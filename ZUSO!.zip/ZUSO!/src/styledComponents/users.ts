import styled from 'styled-components';
import exp from 'constants';

// wrapper
export const Container = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 0rem 5rem 2rem 5rem;
  background: #F1F5F9;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0rem 1rem 2rem 1rem;
  }
`

export const SearchBarContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #E2E8F0;
  padding: 1rem 3rem 1rem 3.5rem;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 1rem 1rem 1rem 1.5rem;
  }
`

export const SearchInput = styled.input`
  background-color: white;
  border-radius: 4px;
  width: 100%;
  min-width: 300px;
  padding: 0.5rem 0.5rem 0.5rem 3rem;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
`

export const HourglassContainer = styled.span`
  margin-right: -30px;
  z-index: 9;
`

export const Hourglass = styled.img`
  width: 15px;
`

export const Header = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  margin-bottom: 10px;
`

export const MainHeading = styled.p`
  color: #334155;
  font-size: 30px;
  font-weight: 600;
`

export const MainHeadingHighlighted = styled.a`
  color: #47BAEB;
  font-size: 30px;
  font-weight: 600;
`

export const MainHeadingMuted = styled.span`
  color: #CBD5E1;
  font-size: 30px;
  font-weight: 600;
`

export const AddUserButton = styled.button`
  padding: 0.5rem 1.5rem;
  color: white;
  background-color: #1E9ED4;
  border-radius: 4px;
  cursor: pointer;
`

export const DeleteUserButton = styled.button`
  padding: 0.5rem 1.5rem;
  color: #64748B;
  border-radius: 4px;
  cursor: pointer;
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
`

export const UserTableContainer = styled.div`
  display: flex;
  width: 100%;
`

export const UserTable = styled.div`
  display: flex;
  flex-grow: 1;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
`

export const TableHeadersContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem 1rem;
  width: 100%;
`

export const TableHeaders = styled.div`
  display: flex;
  justify-content: space-between;
  min-width: 425px;

  @media only screen and (max-width: 1025px) {
    min-width: 120px;
  }

  @media only screen and (max-width: 500px) {
    // for mobile 
    width: 200px;
  }
`

export const TableHeadersLast = styled.div`
  display: flex;
  justify-content: flex-end;
`

export const TableHeading = styled.p`
  color: #94A3B8;
  margin: 0px;
`

export const SortIcon = styled.img`
  width: 8px;
`

export const TableRows = styled.div<{ backgroundColor: string }>`
  display: flex;
  flex-direction: row;
  background-color: ${(props) => props.backgroundColor};
  padding: 0.5rem 1rem;
  width: 100%;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0.5rem 0.5rem;
  }
`

export const TableDefinitions = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-width: 450px;
  padding: 0.5rem;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    min-width: 240px;
  }

  @media only screen and (max-width: 500px) {
    // for mobile 
    width: 200px;
  }
`

export const TableDefinitionLast = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
  min-width: 50px;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    min-width: 50px;
  }
`

export const MenuContainer = styled.div<{display: string}>`
  display: ${props => props.display};
  position: relative;
  flex-direction: column;
  width: 180px;
  background: #FFFFFF;
  border: 1px solid #F8FAFC;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
  border-radius: 4px;
`

export const MenuRow = styled.div`
  display: flex;
  width: 100%;
  padding: 0.2rem;
  flex-direction: row;
  margin-right: 10px;
  
  :hover {
    cursor: pointer;
  }
`

export const MenuIcon = styled.img`
  width: 15px;
  height: 24px;
`

export const MenuHeadingUpdate = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 24px;
  color: #47BAEB;
  margin-left: 5px;
`

export const MenuHeadingDelete = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 24px;
  color: #F87171;
  margin-left: 5px;
`

export const UserName = styled.a`
  color: #1E9ED4;
  font-size: 14px;
  font-weight: 600;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    font-size: 12px;
  }
`

export const UserDesignation = styled.p`
  color: #64748B;
  font-size: 12px;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    font-size: 10px;
  }
`

export const UserEmail = styled.a`
  color: #1E9ED4;
  font-size: 14px;
  font-weight: 600;
  //font-stretch: condensed;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    font-size: 12px;
  }
`

export const UserPermissions = styled.p`
  color: #64748B;
  font-size: 14px;
  font-weight: 600;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    font-size: 12px;
  }
`

export const OptionsIcon = styled.img`
  width: 8px;
  height: 20px;
  @media only screen and (max-width: 1025px) {
    // for mobile 
    width: 8px;
    height: 15px;
  }
`

// user view

export const ProfileContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background: #FFFFFF;
  box-shadow: 2px 2px 4px rgba(30, 41, 59, 0.1);
  border-radius: 4px;
`

export const ProfileHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const ProfileHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const ProfileDetailsContainer = styled.div`
  display: flex;
  flex-direction: row;
`

export const ProfileImageContainer = styled.div`
  width: 35%;
  padding: 4rem;
  display: flex;
  justify-content: center;
  align-items: center;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    width: 30%;
  }
`

export const ProfileImage = styled.img`
  min-width: 200px;
  max-width: 300px;
`

export const ProfileDetails = styled.div`
  display: flex;
  flex-direction: column;
  width: 65%;
  justify-content: center;
  padding: 2rem 0rem;
  //align-items: center;
`

export const ProfileName = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 24px;
  line-height: 36px;
  color: #1E9ED4;
`

export const ProfileDesignation = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 20px;
  color: #475569;
`

export const ProfileIconsContainer = styled.div`
  display: flex;
  flex-direction: row;
  //justify-content: center;
  align-items: center;
  margin-top: 20px;
`

export const ProfileIcons = styled.img`
  width: 10px;
  height: 10px;
`

export const ProfileEmail = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #47BAEB;
  margin-left: 10px;
`

export const ProfilePhone = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #475569;
  margin-left: 10px;
`

export const ProfileInfoHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 20px;
  color: #475569;
  margin-top: 20px;
`

export const ProfileDescription = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 24px;
  color: #64748B;
  max-width: 500px;
`

export const PermissionsContainer = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-top: 1rem;
`

export const PermissionsHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const PermissionsHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const PermissionsBody = styled.div`
  display: flex;
  flex-direction: row;
  background: white;
  padding: 1rem;
`

export const Permissions = styled.div`
  display: flex;
  flex-direction: row;
  padding: 2rem;
  align-items: center;
`

export const PermissionsIcon = styled.img`
  width: 20px;
  height: 20px;
`

export const PermissionName = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 18px;
  color: #475569;
  margin-left: 10px;
`

// delete modal

export const ModalContainer = styled.div`
  background: #F1F5F9;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
  border-radius: 8px 8px 0px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 1rem 2.5rem;

  //@media only screen and (max-width: 1025px) {
  //  // for mobile 
  //  padding: 0rem 2.5rem 0.5rem 2.5rem;
  //}
`

export const ModalImageContainer = styled.div`
  padding: 1rem;  
  @media only screen and (max-width: 1025px) {  
  }
`

export const ModalImage = styled.img`
  width: 150px;
`

export const ModalHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 18px;
  line-height: 24px;
  text-align: center;
  color: #475569;
`

export const ModalName = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 24px;
  line-height: 24px;
  text-align: center;
  color: #47BAEB;
  padding: 0.5rem 0rem;
`

export const ModalSubHeading = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  text-align: center;
  color: #64748B;
`

export const ModalBottom = styled.div`
  display: flex;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 1rem;
  flex-direction: row;
  background: #E2E8F0;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
  border-radius: 0px 0px 8px 8px;
`

export const ModalCloseButton = styled.button`
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  box-shadow: 1px 1px 0px rgba(203, 213, 225, 0.2);
  border-radius: 4px;
  padding: 0.5rem;
  margin-left: 10px;
`

export const ModalCloseButtonText = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  text-align: center;
  color: #64748B;
`

export const ModalConfirmButton = styled.button`
  background: #DC2626;
  border: 1px solid #E2E8F0;
  box-shadow: 1px 1px 0px rgba(203, 213, 225, 0.2);
  border-radius: 4px;
  padding: 0.5rem;
`

export const ModalConfirmButtonText = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  text-align: center;
  color: #FEF2F2;
`

// add user

export const AvatarContainer = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-top: 1rem;
`

export const AvatarHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AvatarHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const AvatarBody = styled.div`
  display: flex;
  flex-direction: column;
  background: white;
  padding: 2.5rem;
  justify-content: center;
  align-items: center;
`

export const AvatarInput = styled.input`
  display: none;
`

export const AvatarImageIcon = styled.img`
  width: 20px;
  height: 20px;
`

export const ClickHereSpan = styled.span`
  color: #47BAEB;
  cursor: pointer;
`

export const AvatarTitle = styled.p`
  color: #94A3B8;
`

export const AvatarProfileContainer = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-top: 1rem;
`

export const AvatarProfileHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AvatarProfileHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const ProfileBody = styled.div`
  display: flex;
  flex-direction: row;
  background: white;
  padding: 1rem;
`

export const ProfileBodyLeft = styled.div`
  display: flex;
  flex-direction: column;
  width: 50%;
  justify-content: center;
`

export const ProfileBodyRight = styled.div`
  display: flex;
  flex-direction: column;
  width: 45%;
  padding-left: 2rem;
  justify-content: center;
`

export const ProfileRows = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0.5rem;
`

export const ProfileInputLabel = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 18px;
  color: #64748B;
`

export const PasswordInfo = styled.p`
  font-style: normal;
  //font-weight: 400;
  font-size: 10px;
  line-height: 18px;
  color: #64748B;
`

export const ProfileInputContainer = styled.div`
  display: flex;
  flex-direction: column;
`

export const ProfileInput = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  min-width: 300px;
  padding: 0.2rem;

  @media only screen and (max-width: 1025px) {
    min-width: 250px;
  }
`

export const ProfileInputError = styled.span`
  color: red;
  display: flex;
  justify-content: flex-end;
  font-size: 8px;
`

export const ProfileDescriptionInput = styled.textarea`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  min-width: 300px;
  min-height: 180px;
  padding: 0.2rem;
  margin-top: 1rem;

  @media only screen and (max-width: 1025px) {
    min-width: 250px;
  }
`

export const PermissionsCheckbox = styled.input`
  width: 20px;
  height: 20px;
  cursor: pointer;
`

export const CreateProfileButton = styled.button`
  margin-top: 20px;
  gap: 10px;
  width: 170px;
  height: 36px;
  background: #1E9ED4;
  color: white;
  border-radius: 4px;
`
