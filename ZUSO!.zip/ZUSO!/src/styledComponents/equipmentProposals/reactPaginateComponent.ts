import styled from "styled-components";


export const ReactPaginateStyled = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 33px;
`

export const LeftColumn = styled.div`
    display: flex;
    align-items: center;
    gap: 10px;

    > select {
        display: inline-block;
        padding: 10px;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;

        option {
            padding: 10px;
        }
    }



    > span, > select {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 19px;
        color: #64748B;
    }
`

export const MiddleColumn = styled.div`

    span {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 19px;
        color: #64748B;
    }
`

export const RightColumn = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 15px;
`