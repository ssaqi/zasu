import styled from "styled-components";


export const EquipmentProposalsModalStyled = styled.form`
    width: 720px;
    background: #FFFFFF;
    box-shadow: 4px 8px 8px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
`

export const ModalHeader = styled.header`
    display: flex;
    justify-content: space-between;
    align-items: center;

    height: 44px;
    background: #F8FAFC;
    border-radius: 8px 8px 0px 0px;
    padding: 0 20px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 18px;
        color: #475569;
    }

    img {
        cursor: pointer;
    }
`

export const ModalBody = styled.div`
    padding: 27px 0;

    > div:first-child {
        border-bottom: 1px solid #E2E8F0;

        > div {
            padding: 0 20px;
        }
    }
`

export const ManufacturerSection = styled.div`
    display: flex;
    align-items: center;
    gap: 16px;
`

export const Detail = styled.div`

    > label {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #505050;
    }

    > input {
        width: 100%;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;
        margin-top: 10px;

        :focus {
           outline: none; 
        }

        ::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 18px;
            color: #94A3B8;
        }
    }
`

export const ProductName = styled(Detail)`
    margin-top: 16px;
`

export const ProductDescription = styled(Detail)`
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 16px;

    > textarea {
        width: 100%;
        min-height: 60px;
        max-height: 250px;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;
        margin-top: 10px;

        :focus {
           outline: none; 
        }

        ::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 18px;
            color: #94A3B8;
        }
    }
`

export const DropdownContainer = styled.div`
    margin-top: 16px;
    margin-bottom: 170px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #505050;
        margin-bottom: 10px;
    }
`

export const DropdownMenu = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;

    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    padding: 10px;
    cursor: pointer;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 18px;
        color: #334155;
    }
`

export const MenuOptions = styled.div`
    position: absolute;
    top: 100%;
    right: 22px;

    width: 285px;
    background: #0982B4;
    border-width: 0px 1px 1px 1px;
    border-style: solid;
    border-color: #9A9A9A;
    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.160784);
    padding: 7px 7px 12px;
    display: none;

    &.shown {
        display: block;
    }

    > p:not(:last-child) {
        margin-bottom: 5px;
    }

    > p {
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 22px;
        letter-spacing: 0.007px;
        color: #FFFFFF;
        cursor: pointer;

        &:hover {
            color: rgba(255, 255, 255, 0.8);
        }
    }
`

export const PersonalInfoSection = styled.div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    align-items: center;
    grid-gap: 16px;

    padding: 0 20px;
    margin-top: 28px;
`

export const PersonalInfoDetail = styled.div`

    > label {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #505050;
    }

    > input {
        width: 100%;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;
        margin-top: 10px;

        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 18px;
        color: #334155;

        :focus {
           outline: none; 
        }
    }
`

export const ButtonsContainer = styled.div`
    display: flex;
    gap: 15px;
    padding: 15px 20px;
    border-top: 1px solid #E2E8F0;
`

export const AddButton = styled.button`
    width: 134px;
    background: #1E9ED4;
    border-radius: 4px;
    padding: 10px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: #F5FCFF;
`

export const ClearButton = styled(AddButton)`
    width: 100px;
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    box-shadow: 1px 1px 0px rgba(203, 213, 225, 0.2);
    border-radius: 4px;
    color: #64748B;
`