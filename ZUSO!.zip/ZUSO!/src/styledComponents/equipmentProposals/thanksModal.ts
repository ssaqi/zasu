import styled from "styled-components";


export const ThanksModalStyled = styled.div`
    width: 720px;
    background: #FFFFFF;
    box-shadow: 4px 8px 8px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
`

export const ImageSection = styled.div`
    display: flex;
    justify-content: center;

    padding-top: 37px;
    padding-bottom: 49px;
`

export const ContentSection = styled.div`
    padding-bottom: 80px;

    > h1 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 30px;
        line-height: 24px;
        text-align: center;
        color: #0172A2;
        margin-bottom: 32px;
    }

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 24px;
        text-align: center;
        color: #64748B;
    }
`

export const ButtonSection = styled.div`
    background: #F1F5F9;
    border-radius: 0px 0px 8px 8px;
    height: 80px;
    
    display: flex;
    justify-content: center;
    align-items: center;

    > button {
        background: #0172A2;
        border-radius: 4px;
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 20px;
        color: #F5FCFF;
        padding: 10px 160px;
    }
`