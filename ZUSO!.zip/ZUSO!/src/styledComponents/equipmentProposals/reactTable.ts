import styled from "styled-components";


export const TableContainer = styled.div`
    .MuiTableSortLabel-icon {
        opacity: 1;
    }
`

export const Table = styled.table`
    width: 100%;

    tr {
        display: grid;
        grid-template-columns: 15% 15% 25% 30% 15%;
        align-items: center;
        position: relative;
    }
`

export const THead = styled.thead`

    tr {
        background: #F8FAFC;
        border-radius: 4px 4px 0px 0px;
        height: 40px;
    }

    /* request */
    th:nth-child(1) {
        padding-left: 22px;
        position: relative;

        &::after {
            content:url('/images/equipmentProposals/sort-icon.svg');
            position: absolute;
            margin-left: 7px;
            margin-top: 2px;
        }

        > span {
            display: none;
        }
    }

    /* request date */
    th:nth-child(2) {
        &::after {
            content:url('/images/equipmentProposals/sort-icon.svg');
            position: absolute;
            margin-left: 7px;
            margin-top: 2px;
        }

        > span {
            display: none;
        }
    }

    /* actions */
    th:nth-child(5) {
        padding-right: 22px;
        text-align: right;
    }

    th {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 12px;
        line-height: 18px;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        color: #94A3B8;
        text-align: left;
    }
`

export const TBody = styled.tbody`

    tr {
        background: #FFFFFF;
        height: 80px;
        width: 100%;
        overflow: hidden;
        transition: 300ms;

        &.is-open {
            height: 330px;
        }
    }
    
    /* request */
    td:nth-child(1) {
        padding-left: 22px;
    }

    /* actions */
    td:nth-child(5) {
        padding-right: 22px;
        text-align: right;
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 12px;
        line-height: 18px;
        color: #64748B;
        cursor: pointer;
    }

    td {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 18px;
        color: #505050;
        margin-top: 20px;

        /* for request by column */
        > p {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 600;
            font-size: 16px;
            line-height: 18px;
            color: #505050;
        }

        > a {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 600;
            font-size: 12px;
            line-height: 18px;
            color: #94A3B8;
        }
    }
`

export const DetailsButton = styled.button`
    display: flex;
    justify-content: flex-end;
    align-items: center;
    width: 100%;

    > span {
        margin-right: 9px;
    }
`

export const TrAccordion = styled.td`
    width: 100%;
    height: 330px;

    > div {
        position: absolute;
        top: 80px;

        width: 100%;
        height: 250px;
        border-top: 1px solid #CBD5E1;
        border-bottom: 1px solid #CBD5E1;
        padding: 25px 20px;
    }
`

export const AccordionCard = styled.div`
    width: 100%;
    height: 100%;
    background: #FFFBEB;
    border: 1px solid #FEF3C7;
    padding: 15px 20px;

    > h2 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 18px;
        line-height: 18px;
        display: flex;
        align-items: center;
        color: #334155;
    }
`

export const AccordionBody = styled.div`
    display: grid;
    grid-template-columns: 30% 70%;
    grid-row-gap: 17px;
    margin-top: 19px;
`

export const Detail = styled.div`

    > h3 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 700;
        font-size: 12px;
        line-height: 18px;
        text-transform: uppercase;
        color: #505050;
        margin-bottom: 2px;
    }

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #475569;
    }

`