import styled from "styled-components";

export const NavContainer = styled.div`
  display: flex;
  position: relative;
  z-index: 0;
  justify-content: space-between;
  text-align: start;
  width: 100%;
  height: 60px;
  background: #17325E;
  //font-family: 'SF Compact Display';
  padding: 0;
  margin: 0;
`
export const LogoLink = styled.a`
  padding: 1rem;
  height: 3.75rem;
  width: 5rem;
  background-image: url('/NavLogo.svg');
`
export const MenuContainer = styled.div`
  display: flex;
  flex-direction: row;
  position: relative;
  z-index: 10;
  justify-content: space-between;
  text-align: start;
  width: 100%;
  padding: 1rem;
  color: #94A3B8;
`
export const NavigationContainer = styled.nav`
  display: flex;
  gap: 12%;
  margin-left: 10px;
  
  @media (max-width: 1024px) {
    gap: 7%;
  }
`

export const NavigationRightContainer = styled.nav`
  display: flex;
  gap: 12%;
  margin-left: 10px;
  padding-right: 1rem;
  
  @media (max-width: 1024px) {
    gap: 0%;
    padding-right: 0rem;
  }
`

export const NavLink = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10%;
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  white-space: nowrap;
  line-height: 18px;
  color: #FFFFFF;
  cursor: pointer;
  
  @media (max-width: 1024px) {
    font-size: 14px;
  } 
`

export const NavIconLink = styled.a`
  display: flex;
  height: 2rem;
  width: 4rem;
  position: relative;
`

export const AvatarImage = styled.img`
  width: 30px;
  border-radius: 50%;
`

export const NavbarIcons = styled.img`
  width: 20px;
  height: 20px;
  align-self: center;
`

export const AvatarImageIcon = styled.img`
  width: 15px;
  margin-left: 8px;
`

/// SearchBar

export const SearchBar = styled.div`
  position: relative;
  display: flex;
  max-width: 480px;
`

export const SearchInput = styled.input`
  width: 100%;
  padding: 1rem 8rem 1rem 8rem;
  font-size: 1rem;
  line-height: 1.5;
  background-color: #fff;
  border: 1px solid #d2d6dc;
  border-radius: 0.375rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;

  &:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 0.2rem rgba(38, 103, 235, 0.25);
  }
`

export const SearchIcon = styled.svg`
  position: absolute;
  top: 60%;
  left: 0.5rem;
  transform: translateY(-50%);
  width: 1rem;
  height: 1rem;
  fill: #9ca3af;
`

//account Navigation

export const AccountBox = styled.div`
  //margin-top: -5rem;
  position: fixed;
  right: 50px;
  top: 0px;
  display: flex;
  flex-direction: column;
  background: #122A4F;
  padding: 1.25rem;
  width: 280px;
  //height: 372px;
  float: right;
  //font-family: 'SF Compact Display';
`
export const AccountHeading = styled.div`
  h1 {
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 17px;
    color: #FFFFFF;
  }

  span {
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 14px;
    color: #94A3B8;
  }
`
export const Divider = styled.div`
  opacity: 0.5;
  border: 1px dashed #015F87;
  margin: 1rem 0 1rem 0;
`
export const AccountSubTitle = styled.div`
  p {
    font-style: normal;
    font-weight: 600;
    font-size: 10px;
    line-height: 14px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #1E9ED4;
  }

  span {
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
    color: #FFFFFF;
  }
`
export const IconColumn = styled.div`

  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 24px;
  /* identical to box height, or 171% */
  color: #FFFFFF;

`;

export const IconRow = styled.div`
  display: flex;
`;

export const Icon = styled.img`
  width: 15px;
  margin-right: 1rem;
  margin-bottom: 0.25rem;
  color: #FFFF;
`;

export const Head2 = styled.h2`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  color: #FFFFFF;
`

export const LogoutButton = styled.button`
  border: none;
`

export const CartQuantity = styled.div`
  position: absolute;
  left: 13px;
  top: -2px;
  background: #EF4444;
  border-radius: 50%;
  width: 17px;
  height: 17px;

  display: flex;
  justify-content: center;
  align-items: center;

  > p {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 10px;
    line-height: 14px;
    text-align: center;
    color: #FFFFFF;
    margin-top: -2px;
  }
`

export const NotificationQuantity = styled(CartQuantity)`
  left: 10px;
`

