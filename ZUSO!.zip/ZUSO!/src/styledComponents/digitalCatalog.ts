import styled from 'styled-components';

export const Container = styled.div`
  display: grid;
  position: relative;
  margin: 3rem 0 1rem 15rem;
  width: 1200px;
  max-width: 1600px;
  text-align: start;
  font-family: 'SF Compact Display';

  h1 {
    font-style: normal;
    font-weight: 600;
    font-size: 30px;
    line-height: 36px;
    color: #334155;
  }

  p {
    font-style: normal;
    font-weight: 400;
    font-size: 16px;
    line-height: 24px;
    /* identical to box height, or 150% */


    /* BlueGray/600 */

    color: #475569;

  }
`

export const Table = styled.tbody`
  display: flex;
  flex-direction: row;
  margin: 1rem 0 1rem 12rem;
`

export const Tr = styled.tr`
  margin: 2rem;
`

export const Td = styled.td`
  display: flex;
  font-style: normal;
  font-weight: 500;
  font-size: 16px;
  line-height: 20px;
  color: #334155;

  span {
    font-style: normal;
    font-weight: 500;
    font-size: 12px;
    line-height: 20px;
    /* identical to box height, or 167% */

    display: flex;
    align-items: center;

    /* BlueGray/500 */

    color: #64748B;
  }

`
export const DownloadButton = styled.button`
  display: flex;
  font-style: normal;
  font-weight: 500;
  font-size: 12px;
  line-height: 20px;
  display: flex;
  align-items: center;
  color: #1E9ED4;
`

export const PageItem = styled.span<{active: boolean}>`
  cursor: pointer;
  padding: 8px;
  background-color: ${(props) => (props.active ? "#4CAF50" : "#ddd")};
  color: ${(props) => (props.active ? "white" : "black")};
`

export const Select = styled.select`
  padding: 10px;
  gap: 10px;
  left: 0%;
  right: 0%;
  top: 0%;
  bottom: 0%;
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  align-items: flex-start;
`

export const PageList = styled.div`
  display: flex;
`

export const ColumnRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;

export const ColumnLeft = styled.div`
  flex: 1;
  text-align: left;
  display: flex;
  margin-top: 0.5rem;
`;

export const ColumnRight = styled.div`
  flex: 0.15;
  text-align: right;
  display: flex;
  margin-top: 0.5rem;
`
export const RowSpan = styled.span`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 17px;
  display: flex;
  align-items: center;
  color: #64748B;
`
