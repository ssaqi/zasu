import styled from "styled-components"

export const ContainerTable = styled.div`
display: flex;
margin: 4rem;
font-family: 'SF Compact Display';
`

export const Table = styled.table`
  width: 100%;
  max-height: 1044px;
  border-collapse: collapse;
  border: solid #fff;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;

`
export const Th = styled.th`
  text-align: left;
  padding: 1.5rem;
  background-color: #f2f2f2;
  height: 80px;
  color: #94A3B8;
  font-style: normal;
font-weight: 600;
font-size: 12px;
`

export const Td = styled.td`
  text-align: left;
  padding: 1.5rem;
  border-bottom: 1px solid #ddd;
  font-style: normal;
  font-weight: 500;
  font-size: 16px;
  line-height: 18px;
  color: #1E9ED4;
`

export const Tr = styled.tr`
  &:nth-child(even) {
    background-color: #f2f2f2;
  }
`

export const SearchFilters = styled.thead`
background: #FFFFFF;
border-radius: 0px;
width: 1200px;
height: 54px;
font-weight: 500;
font-size: 12px;
`

export const FilterRow = styled.th`
background: #FFFFFF;
text-align: start;
color: #CBD5E1;
padding: 1.5rem;
`
export const FilterA = styled.input`
display: flex;
padding: 0.25rem;
border-color:#000000;
background: #FFFFFF;
border: 1px solid;
border-radius: 0.10rem;
width: 10rem;
`
export const FilterB = styled.input`
display: flex;
padding: 0.25rem;
border-color:#000000;
background: #FFFFFF;
border: 1px solid;
border-radius: 0.10rem;
width: 14rem;
`
export const FilterC = styled.input`
display: flex;
padding: 0.25rem;
border-color:#000000;
background: #FFFFFF;
border: 1px solid;
border-radius: 0.10rem;
width: 20rem;
`
export const FilterD = styled.input`
display: flex;
padding: 0.25rem;
border-color:#000000;
background: #FFFFFF;
border: 1px solid;
border-radius: 0.10rem;
width: 8rem;
`

export const DataName = styled.td`
display: flex;
flex-direction: column;
font-weight: 500;
font-size: 14px;
color: #1E9ED4;
padding: 1rem;
span {
    font-weight: 500;
    font-size: 14px;
    line-height: 18px;
    color: #94A3B8;
}
`
export const DataShip = styled.td`
font-style: normal;
font-weight: 500;
font-size: 14px;
color: #64748B;
padding: 1rem;
width: 2rem;
`
