import styled from "styled-components";

export const Container = styled.div`
  position: flex;
  width: 250px;
  height: 1044px;
  background: #FFFFFF;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.1);
  border-radius: 4px;

`
export const Header = styled.div`
  //width: 200px;
  height: 50px;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`
export const Heading = styled.h1`
  padding: 0.5rem;
  font-style: normal;
  font-weight: 600;
  font-size: 1.15rem;
  line-height: 1.2rem;
  color: #475569;
`
export const Form = styled.form`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  align-items: center;
  padding: 1.5rem;
  color: #475569;

  input {
    left: 5.56%;
    right: 5.56%;
    top: 5.56%;
    bottom: 5.56%;
    line-height: 1.50rem;
    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.05);
    border-radius: 4px;
  }

  label {

    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 1.50rem;
    color: #475569;
    padding-left: 0.75rem;
  }
`
