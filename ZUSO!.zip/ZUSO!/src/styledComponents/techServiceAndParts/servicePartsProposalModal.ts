import styled from "styled-components";

export const ServicePartsProposalsModalStyled = styled.form`
  width: 720px;
  background: #ffffff;
  box-shadow: 4px 8px 8px rgba(0, 0, 0, 0.05);
  border-radius: 8px;
`;

export const ModalHeader = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;

  height: 44px;
  background: #f8fafc;
  border-radius: 8px 8px 0px 0px;
  padding: 0 20px;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 18px;
    color: #475569;
  }

  img {
    cursor: pointer;
  }
`;

export const ModalBody = styled.div`
  padding: 20px 0;

  > div:first-child {
    border-bottom: 1px solid #e2e8f0;

    > div {
      padding: 0 20px;
    }
  }
`;
export const BodyHeader = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;

  height: 44px;
  width: 82%;

  padding-inline: 20px;

  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-size: 14px;
  line-height: 18px;
  color: #64748b;

  > p {
    color: #64748b;
  }
`;

export const RadioInputs = styled.div`
  display: flex;
  justify-content: start;
  padding-inline: 5px;
  
  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-size: 14px;
    line-height: 18px;
    color: #64748b;
  }
`;

export const RadioInput = styled.input`
  appearance: none;
  width: 20px;
  height: 20px;
  margin-right: 10px;
  cursor: pointer;
  position: relative;
  z-index: 3;

  background-color: #ffffff;

  border: 1px solid rgba(0, 0, 0, 0.1);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.05);
  border-radius: 100px;

  &:before {
    content: "";
    width: 80%;
    height: 80%;
    border-radius: 100px;
    border: 1px solid #2096c7;
    background: #1e9ed4;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%)
      scale(${(props) => (props.checked ? 1 : 0)});
    transition: transform 0.2s ease;
    z-index: -1;
  }
`;

export const ManufacturerSection = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
`;

export const Detail = styled.div`
  display: flex;
  flex-direction: column;
  margin-right: 20px;

  > label {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #505050;
  }

  > input {
    width: 100%;
    background: #ffffff;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    padding: 5px 10px;
    margin-top: 10px;

    :focus {
      outline: none;
    }

    ::placeholder {
      font-family: "Open Sans", sans-serif;
      font-style: normal;
      font-weight: 400;
      font-size: 14px;
      line-height: 18px;
      color: #94a3b8;
    }
  }
`;

export const BoxTitle = styled(Detail)`
  margin-top: 16px;
`;

export type BoxDescriptionProps = {
  small?: boolean;
};

export const BoxDescription = styled(Detail)<BoxDescriptionProps>`
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-top: 16px;

  > textarea {
    width: ${(props) => (props.small ? "30%" : "50%")};
    min-height: 60px;
    max-height: 100px;
    background: #ffffff;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    padding: 5px 10px;
    margin-top: 10px;

    :focus {
      outline: none;
    }

    ::placeholder {
      font-family: "Open Sans", sans-serif;
      font-style: normal;
      font-weight: 400;
      font-size: 14px;
      line-height: 18px;
      color: #94a3b8;
    }
  }
`;

export const DropdownContainer = styled.div`
  margin-top: 16px;
  margin-bottom: 170px;
  margin-right: 20px;
  display: flex;
  flex-direction: column;
  width: 40%;

  p#placeholder {
    color: #94a3b8;
  }

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #505050;
    margin-bottom: 10px;
  }
`;

export const DropdownMenu = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;

  background: #ffffff;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  padding: 10px;
  cursor: pointer;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
    color: #334155;
  }
`;

export const MenuOptions = styled.div`
  position: absolute;
  top: 100%;
  right: 22px;

  width: 285px;
  background: #0982b4;
  border-width: 0px 1px 1px 1px;
  border-style: solid;
  border-color: #9a9a9a;
  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.160784);
  padding: 7px 7px 12px;
  display: none;

  &.shown {
    display: block;
  }

  > p:not(:last-child) {
    margin-bottom: 5px;
  }

  > p {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 22px;
    letter-spacing: 0.007px;
    color: #ffffff;
    cursor: pointer;

    &:hover {
      color: rgba(255, 255, 255, 0.8);
    }
  }
`;

export const PersonalInfoSection = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  align-items: center;
  grid-gap: 16px;

  padding: 0 20px;
  margin-top: 28px;
`;

export const PersonalInfoDetail = styled.div`
  > label {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #505050;
  }

  > input {
    width: 100%;
    background: #ffffff;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    padding: 5px 10px;
    margin-top: 10px;

    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
    color: #334155;

    :focus {
      outline: none;
    }
  }
`;

export const ButtonsContainer = styled.div`
  display: flex;
  gap: 15px;
  padding: 15px 20px;
  border-top: 1px solid #e2e8f0;
`;

export const AddButton = styled.button`
  width: 134px;
  background: #1e9ed4;
  border-radius: 4px;
  padding: 10px;
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  color: #f5fcff;
`;

export const ClearButton = styled(AddButton)`
  width: 100px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  box-shadow: 1px 1px 0px rgba(203, 213, 225, 0.2);
  border-radius: 4px;
  color: #64748b;
`;

export const RequestSections = styled.div`
  padding-inline: 20px;

  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #505050;
  margin-bottom: 10px;
`;

export const SendTechStyled = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  width: 100%;
  height: 55vh;

  div:first-child {
    display: flex;
    justify-content: space-between;
    width: 45%;
    height: 5%;
  }
`;
