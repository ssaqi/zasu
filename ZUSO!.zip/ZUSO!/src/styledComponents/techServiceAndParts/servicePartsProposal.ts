import styled from "styled-components";


export const ServicePartsProposalsStyled = styled.div`
    background: #F1F5F9;
`

export const ContentWrapper = styled.div`
    padding: 50px 4rem;
    min-height: 60vh;
`

export const TopSection = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 43px;

    > h1 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 35px;
        line-height: 36px;
        color: #334155;
    }

    > button {
        background: #1E9ED4;
        border-radius: 4px;
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 20px;
        text-align: center;
        color: #F5FCFF;
        padding: 10px 20px;
    }
`

