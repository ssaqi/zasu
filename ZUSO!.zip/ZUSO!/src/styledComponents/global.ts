import styled from "styled-components";



export const BackgroundContainer = styled.div`
  background: #f1f5f9;
`;

export const ContentWrapper = styled.div`
    padding: 50px 4rem;
    min-height: 60vh;
`