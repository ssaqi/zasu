import styled from 'styled-components';

export const Container = styled.div`
   color: #fff;
   width: 100%;
   height: 600px;
   background-color: aliceblue;
`





