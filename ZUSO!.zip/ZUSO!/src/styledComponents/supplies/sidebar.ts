import styled from "styled-components";


export const SidebarStyled = styled.div`
  width: 250px;
  min-height: 100vh;
  background: #FFFFFF;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  height: fit-content;
  /* padding-bottom: 30px; */
  padding-bottom: 18px;
`

export const Search = styled.div`

`

export const SearchTop = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 10px 7px 10px 20px;

  > p {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 18px;
    color: #475569;
  }

  > button {
    background: #9A9A9A;
    border-radius: 10px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #F5FCFF;
    padding: 1px 13px;
  }
`

export const SearchInput = styled.div`
  position: relative;
  padding: 10px;

  > input {
    background: #FFFFFF;
    border: 1px solid #1E9ED4;
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    width: 100%;
    height: 38px;
    padding: 5px 10px;

    ::-webkit-input-placeholder, ::placeholder { /* Edge */
      font-family: 'Open Sans', sans-serif;
      font-style: normal;
      font-weight: 600;
      font-size: 14px;
      line-height: 18px;
      color: #94A3B8;
    }

    :focus {
      outline: 1px solid transparent;
    }
  }

  > div {
    display: flex;
    justify-content: center;
    align-items: center;

    position: absolute;
    top: 10px;
    right: 10px;

    width: 27px;
    height: 38px;
    background: #1495CA;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 0px 4px 4px 0px;

    > img {
      width: 11.83px;
      height: 11px;
    }
  }
`

export const SuggestionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  border: 1px solid #1E9ED4;
  margin-left: 10px;
  margin-right: 10px;
  position: absolute;
  background: white;
  width: 230px;
  margin-top: -10px;
  z-index: 9;
  max-height: 400px;
  overflow-y: scroll;
  
  > span {
    border-bottom: 1px solid #1E9ED4;
    padding-left: 5px;
    cursor: pointer;
    :last-child {
      border-bottom: none;
    }
  }

`

export const SearchesContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-items: center;
  gap: 1rem;
  padding: 10px;

  > div {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    background: #FEF2F2;
    border: 1px solid #FEE2E2;
    border-radius: 3px;
    padding: 5px;

    > span {
      font-size: 12px;
      white-space: nowrap;
      font-weight: bold;
      max-width: 200px;
      overflow-x: hidden;
    }
    
    > img {
      margin-left: 10px;
      width: 10px;
      cursor: pointer;
    }
  }

`

export const PrevPurchased = styled.div`
  display: flex;
  align-items: center;
  padding: 0 16px;
  margin-top: 20px;

  > input {
    width: 16px;
    height: 16px;
    background: #1E9ED4;
    border-radius: 4px;
    margin-right: 8px;
  }

  > label {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    color: #475569;
  }
`

export const SupplierPref = styled.div`
  margin-top: 15px;
`

export const SupplierTop = styled.div`
  display: flex;
  align-items: center;

  height: 37px;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  font-family: 'Open Sans', sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 18px;
  color: #475569;
  margin-bottom: 20px;
  margin-left: 18px;
`

export const SupplierDropdown = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  height: 36px;
  margin: 0 15px;
  padding: 0 18px;
`

export const Option = styled.div`
  font-family: 'Open Sans', sans-serif;
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 18px;
  color: #334155;
`

export const ManufacturerTop = styled(SupplierTop)`
  margin-top: 32px;
`

export const ManufacturerInput = styled(SearchInput)`

`

export const CategoriesSection = styled.div`
  margin-top: 80px;
`

export const CategoriesTop = styled(SupplierTop)`
  margin-left: 0;
  padding-left: 16px;
`

export const Categories = styled.div`
  padding: 0 16px;

  > div:not(:last-child) {
    margin-bottom: 8px;
  }
`

export const Category = styled.div`
  display: flex;
  align-items: center;

  > input {
    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.05);
    border-radius: 4px;
    width: 14px;
    height: 14px;
  }

  > label {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    color: #475569;
    margin-left: 7px;
  }
`

export const More = styled.div`
  font-family: 'Open Sans', sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 19px;
  color: #1E9ED4;
  margin-top: 10px;
  margin-left: 35px;
  cursor: pointer;
`
