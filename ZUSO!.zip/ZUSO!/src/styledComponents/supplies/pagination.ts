import styled from "styled-components";


export const PaginationStyled = styled.div`
   display: flex;
   justify-content: space-evenly;
   align-items: center;
   margin-top: 40px;
   padding-right: 5px;
`

export const PerPage = styled.div`
   display: flex;
   justify-content: space-between;
   align-items: center;

   > span:first-child {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 19px;
        /* identical to box height */
        display: flex;
        align-items: center;
        color: #64748B;
   }

   > span:last-child {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 19px;
        /* identical to box height */
        display: flex;
        align-items: center;
        color: #64748B;
   }
`

export const PerPageDropDown = styled.select`
    width: 65px;
    height: 36px;
    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    margin: 0 10px;
    padding: 0 10px;

    display: flex;
    justify-content: space-between;
    align-items: center;

    /* > span {
        font-size: 13px;
        color: #64748B;
        font-weight: bold;
    } */

    > option {
        font-size: 14px;
        color: #64748B;
        font-weight: bold;
    }
`

export const Displaying = styled.div`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    /* identical to box height */
    color: #64748B;
`

export const PaginationContainer = styled.div`
    display: flex;
    justify-content: space-evenly;
    align-items: center;

    > img {
        cursor: pointer;        
        margin-bottom: -2px;
    }
`

export const PreviousBtn = styled.div`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    /* identical to box height */
    display: flex;
    align-items: center;
    color: #94A3B8;
    cursor: pointer;

    margin-left: 12px;
    margin-right: 15px;
`

export const NextBtn = styled(PreviousBtn)`
    color: #1E9ED4;
    margin-left: 15px;
    margin-right: 12px;
`

export const Numbers = styled.div`

    > span {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 19px;
        color: #1E9ED4;
        cursor: pointer;        

        &.active {
            color: #94A3B8;
        }
    }

    > span:not(:last-child) {
        margin-right: 7px;
    }
`
