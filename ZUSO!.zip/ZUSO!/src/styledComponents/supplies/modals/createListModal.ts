import styled from "styled-components";


export const CreateListModalStyled = styled.div`
    width: 720px;
    background: #FFFFFF;
    box-shadow: 4px 8px 8px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
`

export const ModalHeader = styled.header`
    display: flex;
    justify-content: space-between;
    align-items: center;

    height: 44px;
    background: #F8FAFC;
    border-radius: 8px 8px 0px 0px;
    padding: 0 20px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 18px;
        color: #475569;
    }

    img {
        cursor: pointer;
    }
`

export const ModalBody = styled.form`
    background: #FFFFFF;
    border-radius: 0px 0px 4px 4px;
`

export const InputsContainer = styled.div`
    margin-top: 20px;
    margin-bottom: 70px;
    padding: 0 20px;
`

export const ListName = styled.div`
    display: flex;
    flex-direction: column;
    row-gap: 10px;

    > label {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #64748B;
    }

    > input {
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 7px 10px;

        &::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 18px;
            color: #94A3B8;
        }

        &:focus {
            outline: none;
        }
    }
`

export const Description = styled(ListName)`
    margin-top: 18px;

    > textarea {
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 7px 10px;
        min-height: 90px;
        max-height: 300px;

        &::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 18px;
            color: #94A3B8;
        }

        &:focus {
            outline: none;
        }

        ::-webkit-scrollbar {
            width: 5px;
        }

        ::-webkit-scrollbar-track {
            background: #fff;
        }

        ::-webkit-scrollbar-thumb {
            background: #CBD5E1;
            border-radius: 100px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    }
`

export const ButtonContainer = styled.div`
    padding: 15px 20px;
    display: flex;
    gap: 10px;
`

export const CreateListButton = styled.button`
    width: 100px;
    height: 36px;
    background: #1E9ED4;
    border-radius: 4px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: #F5FCFF;
`

export const CancelButton = styled(CreateListButton)`
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    color: #64748B;
`