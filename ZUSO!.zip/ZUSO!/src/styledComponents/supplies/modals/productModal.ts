import styled from "styled-components";

export const ProductModalStyled = styled.div`
  width: 1010px;
`;

export const ModalHeader = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;

  height: 44px;
  background: #f8fafc;
  border-radius: 8px 8px 0px 0px;
  padding: 0 20px;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 18px;
    color: #475569;
  }

  img {
    cursor: pointer;
  }
`;

export const ModalBody = styled.div`
  height: 500px;
  background: #ffffff;
  border-radius: 0px 0px 4px 4px;
`;

export const ModalColumns = styled.div`
  display: grid;
  grid-template-columns: 345px auto;
`;

export const ImageColumn = styled.div`
  /* large image */
  > div:first-child {
    margin: 40px 35px 40px 40px;

    img {
      width: 275px;
      height: 388px;
    }
  }

  /* small images */
  > div:last-child {
    display: grid;
    grid-template-columns: repeat(2, 90px);
    justify-content: center;
    grid-gap: 18px;

    img {
      width: 90px;
      height: 100px;
      border: 1px solid #f1f5f9;
      border-radius: 4px;
    }
  }
`;

export const ContentColumn = styled.div``;

export const ModalBreadcrumb = styled.div`
  display: flex;
  align-items: center;
  margin-top: 17px;

  > p {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 22px;
    letter-spacing: 0.0075px;
    color: #707070;
  }

  > span {
    margin: 0 5px;
  }
`;

export const ProductName = styled.p`
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 24px;
  line-height: 30px;
  color: #1e9ed4;
  margin-top: 12px;
  margin-right: 8%;
`;

export const ProductDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  margin-top: 15px;
`;

export const ProductDetailsLeft = styled.div`
  margin-left: -40px;
`;

export const ProductDetailContainer = styled.div`
  display: grid;
  grid-template-columns: 105px 135px;
  justify-content: center;
  align-items: center;
  gap: 12px;

  p:first-child {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 22px;
    text-align: right;
    letter-spacing: 0.0075px;
    color: #9a9a9a;
  }

  p:last-child {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 700;
    font-size: 14px;
    line-height: 22px;
    letter-spacing: 0.0075px;
    color: #505050;
  }
`;

export const ProductDetailsRight = styled.div`
  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    color: #505050;
  }
`;

export const Tags = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 80px);
  gap: 4px;

`;

export const InputContainer = styled.div`
  position: relative;
  width: 190px;
  margin: 8px 0 5px;

  > input {
    display: inline-block;
    background: #ffffff;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px 0 0 4px;
    font-size: 11px;
    width: calc(100% - 23px);
    height: 23px;
    padding: 3px 5px;
    transform: translateY(-2px);

    ::placeholder {
      font-family: "Open Sans", sans-serif;
      font-style: normal;
      font-weight: 400;
      font-size: 11px;
      color: #94a3b8;

      position: absolute;
      top: 50%;
      transform: translateY(-50%);
    }

    :focus {
      outline: 1px solid transparent;
    }
  }

  /* plus icon container */
  > div {
    position: absolute;
    right: 0;
    top: 0;

    width: 23px;
    height: 23px;
    background: #1495ca;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 0px 4px 4px 0px;
    cursor: pointer;

    display: flex;
    justify-content: center;
    align-items: center;

    > img {
      width: 6px;
      height: 6px;
    }
  }
`;

export const Tag = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 7px;

  width: 74px;
  padding: 3px 8px;
  background: #fef2f2;
  border: 1px solid #fee2e2;
  border-radius: 3px;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 12px;
    line-height: 18px;
    color: #f87171;
  }
`;

export const MoreDetails = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  width: 75%;
  height: 40px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 3px;
  padding: 0 22px;
  margin-top: 30px;
`;

export const CenterPara = styled.p`
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 30px;
  color: #505050;
`;

export const Price = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;

  > span,
  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 20px;
    line-height: 30px;
    color: #f87171;
  }
`;

export const SKU = styled(Price)`
  > p:first-child {
    color: #9a9a9a;
    margin-right: 4px;
  }

  > p:last-child {
    color: #505050;
  }
`;

export const ButtonsSection = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;

  width: 75%;
  margin-top: 20px;
`;

export const BlueButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;

  width: 142px;
  height: 36px;
  background: #1e9ed4;
  border-radius: 4px;

  > span {
    margin-left: 7px;
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #f5fcff;
  }
`;

export const GreenButton = styled(BlueButton)`
  background: #14ca76;
`;

export const AddToList = styled(BlueButton)`
  background: #f5f8fa;
  border: 1px solid #e2e8f0;

  > span {
    color: #64748b;
  }
`;

// export const Quantity = styled.div`
//     display: flex;
//     align-items: center;
//     justify-content: space-between;

//     width: 115px;
//     height: 36px;
//     background: #FFFFFF;
//     border: 1px solid #E2E8F0;
//     border-radius: 4px;

//     > p, div {
//         display: flex;
//         align-items: center;
//         justify-content: center;
//     }

//     /* quantity */
//     > p {
//         text-align: center;
//         width: 38%;
//         height: 36px;
//         color: #64748B;
//     }

//     /* minus icon */
//     > div:first-child {
//         width: 31%;
//         height: 36px;
//         border-right: 1px solid #E2E8F0;
//         cursor: pointer;
//     }

//     /* plus icon */
//     > div:last-child {
//         width: 31%;
//         height: 36px;
//         border-left: 1px solid #E2E8F0;
//         cursor: pointer;
//     }
// `

export const Quantity = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;

  width: 115px;
  height: 36px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 4px;

  > div {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* minus icon */
  > div:nth-child(1) {
    width: 31%;
    height: 100%;
    border-right: 1px solid #e2e8f0;
    cursor: pointer;
  }

  /* quantity */
  > div:nth-child(2) {
    width: 38%;
    height: 100%;

    > input {
      width: 100%;
      height: 100%;
      padding: 0;
      text-align: center;
      border: none;
      font-size: 15px;

      :focus {
        outline: none;
      }
    }
  }

  /* plus icon */
  > div:nth-child(3) {
    width: 31%;
    height: 100%;
    border-left: 1px solid #e2e8f0;
    cursor: pointer;
  }
`;

export const ProductDescription = styled.div`
  margin-top: 40px;
  margin-right: 8%;

  > h3 {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #475569;
  }

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 24px;
    color: #64748b;
    margin-top: 5px;
  }
`;
export const FurtherDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  margin-top: 15px;
  transform: translateX(-8px);
`;

export const FurtherDetailsLeft = styled.div`
  margin-left: -40px;
`;

export const FurtherDetailContainer = styled.div`
  display: grid;
  grid-template-columns: 130px 160px;
  justify-content: center;
  align-items: center;
  gap: 12px;

  p:first-child {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 22px;
    text-align: right;
    letter-spacing: 0.0075px;
    color: #9a9a9a;
  }

  p:last-child {
    font-family: "Roboto", sans-serif;
    font-style: normal;
    font-weight: 700;
    font-size: 14px;
    line-height: 22px;
    letter-spacing: 0.0075px;
    color: #505050;
  }
`;

export const FurtherDetailsRight = styled.div`
  transform: translateX(-30px);

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 19px;
    color: #505050;
  }
`;

export const SafetyData = styled.div`
  display: flex;
  align-items: center;
  margin-top: 13px;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #475569;
  }

  > p:last-child {
    margin-left: 10px;
    color: #1495ca;
  }
`;

export const ProductSpecs = styled.div`
  margin-right: 10%;
  margin-top: 25px;
  margin-bottom: 30px;
`;

export const ProductSpecsTop = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  height: 44px;
  background: #f8fafc;
  border-radius: 8px 8px 0px 0px;
  padding: 0 15px;
  cursor: pointer;

  > p {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    color: #475569;
  }

  > img {
    visibility: hidden;

    &.is-open {
      visibility: visible;
    }
  }
`;

export const ProductSpecsBody = styled.p`
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 24px;
  color: #64748b;
  overflow: hidden;
  height: 0;

  &.is-open {
    height: auto;
    padding: 15px;
  }
`;

export const ModalFooter = styled.footer`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 40px;
  padding: 10px 0;

  > p {
    font-family: "Open Sans";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 30px;
    letter-spacing: 0.01em;
    color: #94a3b8;
  }
`;
