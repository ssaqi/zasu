import styled from "styled-components";


export const SpecialOrderModalStyled = styled.form`
    width: 720px;
`

export const ModalHeader = styled.header`
    display: flex;
    justify-content: space-between;
    align-items: center;

    height: 44px;
    background: #F8FAFC;
    border-radius: 8px 8px 0px 0px;
    padding: 0 20px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 18px;
        color: #475569;
    }

    img {
        cursor: pointer;
    }
`

export const ModalBody = styled.div`
    padding: 20px;
    display: grid;
    grid-gap: 15px;
`

export const InputGrid = styled.div`
    display: grid;
    grid-template-columns: 35% 65%;
    align-items: center;
`

export const InputContainer = styled(InputGrid)`

    label {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 18px;
        color: #64748B;
    }

    input {
        width: 100%;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;

        :focus {
           outline: none; 
        }

        ::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 600;
            font-size: 14px;
            line-height: 18px;
            color: #E2E8F0;
        }
    }

   
`

export const Quantity = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;

    width: 115px;
    height: 36px;
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 4px;

    > div {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* minus icon */
    > div:nth-child(1) {
        width: 31%;
        height: 100%;
        border-right: 1px solid #E2E8F0;
        cursor: pointer;
    }

    /* quantity */
    > div:nth-child(2) {
        width: 38%;
        height: 100%;

        > input {
            width: 100%;
            height: 100%;
            padding: 0;
            text-align: center;
            border: none;
            font-size: 15px;

            :focus {
                outline: none;
            }
        }
    }

    /* plus icon */
    > div:nth-child(3) {
        width: 31%;
        height: 100%;
        border-left: 1px solid #E2E8F0;
        cursor: pointer;
    }
`

export const NotesInfo = styled(InputContainer)`
    align-items: start;

    textarea {
        width: 100%;
        min-height: 60px;
        max-height: 250px;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;

        :focus {
           outline: none; 
        }

        ::placeholder {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 600;
            font-size: 14px;
            line-height: 18px;
            color: #E2E8F0;
        }

        ::-webkit-scrollbar {
            width: 5px;
        }

        ::-webkit-scrollbar-track {
            background: #fff;
        }

        ::-webkit-scrollbar-thumb {
            background: #CBD5E1;
            border-radius: 100px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    }
`

export const UploadPhoto = styled(NotesInfo)`
    
    > div:last-child {
        display: flex;
        flex-direction: column;
        gap: 13px;
        justify-content: center;
        align-items: center;

        width: 100%;
        height: 93px;
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 5px 10px;

        p {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 600;
            font-size: 14px;
            line-height: 18px;
            color: #94A3B8;

            span {
                color: #47BAEB;
                cursor: pointer;
            }
        }
    }
`

export const ButtonsContainer = styled.div`
    display: flex;
    gap: 15px;
    padding: 15px 20px;
    border-top: 1px solid #E2E8F0;
`

export const AddButton = styled.button`
    width: 134px;
    background: #1E9ED4;
    border-radius: 4px;
    padding: 10px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: #F5FCFF;
`

export const ClearButton = styled(AddButton)`
    width: 100px;
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    box-shadow: 1px 1px 0px rgba(203, 213, 225, 0.2);
    border-radius: 4px;
    color: #64748B;
`