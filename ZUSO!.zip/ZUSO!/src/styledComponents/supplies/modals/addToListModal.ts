import styled from "styled-components";


export const AddToListModalStyled = styled.div`
    width: 720px;
    background: #FFFFFF;
    box-shadow: 4px 8px 8px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
`

export const ModalHeader = styled.header`
    display: flex;
    justify-content: space-between;
    align-items: center;

    height: 44px;
    background: #F8FAFC;
    border-radius: 8px 8px 0px 0px;
    padding: 0 20px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 18px;
        color: #475569;
    }

    img {
        cursor: pointer;
    }
`

export const ModalBody = styled.div`
    background: #FFFFFF;
    border-radius: 0px 0px 4px 4px;
`

export const ListsTable = styled.div`
    height: 274px;
    overflow: auto;
    border-bottom: 1px solid #E2E8F0;
    margin-right: 5px;

    ::-webkit-scrollbar {
        width: 5px;
    }

    ::-webkit-scrollbar-track {
        background: #fff;
    }

    ::-webkit-scrollbar-thumb {
        background: #CBD5E1;
        border-radius: 100px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #555;
    }

    table {
        width: 100%;
        height: 100%;

        thead {
            tr {
                border-bottom: 1px solid #E2E8F0;
                padding: 8px 20px; 
                margin-top: 8px;
            }

            th {
                font-family: 'Open Sans', sans-serif;
                font-style: normal;
                font-weight: 600;
                font-size: 12px;
                line-height: 18px;
                letter-spacing: 0.1em;
                text-transform: uppercase;
                color: #94A3B8;
                text-align: left;
            }

            /* items */
            th:nth-child(2) {
                text-align: center;
            }

            /* total */
            th:nth-child(3) {
                text-align: center;
            }
        }

        tr {
            display: grid;
            align-items: center;
            grid-template-columns: 40% 25% 25% 10%;
            padding: 10px 20px; 
        }

        tbody {
            tr:nth-child(even) {
                background: #F8FAFC;
            }

            tr:first-child {
                margin-top: 10px;
            }

            tr:last-child {
                margin-bottom: 10px;
            }

            /* list name */
            td:nth-child(1) {
                font-family: 'Open Sans', sans-serif;
                font-style: normal;
                font-weight: 600;
                font-size: 14px;
                line-height: 18px;
                color: #1E9ED4;
            }

            /* items */
            td:nth-child(2) {
                font-family: 'Open Sans', sans-serif;
                font-style: normal;
                font-weight: 600;
                font-size: 12px;
                line-height: 16px;
                color: #64748B;
                text-align: center;

                span {
                    background: #F8FAFC;
                    border: 1px solid #E2E8F0;
                    border-radius: 100px;
                    margin-right: 5px;
                    padding: 3px 8px;
                }
            }

            /* total */
            td:nth-child(3) {
                font-family: 'Open Sans', sans-serif;
                font-style: normal;
                font-weight: 600;
                font-size: 14px;
                line-height: 18px;
                color: #475569;
                text-align: center;
            }

            /* action */
            td:nth-child(4) {
                text-align: center;

                span {
                    display: inline-block;
                    background: #1E9ED4;
                    border-radius: 4px;
                    padding: 7px;
                    transform: translateX(10px);
                    cursor: pointer;
                }  
            }
        }
    }
`

export const NoListsFound = styled.div`
    height: 300px;
    background: #F1F5F9;
    border-bottom: 1px solid #E2E8F0;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
`

export const ImageContainer = styled.div`
    display: flex;
    justify-content: center;
    position: relative;

    > div {
        width: 160px;
        height: 160px;
        padding: 0 10px;

        /* background image */
        > img {
            width: 100%;
            height: 100%;
        }
    }

    /* no lists icon */
    > img {
        width: 81px;
        height: 83px;
        position: absolute;
        top: 50%;
        transform: translate(5px, -50%);
    }
`

export const NoListsText = styled.div`
    margin-top: 15px;

    > h3 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 20px;
        color: #475569;
        text-align: center;
    }

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 12px;
        line-height: 20px;
        color: #94A3B8;
    }
`

export const ButtonContainer = styled.div`
    padding: 15px 20px;

    > button {
        width: 130px;
        height: 36px;
        background: #1E9ED4;
        border-radius: 4px;
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 20px;
        color: #F5FCFF;
    }
`