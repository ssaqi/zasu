import styled from "styled-components";


export const ConfirmRemoveModalStyled = styled.div`
    width: 500px;
    position: relative;

    background: #F1F5F9;
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
    padding: 25px 30px 0;
`

export const CloseIcon = styled.img`
    position: absolute;
    top: 10px;
    right: 10px;
    cursor: pointer;
`

export const ImageContainer = styled.div`
    display: flex;
    justify-content: center;
    position: relative;

    > div {
        width: 180px;
        height: 180px;
        padding: 0 10px;

        /* background image */
        > img {
            width: 100%;
            height: 100%;
        }
    }

    /* product image */
    > img {
        width: 88px;
        height: 120px;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
    }
`

export const RemovalMessage = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 24px;
    text-align: center;
    color: #334155;
    margin-top: 15px;
`

export const ProductName = styled.h2`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 18px;
    line-height: 24px;
    text-align: center;
    color: #1E9ED4;
    margin-top: 10px;
`

export const DetailsSection = styled.div`
    margin-top: 15px;
    padding: 0 5px;
`
export const Detail = styled.div`
    margin-bottom: 15px;

    > p:first-child {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 24px;
        text-align: center;
        color: #334155;
    }

    > p:last-child {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 18px;
        line-height: 24px;
        text-align: center;
        color: #F87171;
    }
`

export const ConfirmMessage = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    text-align: center;
    color: #475569;
`

export const ButtonsContainer = styled.div`
    width: calc(100% + 60px);
    height: 70px;
    transform: translateX(-30px);
    background: #E2E8F0;
    border-radius: 0px 0px 8px 8px;
    margin-top: 16px;

    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
`

export const RemoveButton = styled.button`
    width: 206px;
    height: 40px;
    background: #DC2626;
    border-radius: 4px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 20px;
    color: #FEF2F2;
`

export const BackButton = styled(RemoveButton)`
    width: 145px;
    background: #FFFFFF;
    color: #64748B;
`