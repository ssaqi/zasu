import styled from "styled-components";


export const RemoveItemModalStyled = styled.div`
    width: 500px;
    position: relative;
    /* height: 660px; */

    background: #F1F5F9;
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
    border-radius: 8px;
    padding: 25px 30px 0;
`

export const CloseIcon = styled.img`
    position: absolute;
    top: 10px;
    right: 10px;
    cursor: pointer;
`

export const ImageContainer = styled.div`
    display: flex;
    justify-content: center;
    position: relative;

    > div {
        width: 180px;
        height: 180px;
        padding: 0 10px;

        /* background image */
        > img {
            width: 100%;
            height: 100%;
        }
    }

    /* product image */
    > img {
        width: 88px;
        height: 120px;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
    }
`

export const RemovalMessage = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 24px;
    text-align: center;
    color: #334155;
    margin-top: 15px;
`

export const ProductName = styled.h2`
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 18px;
    line-height: 24px;
    text-align: center;
    color: #1E9ED4;
    margin-top: 10px;
`

export const DropdownsContainer = styled.div`
    margin: 20px 20px 0;

    /* first dropdown */
    > div:first-child {
        margin-bottom: 15px;
    }
`

export const DropdownContainer = styled.div`

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 24px;
        color: #64748B;
    }
`

export const DropdownMenu = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;

    background: #FFFFFF;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
    border-radius: 4px;
    padding: 10px;
    cursor: pointer;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 18px;
        color: #334155;
    }
`

export const MenuOptions = styled.div`
    position: absolute;
    bottom: 0;
    right: 22px;

    width: 285px;
    background: #0982B4;
    border-width: 0px 1px 1px 1px;
    border-style: solid;
    border-color: #9A9A9A;
    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.160784);
    padding: 7px 7px 12px;
    display: none;

    &.shown {
        display: block;
    }

    > p:not(:last-child) {
        margin-bottom: 5px;
    }

    > p {
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 22px;
        letter-spacing: 0.007px;
        color: #FFFFFF;
        cursor: pointer;

        &:hover {
            color: rgba(255, 255, 255, 0.8);
        }
    }
`

export const ShortNote = styled.div`
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-top: 10px;

    > label {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 24px;
        color: #64748B;
    }

    > input {
        background: #FFFFFF;
        border: 1px solid rgba(0, 0, 0, 0.05);
        box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
        border-radius: 4px;
        padding: 10px;

        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 18px;
        color: #334155;

        &:focus {
            outline: none;
        }
    }
`

export const ButtonsContainer = styled.div`
    width: calc(100% + 60px);
    height: 70px;
    transform: translateX(-30px);
    background: #E2E8F0;
    border-radius: 0px 0px 8px 8px;
    margin-top: 16px;

    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
`

export const RemoveButton = styled.button`
    width: 145px;
    height: 40px;
    background: #DC2626;
    border-radius: 4px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 20px;
    color: #FEF2F2;
`

export const CancelButton = styled(RemoveButton)`
    background: #FFFFFF;
    color: #64748B;
`