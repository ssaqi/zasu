import styled from "styled-components";


export const CardsStyled = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 290px);
  grid-gap: 35px;
`

export const CardStyled = styled.div`
  /* height: 423px; */
  height: 447px;
  background: #FFFFFF;
  border-radius: 10px;
  padding: 15px 5px;
`

export const CardTop = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 8px 0 10px;
`

export const LastOrdered = styled.p`
  display: flex;
  justify-content: space-between;
  align-items: center;

  background: #F8FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 10px;
  padding: 2px 10px;

  span:first-child {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 10px;
    margin-right: 3px;
  }

  a {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 10px;
    text-decoration: underline;
    color: #1E9ED4;
  }
`

export const Trash = styled.div`
  position: relative;
  cursor: pointer;

  > span {
    position: absolute;
    top: 28px;
    left: -50%;

    width: 40px;
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 9px;
    line-height: 9px;
    /* or 100% */
    text-align: center;
    letter-spacing: 0.0075px;
    color: #9A9A9A;
  }
`

export const Heart = styled(Trash)`
  > span {
    left: -30%;
  }
`

export const ProductImage = styled.div`
    display: flex;
    justify-content: center;
    margin-top: 20px;
    cursor: pointer;
`

export const ProductDesc = styled.div`
  display: flex;
  align-items: flex-end;
  margin-top: 15px;
  padding: 0 8px 0 12px;
  height: 42px;

  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  [title]:hover::after {
    content: attr(title);
    position: absolute;
    top: -100%;
    left: 0;
    font-weight: bolder;
  }

  > p {
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 12.8px;
    line-height: 20px;
    letter-spacing: 0.011px;
    color: #1495CA;
    cursor: pointer;
  }
`

export const OtherDetails = styled.div`
  height: 140px;
  margin-top: 12px;
  padding: 0 12px;
`

export const Supplier = styled.div`
  display: flex;
  justify-content: space-between;

  // supplier
  > p:first-child {
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 11px;
    line-height: 20px;
    /* or 182% */
    letter-spacing: 0.0075px;
    color: #9A9A9A;

    span:last-child {
      font-weight: 700;
      color: #3A3A3A;
      margin-left: 3px;
    }
  }

  // price
  > p:last-child {
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 700;
    font-size: 15px;
    line-height: 24px;
    /* or 160% */
    text-align: right;
    color: #3A3A3A;

    margin-top: -5px;
  }
`

export const MFR = styled.div`
  > span:first-child {
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 11px;
    line-height: 20px;
    /* or 182% */
    letter-spacing: 0.0075px;
    color: #9A9A9A;
  }

  > span:last-child {
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 11px;
    line-height: 20px;
    /* or 182% */
    letter-spacing: 0.0075px;
    font-weight: 700;
    color: #3A3A3A;
    margin-left: 3px;
  }
`

export const NickName = styled(MFR)`

`

export const Bottom = styled.div`
  margin-top: 10px;
  padding: 0 12px;
  display: flex;
  align-items: center;
  gap: 18px;
`

export const BlueButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;

  width: 142px;
  height: 36px;
  background: #1E9ED4;
  border-radius: 10px;

  > span {
    margin-left: 7px;
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #F5FCFF;
  }
`

export const GreenButton = styled(BlueButton)`
  background: #14CA76;
`

// export const Quantity = styled.div`
//   display: flex;
//   align-items: center;
//   justify-content: space-between;

//   width: 84px;
//   height: 36px;
//   background: #FFFFFF;
//   border: 1px solid #E2E8F0;
//   border-radius: 10px;

//     > p, div {
//         display: flex;
//         align-items: center;
//         justify-content: center;
//     }
    
//     /* quantity */
//     > p {
//         text-align: center;
//         width: 38%;
//         height: 36px;
//         color: #64748B;
//     }

//     /* minus icon */
//     > div:first-child {
//         width: 31%;
//         height: 36px;
//         border-right: 1px solid #E2E8F0;
//         cursor: pointer;
//     }

//     /* plus icon */
//     > div:last-child {
//         width: 31%;
//         height: 36px;
//         border-left: 1px solid #E2E8F0;
//         cursor: pointer;
//     }
// `

export const Quantity = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;

    width: 84px;
    height: 36px;
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 4px;

    > div {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* minus icon */
    > div:nth-child(1) {
        width: 31%;
        height: 100%;
        border-right: 1px solid #E2E8F0;
        cursor: pointer;
    }

    /* quantity */
    > div:nth-child(2) {
        width: 38%;
        height: 100%;

        > input {
           width: 100%;
            height: 100%;
            padding: 0;
            text-align: center;
            border: none;
            font-size: 15px;

            :focus {
              outline: none;
            }
        }
    }

    /* plus icon */
    > div:nth-child(3) {
        width: 31%;
        height: 100%;
        border-left: 1px solid #E2E8F0;
        cursor: pointer;
    }
`

export const ModalContainer = styled.div`
  
`
