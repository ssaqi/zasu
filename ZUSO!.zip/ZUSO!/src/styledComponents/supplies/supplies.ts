import styled from 'styled-components';


export const PageContainer = styled.div`
  background: #F1F5F9;
  display: flex;
  flex-direction: column;
`

export const ContentWrapper = styled.div`
  padding: 2rem 4rem;
`

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 0rem 5rem 2rem 5rem;
  background: #F1F5F9;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0rem 1rem 2rem 1rem;
  }
`

export const Header = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  margin-bottom: 10px;

  > div {
    display: flex;
    align-items: center;
    gap: 17px;
  }
`

export const MainHeading = styled.p`
  color: #334155;
  font-size: 30px;
  font-weight: 600;
`

export const SortBy = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  position: relative;

  padding: 2px 10px;
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;

  // sort icon
  img:first-child {
    width: 16px;
    height: 14.22px;
  }

  > p:nth-child(2) {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 36px;
    /* identical to box height, or 257% */
    color: #64748B;
    margin-left: -5px;
    margin-right: 10px;
  }

  > p:nth-child(3) {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 36px;
    text-align: right;
    color: #64748B;
    margin-right: 6px;
    cursor: pointer;
  }

  // chevron down
  img:nth-child(4) {
      margin-right: 8px;
      /* cursor: pointer; */
  }
`

export const SortByDropdown = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 10;

  width: 100%;
  height: 205px;
  padding: 10px 25px;
  background: #FFFFFF;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 2px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
  display: none;

  &.is-open {
    display: block;
  }

  > p:not(:last-child) {
    margin-bottom: 15px;
  }

  > p {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    /* line-height: 36px; */
    text-align: right;
    color: #64748B;
    cursor: pointer;
  }
`

export const AddSpecialOrderButton = styled.button`
  padding: 0.5rem 1.5rem;
  color: white;
  background-color: #1E9ED4;
  border-radius: 4px;
  cursor: pointer;
`

export const MainHeadingHighlighted = styled.a`
  color: #47BAEB;
  font-size: 30px;
  font-weight: 600;
`

export const MainHeadingMuted = styled.span`
  color: #CBD5E1;
  font-size: 30px;
  font-weight: 600;
`

export const Main = styled.div`
  display: grid;
  grid-template-columns: 250px auto;
  gap: 30px;
  margin-top: 25px;
`

export const FirstRow = styled.div`
  display: flex; 
  flex-direction: row;
  justify-content: space-between;
`

export const FirstRowLeft = styled.div`
  display: flex;
  flex-direction: column;
  max-width: 40%;
  justify-content: flex-start;
`

export const FirstRowRight = styled.div`
  display: flex;
  flex-direction: column;
  max-width: 40%;
  justify-content: flex-start;
`

export const AccountInfoContainer = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-top: 1rem;
`

export const AccountInfoHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AccountInfoHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const AccountInfoBody = styled.div`
  display: flex;
  flex-direction: column;
  background: white;
  padding: 1.5rem;
  justify-content: center;
  align-items: center;
`

export const AccountInfoName = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 22px;
  color: #475569;
`

export const AccountInfoEmail = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 18px;
  text-decoration-line: underline;
  color: #475569;
`

export const AccountInfoPhoneNumber = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 19px;
  color: #94A3B8;
`

export const BottomRow = styled.div`
  display: flex;
  flex-direction: row;
  gap: 2rem;
`

export const Icon = styled.img`
  width: 10px;
  height: 10px;
`

export const AccountInfoButtons = styled.button`
  font-style: normal;
  font-weight: 600;
  font-size: 12px;
  line-height: 18px;
  color: #1E9ED4;
`


