import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 0rem 5rem 2rem 5rem;
  background: #F1F5F9;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0rem 1rem 2rem 1rem;
  }
`

export const Header = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  margin-bottom: 10px;
`

export const MainHeading = styled.p`
  color: #334155;
  font-size: 35px;
  font-weight: 600;
`

export const FirstRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 100%;

  @media (max-width: 1024px) {
    justify-content: space-evenly;
  }
`

export const FirstRowLeft = styled.div`
  display: flex;
  flex-direction: column;
  width: 42%;
  justify-content: flex-start;

  @media (max-width: 1024px) {
    //margin-top: 10px;
  }
`

export const FirstRowRight = styled.div`
  display: flex;
  flex-direction: column;
  width: 55%;
  justify-content: flex-start;

  @media (max-width: 1024px) {
    //margin-top: 10px;
  }
`

export const AccountInfoContainer = styled.div`
  display: flex;
  width: 100%;
  text-align: left;
  flex-direction: column;
  //margin-top: 1rem;
`

export const AccountInfoHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AccountInfoTopHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #334155;
  margin-bottom: 1rem;
`

export const AccountInfoHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 12px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #94A3B8;
  padding-left: 1.5rem;
`

export const AccountInfoBody = styled.div`
  display: flex;
  flex-direction: column;
  background: white;
  padding: 2rem;
  justify-content: center;
  align-items: flex-start;
`

export const Row = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-bottom: 10px;
`

export const Headings = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 19px;
  color: #707070;
  margin-bottom: 3px;
`

export const SelectDistributor = styled.select`
  padding: 0.5rem;
  font-size: 14px;
  width: 100%;
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  cursor: pointer;

  :active {
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  }
`

export const SaveButtonContainer = styled.div`
  display: flex;
  width: 100%;
  background: white;
  padding: 1rem;
  border-bottom-right-radius: 4px;
  border-bottom-left-radius: 4px;
`

export const SaveButton = styled.button`
  background: #1E9ED4;
  border-radius: 4px;
  padding: 0.5rem 1.2rem;
  color: white;
  margin-left: 10px;
  max-width: 300px;
`

export const AccountInfoAddress = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #64748B;
  margin-top: 0.5rem;
`


export const ChoosePageSelectOptions = styled.option`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  cursor: pointer;
`

export const SaveLandingPageButton = styled.button`
  background: #1E9ED4;
  border-radius: 4px;
  padding: 0.5rem 2rem;
  color: #F5FCFF;
`

export const BottomRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 2rem;
  margin-top: 1rem;
`

export const Icon = styled.img`
  width: 15px;
  height: 15px;
`

export const SecondRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  //align-items: center;
  width: 100%;
  margin-top: 2rem;

  @media (max-width: 1024px) {
    flex-direction: column;
  }
`

export const SecondRowLeft = styled.div`
  display: flex;
  flex-direction: column;
  width: 47%;
  justify-content: flex-start;
  margin-top: 2rem;
  min-width: 350px;
`

export const SecondRowRight = styled.div`
  display: flex;
  flex-direction: row;
  width: 47%;
  background: white;
  margin-top: 4rem;
`


export const SupplierAccountsTable = styled.table`
  //display: flex;
  width: 100%;
  //text-align: left;
  //flex-direction: column;
`

export const SupplierAccountsHeader = styled.div`
  display: flex;
  flex-direction: row;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  justify-content: space-between;
  padding: 1rem;
`

export const SupplierAccountsTableRows = styled.tr<{backgroundColor: string}>`
  //display: flex;
  //flex-direction: row;
  width: 100%;
  background: ${props => props.backgroundColor};
  //justify-content: space-between;
`

export const SupplierAccountsTableDefinitions = styled.td`
  padding: 0.7rem 0.7rem;
`

export const SupplierAccountTableHeadings = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 11px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #505050;
`

export const SupplierAccountNames = styled.p`
  font-style: normal;
  font-weight: 700;
  font-size: 14px;
  line-height: 15px;
  display: flex;
  align-items: center;
  color: #707070;
`

export const SupplierAccountInput = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  font-size: 12px;
  padding: 0.3rem 0.5rem;
`

export const AccountInfoButtons = styled.button`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #1E9ED4;
  margin-left: -20px;
`




