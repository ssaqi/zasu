import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 0rem 5rem 2rem 5rem;
  background: #F1F5F9;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0rem 1rem 2rem 1rem;
  }
`

export const Header = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  margin-bottom: 10px;
`

export const MainHeading = styled.p`
  color: #334155;
  font-size: 35px;
  font-weight: 600;
`

export const MainHeadingHighlighted = styled.a`
  color: #47BAEB;
  font-size: 30px;
  font-weight: 600;
`

export const MainHeadingMuted = styled.span`
  color: #CBD5E1;
  font-size: 30px;
  font-weight: 600;
`

export const FirstRow = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;

  @media (max-width: 1024px) {
    justify-content: space-evenly;
  }
`

export const FirstRowLeft = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 45%;
  justify-content: flex-start;

  @media (max-width: 1024px) {
    //margin-top: 10px;
  }
`

export const FirstRowRight = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 45%;
  justify-content: flex-start;
  margin-top: 1rem;

  @media (max-width: 1024px) {
    margin-top: 10px;
  }
`

export const AccountInfoContainer = styled.div`
  display: flex;
  width: 100%;
  text-align: left;
  flex-direction: column;
  margin-top: 1rem;
`

export const AccountInfoHeadingContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  //justify-content: space-between;
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AvatarHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
`

export const AvatarHeading = styled.p`
  font-size: 20px;
  font-weight: 600;
  font-style: normal;
  color: #475569;
`

export const AvatarBody = styled.div`
  display: flex;
  flex-direction: row;
  background: white;
  padding: 2.5rem;
  justify-content: space-around;
  align-items: center;
`

export const AvatarBodyWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border: 1px dashed #E2E8F0;
  border-radius: 4px;
  padding: 3rem;
`

export const AvatarInput = styled.input`
  display: none;
`

export const AvatarImage = styled.img`
  border-radius: 50%;
  max-width: 350px;
`

export const AvatarImageIcon = styled.img`
  width: 20px;
  height: 20px;
`

export const ClickHereSpan = styled.span`
  color: #47BAEB;
  cursor: pointer;
`

export const AvatarTitle = styled.p`
  color: #94A3B8;
`

export const AccountInfoTopHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #334155;
  align-self: center;
`

export const AccountInfoHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 12px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #94A3B8;
  padding-left: 1.5rem;
`

export const AccountInfoBody = styled.div`
  display: flex;
  flex-direction: row;
  background: white;
  padding: 1rem;
  justify-content: space-between;
  align-items: flex-start;
`

export const ChooseLandingPageContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`

export const ChoosePageSelect = styled.select`
  padding: 0.5rem;
  font-size: 14px;
  width: 250px;
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  cursor: pointer;

  :active {
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  }
`

export const ChoosePageSelectOptions = styled.option`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  cursor: pointer;
`

export const SaveLandingPageButton = styled.button`
  background: #1E9ED4;
  border-radius: 4px;
  padding: 0.5rem 2rem;
  color: #F5FCFF;
`

export const AccountInfoName = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 22px;
  color: #475569;
`

export const AccountInfoEmail = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 18px;
  text-decoration-line: underline;
  color: #475569;
  margin-top: 0.5rem;
`

export const AccountInfoPhoneNumber = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 19px;
  color: #94A3B8;
  margin-top: 0.5rem;
`

export const BottomRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 2rem;
  margin-top: 1rem;
`

export const Icon = styled.img`
  width: 15px;
  height: 15px;
`

export const AccountInfoButtons = styled.button`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #1E9ED4;
  margin-left: -20px;
`

export const SecondRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  //align-items: center;
  width: 100%;
  margin-top: 2rem;

  @media (max-width: 1024px) {
    flex-direction: column;
  }
`

export const SecondRowLeft = styled.div`
  display: flex;
  flex-direction: column;
  width: 30%;
  justify-content: flex-start;
  margin-top: 2rem;
  min-width: 350px;
`

export const SecondRowRight = styled.div`
  display: flex;
  flex-direction: row;
  width: 65%;
  background: white;
  margin-top: 4rem;
`


export const PlanInfoContainer = styled.div`
  display: flex;
  width: 100%;
  text-align: left;
  flex-direction: column;
  margin-top: 1rem;
`

export const PlanInfoHeadingContainer = styled.div`
  width: 100%;
  background: #F8FAFC;
  border-radius: 4px 4px 0px 0px;
  padding: 0.5rem;
  display: flex;
  justify-content: space-between;
`

export const PlanInfoTopHeading = styled.p`
  font-style: normal;
  white-space: nowrap;
  font-weight: 600;
  font-size: 20px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #334155;
`

export const PlanInfoHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 18px;
  color: #475569;
  padding-left: 1.5rem;
`

export const PlanInfoTopRightHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  text-align: right;
  color: #F87171;
  padding-right: 1rem;
`

export const PlanInfoBody = styled.div`
  display: flex;
  flex-direction: column;
  background: white;
  padding: 2rem;
  justify-content: center;
  align-items: flex-start;
`

export const PlanInfoHeadings = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 12px;
  line-height: 18px;
  margin-top: 1rem;
  color: #94A3B8;
`

export const PlanInfoValues = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 18px;
  margin-top: 0.3rem;
  color: #475569;
`

export const PlanInfoValueMuted = styled.p`
  font-weight: 600;
  font-size: 12px;
  line-height: 18px;
  color: #94A3B8;
`

export const PlanInfoStatus = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #22C55E;
`

export const CancelPlanButton = styled.button`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #94A3B8;
  margin-left: -20px;
`

export const AnnualPlanInfoContainer = styled.div`
  display: flex;
  flex-direction: column;
  padding: 1.5rem 2rem;
  min-width: 500px;

  @media (max-width: 1024px) {
    padding: 1.5rem 1rem;
  }
`

export const AnnualPlanInfoHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 18px;
  color: #334155;
`

export const AnnualPlanInfoSubHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 24px;
  color: #334155;
  margin-top: 20px;

  @media (max-width: 1024px) {
    margin-top: 10px;
  }
`

export const AnnualPlanInfoDescription = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #64748B;
  margin-top: 15px;
  @media (max-width: 1024px) {
    margin-top: 10px;
  }
`

export const AnnualPlanPointersContainer = styled.span`
  display: flex;
  flex-direction: row;
  align-items: center;
`

export const AnnualPlanInfoCheckmark = styled.img`
  width: 15px;
  height: 15px;
`

export const AnnualPlanInfoPointers = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 24px;
  color: #64748B;
  margin-left: 10px;
  margin-top: 5px;
  @media (max-width: 1024px) {
    //margin-top: 2px;
  }
`

export const ProfileRows = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
  margin: 0.5rem;
`

export const ProfileInputLabel = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 18px;
  color: #64748B;
`

export const CheckboxLabel = styled.p`
  font-style: normal;
  font-weight: 600;
  margin-left: 10px;
  font-size: 14px;
  line-height: 18px;
  color: #64748B;
`

export const AnnualPlanImage = styled.img`
  width: 400px;
  height: 350px;

  @media (max-width: 1024px) {
    width: 350px;
    height: 350px;
    margin-left: -25px;
  }
`

export const SwitchNowButton = styled.button`
  background: #DC2626;
  border-radius: 4px;
  color: white;
  width: 140px;
  height: 35px;
  margin-top: 20px;
`

export const ProfileInputContainer = styled.div`
  display: flex;
  flex-direction: column;
`

export const ProfileInput = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  min-width: 300px;
  padding: 0.2rem;
  margin-top: 5px;

  @media only screen and (max-width: 1025px) {
    min-width: 250px;
  }
`

export const ProfileInputError = styled.span`
  color: red;
  display: flex;
  justify-content: flex-end;
  font-size: 8px;
`

export const ProfileDescriptionInput = styled.textarea`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  min-width: 300px;
  min-height: 180px;
  padding: 0.2rem;
  margin-top: 1rem;

  @media only screen and (max-width: 1025px) {
    min-width: 250px;
  }
`

export const UpdateAddressCheckbox = styled.input`
  width: 20px;
  height: 20px;
  margin-left: 2rem;
  background: #1E9ED4;
  border-radius: 4px;
  cursor: pointer;
  padding: 0.2rem 1rem;
  //color: white;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  color: #64748B;

`

export const Select = styled.select`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 300px;
  height: 30px;
  //padding: 15px 5px;
  outline: none;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 298px;
  }
  
  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
  }
`
