import styled from "styled-components";

export const Container = styled.div`

  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  margin: auto;
  background-color: #E2E8F0;
  padding: 1rem;
`;

export const Column = styled.div`
  display: flex;
  position: relative;
  margin: 0.270rem;
`;

export const SearchInput = styled.input`

display: flex;
flex-direction: row;
align-items: flex-start;
text-align: center;
padding-top: 0.40rem;
padding-bottom: 0.40rem;
padding-left: 1rem;
padding-right: 12rem;
background: #FFFFFF;
border: 1px solid rgba(0, 0, 0, 0.05);
box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
border-radius: 5px;

`;

export const Dropdown = styled.select`

display: flex;
flex-direction: row;
align-items: flex-start;
text-align: start;
padding-top: 0.40rem;
padding-bottom: 0.40rem;
padding-left: 1rem;
padding-right: 8rem;
background: #FFFFFF;
border: 1px solid rgba(0, 0, 0, 0.05);
box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
border-radius: 5px;
`;

export const Button = styled.button`

padding-top: 0.40rem;
padding-bottom: 0.40rem;
padding-left: 4rem;
padding-right: 4rem;
background-color: #1E9ED4;
color: #fff;
border: none;
border-radius: 4px;
cursor: pointer;
`;
