import styled from 'styled-components';
import background from '../../public/Intro-Background.svg';

export const HomeContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: baseline;
  min-height: 100vh;
  width: 100%;

  @media only screen and (max-width: 1024px) {
    justify-content: space-between;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  
`


export const IntroContainer = styled.div`
  width: 60%;
  min-height: 100vh;
  padding: 0rem 3rem 0rem 12rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-image: url("${background.src}");
  background-size: cover;

  @media only screen and (max-width: 1024px) {
    padding: 0rem 0.25rem 0rem 5rem;
    width: 70%;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    width: 100%;
    padding: 2rem 0rem 2rem 0rem;
    flex-direction: column;
    background: #1E9ED4;
  }
`

export const FeaturesContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: baseline;
  gap: 1.5rem;

  @media only screen and (max-width: 1024px) {
    align-items: baseline;
    padding-right: 1rem;
  }
  
  @media only screen and (max-width: 500px) { // for mobile 
    flex-direction: column;
    padding: 2rem;
  }
`

export const Image = styled.img`
  width: 350px;
  margin-bottom: 15px;
  @media only screen and (max-width: 1025px) { // for mobile 
    width: 250px;
    margin-bottom: 0px;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    width: 350px;
  }

`

export const Logo = styled.img`
  width: 180px;
  position: relative;
  top: -35px;

  @media only screen and (max-width: 1025px) { // for mobile 
    width: 120px;
    top: 10px;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    width: 200px;
    position: inherit;
    margin-top: 30px;
  }

`

export const Container = styled.div`
  width: 40%;
  //height: 100vh;
  padding: 0rem 1.25rem 0rem 1.25rem;

  @media only screen and (max-width: 1024px) {
    padding: 0rem 0rem 0rem 0.25rem;
    width: 30%;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    width: 100%;
    padding: 1.25rem;
  }
  
`

export const LogoContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  padding-top: 0rem;
  padding-left: 1.25rem;
  margin-top: -25px;
`

export const FormWrapper = styled.div`
  
  padding-top: 7rem;
  padding-left: 1.25rem;

  @media only screen and (max-width: 1024px) {
    padding-left: 0.75rem;
    padding-top: 2rem;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    padding-top: 3rem;
    padding-bottom: 3rem;
    padding-left: 1.5rem;
    //display: flex;
    //justify-content: center;
    //align-items: center;
    //flex-direction: column;
    //text-align: left;
  }
  
`

export const LoginButton = styled.button`
  color: white;
  font-weight: 700;
  cursor: pointer;
  padding: 10px;
  background: #1E9ED4;
  border-radius: 4px;
  width: 300px;
  transition-duration: 1s;

  @media only screen and (max-width: 1024px) {
    width: 250px;
    font-size: 12px;
  }
  
  :hover {
    background: #015F87;
  }
`

export const LoginHeading = styled.h2`
  font-size: 20px;
  white-space: nowrap;
  margin-bottom: 0px;

  @media only screen and (max-width: 1024px) {
    font-size: 18px;
  }
`

export const LoginSubHeading = styled.h2`
  font-size: 18px;
  white-space: nowrap;
  @media only screen and (max-width: 1024px) {
    font-size: 14px;
    margin-bottom: 15px;
  }
`

export const RememberMeContainer = styled.div`
  display: flex;
  justify-content: space-between;
  width: 300px;
  margin-bottom: 1.25rem;
  @media only screen and (max-width: 1024px) {
    width: 250px;
    margin-bottom: 1rem;
  }
`
