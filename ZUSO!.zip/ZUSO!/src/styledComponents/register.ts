import styled from 'styled-components';

export const Logo = styled.img`
  width: 180px;
  
  @media only screen and (max-width: 1025px) { // for mobile 
    width: 120px;
  }

  @media only screen and (max-width: 500px) { // for mobile 
    width: 200px;
  }

`


export const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  padding-bottom: 5rem;
  @media only screen and (max-width: 1024px) {
  }

  @media only screen and (max-width: 500px) { // for mobile 
    flex-direction: column-reverse;
  }

`

export const FormPadding = styled.div`
  width: 50%;
  padding: 2rem;
  @media only screen and (max-width: 1024px) {
  }

  @media only screen and (max-width: 500px) { // for mobile
    padding: 2rem;
    width: 100%;
  }
`

export const NavWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0rem 2rem 2rem 2rem;
  flex-direction: row;
`

export const NavContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  white-space: nowrap;
  padding: 10px;
`

export const Numbers = styled.span`
  color: #1E9ED4;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: bolder;
  background: white;
  width: 30px;
  height: 30px;
  border-radius: 30px;

  @media only screen and (max-width: 500px) {
    width: 20px;
    height: 20px;
    border-radius: 20px;
  }
`

export const NumbersMuted = styled.span`
  color: #1E9ED4;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: bolder;
  background: #72CDF3;
  width: 30px;
  height: 30px;
  border-radius: 30px;
`

export const ArrowIcon = styled.img`
  width: 20px;
`

export const BackContainer = styled.div`
  display: flex;
  padding: 0rem 2.5rem;

  @media only screen and (max-width: 500px) {
    padding: 0rem 0.5rem 0.5rem 2.5rem;
  }
`
