import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  background: #E2E8F0;
  padding: 1rem 5rem;
  gap: 3rem 5rem;
`

export const Headings = styled.p<{selectedColor: string}>`
  color: ${props => props.selectedColor};
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  cursor: pointer;
`
