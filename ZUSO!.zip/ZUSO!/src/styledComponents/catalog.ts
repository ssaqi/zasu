import styled from 'styled-components';

export const Container = styled.div`
  // display: flex;
  // flex-direction: row;
  // width: 1400px;
  // max-width: 1400px;
  // margin: 4rem 5rem 0 15rem;
  // font-family: 'SF Compact Display';
  // @media screen and (min-width: 1200px) {
  //   div {
  //     display: flex;
  //     flex-direction: row;
  //   }
  // }

  display: flex;
  flex-direction: row;

`

export const SideBar = styled.div`
  flex: 1;
  width: 20%;
  margin: 4rem 5rem 0 8rem;
`
export const CatalogSection = styled.div`
  flex: 4;
  width: 80%;
  margin: 4rem;
`
export const Row = styled.div`
  padding: 0.25rem;
  width: 100%;
  border-bottom: 1px solid #ddd;
  @media only screen and (max-width: 768px) {
    padding: 5px;
  }
`
export const RowContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 1rem 14rem 0 14rem;

  h1 {
    font-style: normal;
    font-weight: 600;
    font-size: 30px;
    color: #334155;
  }

  button {
    padding: 0.5rem;
    color: #FFF;
    background: #1E9ED4;
    border-radius: 4px;
  }

  button: hover {
    background: #fff;
    color: #1E9ED4;
  } a {
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: #64748B;
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 4px;
    padding: 0.6rem;
    margin-left: 1rem;
  }

  a:hover {
    color: #FFFF;
    background: #64748B;
  }
`
export const RowSideBar = styled.div`
  padding: 10px;
  width: 400px;
  border-bottom: 1px solid #ddd;
  @media only screen and (max-width: 768px) {
    padding: 5px;
  }
`

export const Table = styled.table`
  width: 1000px;
  max-height: 1044px;
  border-collapse: collapse;
  background: #F8FAFC;
  border-radius: 5px;
  border-spacing: 0;

  th:first-child {
    border-top-left-radius: 5px;
  }
  
  th:last-child {
    border-top-right-radius: 5px;
  }
`

export const Th = styled.th`
  color: #94A3B8;
  font-weight: bold;
  text-align: left;
  padding: 8px;
  background-color: #f2f2f2;
  height: 80px;
`

export const Td = styled.td`
  text-align: left;
  padding: 8px;
  border-bottom: 1px solid #ddd;

  h5 {
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 20px;
    display: flex;
    align-items: center;
    text-align: right;
    color: #F87171;
  }

  h4 {
    font-style: normal;
    font-weight: 500;
    font-size: 12px;
    line-height: 18px;
    color: #1E9ED4;
  }
`

export const Tr = styled.tr`
  &:nth-child(even) {
    background-color: #f2f2f2;
  }
`

export const TableContainer = styled.div`
  overflow-x: auto;
`


export const Span = styled.span`
  width: 272px;
  height: 36px;
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 18px;
  display: flex;
  align-items: center;
  color: #1E9ED4;
  order: 0;
  flex-grow: 0;
`
export const CategorySpan = styled.span`
  font-weight: 500;
  font-size: 12px;
  line-height: 18px;
  display: flex;
  align-items: center;
  color: #94A3B8;
  flex: none;
  order: 0;
  flex-grow: 0;

`
export const SkuSpan = styled.span`
  box-sizing: border-box;
  padding: 1px 5px;
  gap: 10px;
  width: 50px;
  left: 0px;
  top: 0%;
  bottom: 0%;
  background: #FEF2F2;
  border: 1px solid #FEE2E2;
  border-radius: 3px;
  align-items: center;
  color: #F87171;
  flex: none;
  order: 0;
  flex-grow: 0;
  font-style: normal;
  font-weight: 500;
  font-size: 10px;
`
export const Button = styled.button`
  background-color: #1E9ED4;
  color: white;
  border: none;
  padding: 0.75rem;
  margin: 1px;
  cursor: pointer;
  border-radius: 5px;
  display: flex;

  &:hover {
    background-color: #125E80;
  }

  img {
    margin: 0.25rem;
  }
`
export const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 84px;
  height: 36px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
`

export const ButtonQTY = styled.button`
  width: 28px;
  height: 36px;
  border: 2px solid #cbd5e1;
  font-size: 16px;
  font-weight: bold;
  color: #718096;
  background-color: #f7fafc;

  &:hover {
    background-color: #cbd5e1;
  }
`
export const Quantity = styled.span`
  width: 28px;
  height: 25px;
  display: flex;
  justify-content: center;
`
export const TrContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1.2rem;
`

export const ImageContainer = styled.div`
  padding-right: 0.25rem;
`

export const TextContainer = styled.div`
  flex: 1;
`

export const RowSpan = styled.span`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 17px;
  display: flex;
  align-items: center;
  color: #64748B;

`

export const PageItem = styled.span<{ active: boolean }>`
  cursor: pointer;
  padding: 8px;
  background-color: ${(props) => props.active ? "#4CAF50" : "#ddd"};
  color: ${(props) => (props.active ? "white" : "black")};
`

export const Select = styled.select`
  padding: 10px;
  gap: 10px;
  left: 0%;
  right: 0%;
  top: 0%;
  bottom: 0%;
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  align-items: flex-start;
`

export const PageList = styled.div`
  display: flex;
`

export const ColumnRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin: 0 5rem 0 0;
`;

export const ColumnLeft = styled.div`
  flex: 1;
  text-align: left;
  display: flex;
  margin-top: 0.5rem;
`;

export const ColumnRight = styled.div`
  flex: 0.15;
  text-align: right;
  display: flex;
  margin-top: 0.5rem;
`
