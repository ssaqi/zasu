import styled from "styled-components";


export const DashboardSectionsStyled = styled.div`
    padding: 0 100px;  
`

export const MainSection = styled.section`

    > h1 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 35px;
        line-height: 36px;
        color: #334155;
        margin-top: 50px;
        margin-bottom: 40px;
    }
`

export const MainCards = styled.div`
    display: grid;
    grid-template-columns: repeat(4, minmax(250px, 1fr));
    grid-gap: 25px;

    /* headings of first four cards */
   .large-font {
        font-size: 20px;
    } 

    /* rest of headings */
   .small-font {
        font-size: 16px;
    } 

    /* Technical Service and Parts */
    > div:nth-child(3) {
        h1.large-font {
            font-size: 18px;
            margin-top: 2px;
        }
    }

    /* Request Product Info or Sample */
    > div:nth-child(10) {
        h1.small-font {
            font-size: 15px;
        }
    }
`

export const OrderSummaySection = styled.section`
    margin-top: 35px;

    > h1 {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 20px;
        line-height: 18px;
        color: #334155;
        margin-bottom: 20px;
    }

    /* cards container */
    > div {
        display: grid;
        grid-template-columns: repeat(4, minmax(250px, 1fr));
        grid-gap: 25px;
    }
`

export const SummaryCard = styled.div`
    background: #FFFFFF;
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
    border-radius: 4px;

    /* card header */
    > div:first-child {
        background: #F8FAFC;
        border-radius: 4px 4px 0px 0px;
        height: 40px;

        display: flex;
        justify-content: center;
        align-items: center;

        > h2 {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 700;
            font-size: 12px;
            line-height: 18px;
            text-align: center;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: #475569;
        }
    }

    /* card body */
    > div:last-child {
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;

        > p:first-child {
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: 700;
            font-size: 40px;
            line-height: 54px;
            text-align: center;
            color: #51A633;
            margin-bottom: 15px;
        }
    }
`

export const TotalQuantity = styled.p`
    position: absolute;
    bottom: 11px;

    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 700;
    font-size: 15px;
    line-height: 20px;
    text-align: center;
    color: #707070;
`

export const ComingSoon = styled.section`
    margin-top: 34px;

    > h2 {
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 20px;
        line-height: 20px;
        color: #64748B;
    }

    /* coming soon cards container */
    > div {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 25px;
        margin-top: 22px;
    }
`