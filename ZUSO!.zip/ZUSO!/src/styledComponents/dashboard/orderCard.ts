import styled from "styled-components";
import { MainCardStyled, ButtonContainer } from "./mainCard";


export const OrderCardStyled = styled(MainCardStyled)`

`

export const OrdersSection = styled.div`
    padding: 20px;

    > h1 {
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 20px;
        line-height: 20px;
        color: #334155;
    }

    > div {
        height: 190px
    }
`

export const OrderDetail = styled.p`
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-size: 14px;
    line-height: 18px;
    color: #64748B;
    margin-top: 14.3px;

    span {
        color: #1495CA;
        text-decoration-line: underline;
    }
`

export const OrderButtonContainer = styled(ButtonContainer)`

`

