import styled from "styled-components";


export const MainCardStyled = styled.div`
    background: #FFFFFF;
    box-shadow: 2px 2px 4px rgba(30, 41, 59, 0.1);
    border-radius: 4px;
`

export const CardBody = styled.div`
    height: 130px;
    padding: 0 15px;
`

export const ImageSection = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;

    margin-top: 20px;
    margin-bottom: 15px;
`

export const Title = styled.h1`
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 600;
    line-height: 20px;
    text-align: center;
    color: #334155;
    margin-bottom: 7px;
`

export const Description = styled.p`
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #64748B;
    margin-bottom: 50px;
`

export const ButtonContainer = styled.div`
    background: #F8FAFC;
    border-radius: 0px 0px 4px 4px;
    padding: 15px;

    > button {
        width: 100%;
        background: #1E9ED4;
        border-radius: 4px;
        padding: 10px;
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 500;
        font-size: 16px;
        line-height: 20px;
        color: #F5FCFF;
    }
`