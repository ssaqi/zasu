import styled from "styled-components";


export const ComingSoonCardStyled = styled.div`
    background: #F8FAFC;
    border-radius: 4px;
    height: 250px;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    > p {
        font-family: 'Roboto', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 16px;
        line-height: 20px;
        color: #94A3B8;
        margin-top: 10px;
    }
`