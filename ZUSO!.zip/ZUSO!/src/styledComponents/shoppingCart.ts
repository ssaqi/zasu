import styled from 'styled-components';

export const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  z-index: 100;
  right: 100px;
  width: 360px;
  /* height: 420px; */
  background: #122A4F;
  border-radius: 0px 0px 4px 4px;
  padding: 1rem;
`

export const RowContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin-bottom: 16px;
  width: 100%;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
  }
`

export const ColumnContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-right: 16px;
  width: 100%;
  @media (max-width: 768px) {
    margin-right: 0;
  }
`;

export const SKUContainer = styled.div`
  display: flex;
  flex-direction: row;
  font-size: 12px;
  margin-left: 5.15rem;
  margin-top: -1.8rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
  }
`
export const SKUFont = styled.h2`
  font-style: normal;
  font-weight: 500;
  font-size: 12px;
  line-height: 18px;
  color: #94A3B8;
  margin: 3px 0 10px;
`
export const SKUSpan = styled.span`
  font-style: normal;
  font-weight: 500;
  font-size: 10px;
  color: #FFFFFF;
  margin-left: 10px;
`

export const CartItemContainer = styled.div`
  overflow-y: auto;
  max-height: 278px;

  /* cart item */
  > div:not(:first-child) {
    margin-top: 30px;
  }

  &::-webkit-scrollbar {
      width: 5px;
  }

  &::-webkit-scrollbar-track {
      background: #122A4F;
  }

  &::-webkit-scrollbar-thumb {
      background: #64748B;
      border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb:hover {
      background: #555;
  }
`

export const CartHeading = styled.h1`
  font-style: normal;
  font-weight: 600;
  font-size: 12px;
  line-height: 14px;
  text-align: center;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #94A3B8;
`

export const CartImage = styled.img`
  left: 70.56%;
  right: 25%;
  top: 15.71%;
  bottom: 75.14%;
  border-radius: 4px;
  padding-right: 1.15rem;
`

export const ProductHeadingContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;

  > img {
    transform: translateX(10px);
  }
`

export const ProductHeading = styled.h2`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 16px;
  color: #1E9ED4;
`

export const CartPrice = styled.h2`
  font-style: normal;
  font-weight: 500;
  font-size: 12px;
  line-height: 18px;
  text-align: right;
  color: #FFFFFF;
`

export const QTYContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  font-size: 12px;
  margin-left: 5.15rem;
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
  }
`

export const QTY = styled.span`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 16px;
  padding-right: 0.25rem;
  color: #94A3B8;
`

export const QTYIcon = styled.span`
  width: 1.5rem;
  text-align: center;
  background: #17325E;
  border-radius: 4px;
  font-style: normal;
  font-weight: 500;
  color: #F8FAFC;
`

export const BtnMinus = styled.button`
  padding: 0 0.25rem 0 0.25rem;
  cursor: pointer;
  border: none;
`
export const ProductPrice = styled.span`
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  line-height: 16px;
  padding: 0 2rem 0 2rem;
  color: #F1F5F9;
`
export const Divider = styled.span`
  margin: 0.5rem 0 1.5rem 0;
  height: 1px;
  /* width: 340px; */
  width: calc(100% + 32px);
  transform: translateX(-16px);
  opacity: 1.5;
  border: 1px solid #0F172A;
`

export const LeftFloat = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 1rem;
  margin-top: 0.25rem;
  color: #FFF;

  h4 {
    color: #94A3B8;
    font-size: 1rem;
  }

  h5 {
    font-weight: 700;
    font-size: 1.2rem;
    line-height: 18px;
    color: #FFFFFF;
    margin-top: 0.75rem;
  }

  h6 {
    font-style: normal;
    font-weight: 700;
    font-size: 1.2rem;
    line-height: 18px;
    color: #EF4444;

  }
`;

export const GrandTotal = styled(LeftFloat)`
  margin-top: 10px;
  margin-bottom: 20px;

  h5 {
    margin-top: 0;
  }
`;

export const BottomDivider = styled(Divider)`
  margin: 0.5rem 0 0.5rem 0;
`

export const FloatContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

export const Button = styled.button`
  width: 48%;
  background-color: #47BAEB;
  padding: 0.25rem 1.25rem 0.25rem 1.25rem;
  border-radius: 4px;
`;


