import styled from 'styled-components';


export const MegaMenuStyled = styled.section`
  position: absolute;
  z-index: 100;

  display: flex;
  justify-content: space-between;

  width: calc(100% - 4.8rem);
  height: 360px;
  background-color: #122A4F;
  color: #47BAEB;
  margin-left: 77px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`

export const MenuLeftSection = styled.nav`
  width: calc(100% - 340px);
  display: grid;
  grid-template-columns: 17% 23% 30% 30%;
  align-items: start;
  margin-top: 26px;
  margin-left: 30px;
`

export const SuppliesColumn = styled.div`

  > h1 {
    font-family: 'Open Sans', sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 12px;
    line-height: 18px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #F8FAFC;
    margin-bottom: 12px;
  }

  /* links container */
  > div {
    display: flex;
    flex-direction: column;
    gap: 10px;

    > a {
      font-family: 'Open Sans', sans-serif;
      font-style: normal;
      font-weight: 400;
      font-size: 14px;
      line-height: 16px;
      color: #47BAEB;
    }
  }
`

export const ResearchColumn = styled(SuppliesColumn)`

`

export const EquipmentSupportColumn = styled.div`

`

export const EquipmentColumn = styled(SuppliesColumn)`
  margin-bottom: 44px;
`

export const SupportColumn = styled(SuppliesColumn)`

`

export const OfficeColumn = styled(SuppliesColumn)`

`

export const MenuBanner = styled.div`
  width: 340px;

  > img {
    width: 100%;
    height: 100%;
  }
`