import styled from 'styled-components';

export const FormContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  background: #30ACE0;
  padding: 3rem;
  border-radius: 5px;
  //width: 50%;
  margin-right: 30px;
  margin-left: 30px;
  gap: 0rem 1rem;
  @media only screen and (max-width: 1024px) {
    padding: 2rem 2.5rem;
    margin-right: 10px;
    margin-left: 10px;
  }

  @media only screen and (max-width: 500px) { // for mobile
    padding: 1rem;
    flex-direction: column;
    align-items: flex-start;
    background: none;
    margin-right: 0px;
    margin-left: 0px;
  }

`

export const FormHeading = styled.h2`
  color: white;
`

export const Row = styled.div`
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  column-gap: 0.35rem;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 300px;
  }
  
  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
    gap: 1.5rem;
  }
`

export const Form = styled.form`
  width: 400px;

  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
  }
`

export const Column = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 300px;
  }
`

export const Input = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 400px;
  height: 30px;
  padding: 15px 5px;
  outline: none;

  @media only screen and (max-width: 1024px) {
    width: 298px;
  }

  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
  }
`

export const InputHalf = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 195px;
  height: 30px;
  padding: 15px 5px;
  outline: none;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 145px;
  }

  @media only screen and (max-width: 500px) { // for mobile
    width: 136px;
  }
`

export const InputOneThird = styled.input`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 100px;
  height: 30px;
  padding: 15px 5px;
  outline: none;
`

export const Select = styled.select`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 400px;
  height: 30px;
  //padding: 15px 5px;
  outline: none;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 298px;
  }
  
  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
  }
`

export const SelectMonth = styled.select`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 70px;
  height: 30px;
  //padding: 15px 5px;
  outline: none;
  @media only screen and (max-width: 500px) { // for mobile
    width: 60px;
  }
`

export const SelectYear = styled.select`
  background: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 1px 1px 0px rgba(71, 85, 105, 0.03);
  border-radius: 4px;
  width: 90px;
  height: 30px;
  //padding: 15px 5px;
  outline: none;
  margin-left: 10px;
  @media only screen and (max-width: 500px) { // for mobile
    width: 100px;
    margin-left: 0px;
  }
`

export const Title = styled.span`
  color: #D7F2FE;
  font-size: 12px;
  white-space: nowrap;
  width: 200px;
  margin-top: 10px;
  margin-bottom: 5px;

  @media only screen and (max-width: 1025px) { // for mobile
    width: 157px;
  }

  @media only screen and (max-width: 500px) { // for mobile
    width: 127px;
  }
`

export const SubmitButton = styled.button`
  color: white;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  padding: 10px;
  background: #015F87;
  border-radius: 4px;
  width: 100%;
  transition-duration: 1s;
  margin-top: 15px;

  @media only screen and (max-width: 1024px) {
    width: 100%;
  }

  @media only screen and (max-width: 500px) { // for mobile
    width: 300px;
  }

  :hover {
    background: #17325E;
  }
`

export const ErrorMessage = styled.span`
    font-size: 10px;
    color: aquamarine;
`

