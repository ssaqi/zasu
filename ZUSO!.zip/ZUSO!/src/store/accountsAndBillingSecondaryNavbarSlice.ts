import {createAsyncThunk, createSlice} from "@reduxjs/toolkit";
import {AppState} from '@/store/store';

export interface navbarState {
    selectedTab: number;
}

const initialState: navbarState = {
    selectedTab: 1,
};

export const setSelectedTab = createAsyncThunk(
    "SET_SELECTED_TAB",
    (tab: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(tab)
        });
    }
);

export const accountsAndBillingSecondaryNavbarSlice = createSlice({
    name: "accountsAndBillingSecondaryNavbarState",
    initialState,
    reducers: {
        // clearFullState: () => initialState,
    },
    extraReducers: {
        [setSelectedTab.fulfilled.toString()]: (state, {payload}) => {
            state.selectedTab = payload
        },
    }
});

export const selectedTab = (state: AppState) => state.accountsAndBillingSecondaryNavbarState.selectedTab;
export const {} = accountsAndBillingSecondaryNavbarSlice.actions;
export default accountsAndBillingSecondaryNavbarSlice.reducer;
