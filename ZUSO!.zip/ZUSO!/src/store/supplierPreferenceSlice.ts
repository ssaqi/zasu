import {createAsyncThunk, createSlice} from "@reduxjs/toolkit";
import {AppState} from '@/store/store';
import {getSupplierAccountsList, getSuppliersList} from '@/store/fetch';
import {get} from '@/utils/fetch';

export interface ISupplierAccounts {
    name: string,
    accountNumber: number,
    username: string,
    password: string
}

export interface ISuppliersList {
    value: string,
    label: string,
}

export interface ISupplierPreferenceState {
    primary: string;
    secondary: string;
    additional: string[];
    directSuppliers: string[];
    selectedSuppliers: ISupplierAccounts[];
    allSuppliers: ISuppliersList[];
    supplierAccounts: ISupplierAccounts[],
    supplierAccountsList: ISupplierAccounts[],
    updateSupplierAccounts: boolean,
}

const initialState: ISupplierPreferenceState = {
    primary: '',
    secondary: '',
    additional: [],
    directSuppliers: [],
    selectedSuppliers: [],
    allSuppliers: [],
    supplierAccounts: [],
    supplierAccountsList: [],
    updateSupplierAccounts: false,
};

export const getSuppliers = createAsyncThunk(
    "GET_SUPPLIERS",
    () => {
        return new Promise<any>((resolve, reject) => {
            getSuppliersList().then((res: any) => {
                resolve(res)
            })
        });
    }
);

export const updateSelectedSuppliers = createAsyncThunk(
    "SUPPLIER_PREFERENCES/UPDATE_SELECTED_SUPPLIERS",
    (supplier,) => {
        return new Promise<any>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const setPrimarySupplier = createAsyncThunk(
    "SET_PRIMARY_SUPPLIER",
    (supplier: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const setSecondarySupplier = createAsyncThunk(
    "SET_SECONDARY_SUPPLIER",
    (supplier: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const setAdditionalSuppliers = createAsyncThunk(
    "SET_ADDITIONAL_SUPPLIERS",
    (supplier: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const setDirectSuppliers = createAsyncThunk(
    "SET_DIRECT_SUPPLIERS",
    (supplier: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const uploadSupplierAccounts = createAsyncThunk(
    "SET_SUPPLIER_ACCOUNTS",
    (supplier: any) => {
        return new Promise<void>((resolve, reject) => {
            resolve(supplier)
        });
    }
);

export const getSupplierAccounts = createAsyncThunk(
    "GET_SUPPLIER_ACCOUNTS",
    () => {
        return new Promise<void>((resolve, reject) => {
            getSupplierAccountsList().then((res: any) => resolve(res))
        });
    }
);

export const updateSupplierAccountValue = createAsyncThunk(
    "UPDATE_SUPPLIER_ACCOUNT_VALUES",
    ({id, valueName, value}: any) => {
        return new Promise<void>((resolve, reject) => {
            // @ts-ignore
            resolve({value: value, valueName: valueName, id: id})
        });
    }
);

export const supplierPreferencesSlice = createSlice({
    name: "supplierPreferenceState",
    initialState,
    reducers: {
        clearFullState: () => initialState,
    },
    extraReducers: {
        [setPrimarySupplier.fulfilled.toString()]: (state, {payload}) => {
            state.primary = payload
        },
        [updateSelectedSuppliers.fulfilled.toString()]: (state, {payload}) => {
            // console.log(payload, ' <<<<< payload in update selected supplier')
            state.selectedSuppliers = payload
        },
        [getSuppliers.fulfilled.toString()]: (state, {payload}) => {
            state.allSuppliers = payload
        },
        [setSecondarySupplier.fulfilled.toString()]: (state, {payload}) => {
            state.secondary = payload
        },
        [setAdditionalSuppliers.fulfilled.toString()]: (state, {payload}) => {
            state.additional = payload
        },
        [setDirectSuppliers.fulfilled.toString()]: (state, {payload}) => {
            state.directSuppliers = payload
        },
        [uploadSupplierAccounts.fulfilled.toString()]: (state, {payload}) => {
            state.updateSupplierAccounts = payload
        },
        [getSupplierAccounts.fulfilled.toString()]: (state, {payload}) => {
            // state.selectedSuppliers = payload
        },
        [updateSupplierAccountValue.fulfilled.toString()]: (state, {payload}) => {
            let tempSuppliers = state.selectedSuppliers
            for (const supplier of tempSuppliers) {
                if (supplier.name === payload.id) {
                    if (payload.valueName === 'accountNumber') {
                        supplier.accountNumber = payload.value
                    }
                    if (payload.valueName === 'username') {
                        supplier.username = payload.value
                    }
                    if (payload.valueName === 'password') {
                        supplier.password = payload.value
                    }
                }
            }
            state.selectedSuppliers = tempSuppliers
        }
    }
});

export const suppliersList = (state: AppState) => state.supplierPreferenceState.allSuppliers;
export const selectedSuppliersList = (state: AppState) => state.supplierPreferenceState.selectedSuppliers;
export const updateSupplierAccounts = (state: AppState) => state.supplierPreferenceState.updateSupplierAccounts;
export const supplierAccountsList = (state: AppState) => state.supplierPreferenceState.supplierAccountsList;
export const selectedPrimarySupplier = (state: AppState) => state.supplierPreferenceState.primary;
export const selectedSecondarySupplier = (state: AppState) => state.supplierPreferenceState.secondary;
export const selectedAdditionalSuppliers = (state: AppState) => state.supplierPreferenceState.additional;
export const selectedDirectSuppliers = (state: AppState) => state.supplierPreferenceState.directSuppliers;
export const {} = supplierPreferencesSlice.actions;
export default supplierPreferencesSlice.reducer;
