import {createAsyncThunk, createSlice} from "@reduxjs/toolkit";
import {AppState} from "./store";
import {get} from '@/utils/fetch';

// Type for our state
export interface IUserState {
    id: number;
    first_name: string;
    last_name: string;
    phone_number: string;
    position: string;
    info: string;
    email: string;
    username: string;
    profile_image: string;
    register_stage: number,
    company_name: string,
    is_owner: boolean,
    landing_page: string,
}

// Initial state
const initialState: IUserState = {
    id: 0,
    first_name: '',
    last_name: '',
    phone_number: '',
    position: '',
    info: '',
    email: '',
    username: '',
    profile_image: '',
    register_stage: 0,
    company_name: '',
    is_owner: false,
    landing_page: '',
};

export const getUserAccountDetails = createAsyncThunk(
    "GET_ACCOUNT_DETAILS",
    (thunkAPI) => {
        return new Promise<void>((resolve, reject) => {
            get('user')
                .then((data: any) => {
                    resolve(data)
                }).catch((err: any) => {
                reject(err)
            })
        });
    }
);

// Actual Slice
export const accountSlice = createSlice({
    name: "account",
    initialState,
    reducers: {
        // clearFullState: () => initialState,
    },
    extraReducers: {
        [getUserAccountDetails.fulfilled.toString()]: (state, {payload}) => {
            state.id = payload.id;
            state.first_name = payload.first_name;
            state.last_name = payload.last_name;
            state.phone_number = payload.phone_number;
            state.position = payload.position;
            state.info = payload.info;
            state.email = payload.email;
            state.username = payload.username;
            state.profile_image = payload.profile_image;
            state.register_stage = payload.register_stage;
            state.company_name = payload.company_name;
            state.is_owner = payload.is_owner;
            state.landing_page = payload.landing_page;
        },
    }
});

export const {} = accountSlice.actions;

export const selectAccountState = (state: AppState) => state.account;

export default accountSlice.reducer;
