import { PayloadAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { AppState } from "./store";
import { get, post } from "@/utils/fetch";

export interface IProduct {
  id: number;
  tags: string[];
  lastOrdered: string;
  name: string;
  image: string;
  description: string;
  shortDescription: string;
  mpn: string;
  productSpecs: string;
  weight: string;
  size: string;
  composition: string;
  brand: string;
  category: string;
  subCategory: string;
  subSubCategory: string;
  shadeType: string;
  dataSheetPdf: string;
  price: number;
  supplier: string;
  supplierSku: string;
  mfr: string;
  nickname: string[];
  cartIcon: string;
  inCart: string;
  productQuantity: string;
  caseQuantity: string;
  quantity: number;
  minus: string;
  plus: string;
  trashIcon: {
    icon: string;
    desc: string;
  };
  heartIcon: {
    icon: string;
    desc: string;
  };
}

export interface IProducts {
  products: IProduct[];
  categories: ICategory[];
  categoryCount: number;
  product: IProduct;
  //   product: {
  //     lastOrdered: string;
  //     name: string;
  //     image: string;
  //     description: string;
  //     price: string;
  //     supplier: string;
  //     mfr: string;
  //     nickname: string;
  //     cartIcon: string;
  //     inCart: string;
  //     quantity: string;
  //     minus: string;
  //     plus: string;
  //     trashIcon: {
  //       icon: string;
  //       desc: string;
  //     };
  //     heartIcon: {
  //       icon: string;
  //       desc: string;
  //     };
  //   };
  search: {
    query: string[];
    filterBy: string[];
  };
  count: {
    total: number;
  };
}

const initialState: IProducts = {
  products: [],
  categories: [],
  categoryCount: 0,
  search: {
    query: [],
    filterBy: [],
  },
  count: {
    total: 0,
  },
  product: {
    tags: [],
    lastOrdered: "",
    name: "",
    image: "",
    description: "",
    price: 0,
    supplier: "",
    mfr: "",
    nickname: [],
    cartIcon: "",
    inCart: "",
    quantity: 0,
    minus: "",
    plus: "",
    trashIcon: {
      icon: "",
      desc: "",
    },
    heartIcon: {
      icon: "",
      desc: "",
    },
    id: 0,
    shortDescription: "",
    mpn: "",
    productSpecs: "",
    weight: "",
    size: "",
    composition: "",
    brand: "",
    category: "",
    subCategory: "",
    subSubCategory: "",
    shadeType: "",
    dataSheetPdf: "",
    supplierSku: "",
    productQuantity: "",
    caseQuantity: "",
  },
};

export interface IProductResponse {
  success: boolean;
  data: IProduct[];
  count: number;
}

export const getProducts = createAsyncThunk<IProductResponse>(
  "GET_PRODUCTS",
  async ({ limit, offset, orderBy, filterBy }: any) => {
    return new Promise((resolve, reject) => {
      const body = {
        limit: limit,
        offset: offset,
        orderBy: orderBy,
        filterBy: filterBy,
      };
      post("users/product/listAll", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export interface ICategory {
  name: string;
}

export interface ICategoryResponse {
  success: boolean;
  data: ICategory[];
  count: number;
}

export const getCategories = createAsyncThunk(
  "GET_CATEGORIES",
  ({ showMore }: any) => {
    return new Promise<ICategoryResponse>((resolve, reject) => {
      const body = {
        showMore: showMore,
        // Boolean default 10, else on showMore or ShowLess events
      };
      post("users/product/categories", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

interface IGetProductResponse {
  success: boolean;
  data: IProduct;
}
interface IAddTagResponse {
  success: boolean;
  data: { product: number; tag: string; company: number };
}

export const addProductTag = createAsyncThunk(
  "GET_PRODUCT_TAG",
  ({ productId, tag }: any) => {
    return new Promise<IAddTagResponse>((resolve, reject) => {
      const body = {
        product_id: productId,
        tag: tag,
      };
      post("users/product/addProductTag", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const removeProductTag = createAsyncThunk(
  "REMOVE_PRODUCT_TAG",
  ({ productId, tag }: any) => {
    return new Promise<IAddTagResponse>((resolve, reject) => {
      const body = {
        product_id: productId,
        tag: tag,
      };
      post("users/product/removeProductTag", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const getProduct = createAsyncThunk(
  "GET_SINGLE_PRODUCT",
  (query: string, thunkAPI) => {
    return new Promise<IGetProductResponse>((resolve, reject) => {
      get("users/product/listOne?name=" + query)
        .then((response: any) => {
          if (response.success) {
            resolve(response.data);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const searchProducts = createAsyncThunk(
  "SEARCH_PRODUCTS",
  ({ limit, offset, orderBy, filterBy, query }: any, thunkAPI) => {
    return new Promise<IProductResponse>((resolve, reject) => {
      const body = {
        limit: limit,
        offset: offset,
        orderBy: orderBy,
        filterBy: filterBy,
        queries: query,
      };
      post("users/product/search", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const setSearchQueryProducts = createAsyncThunk(
  "SET_SEARCH_QUERY_PRODUCTS",
  (query: string) => {
    return new Promise<string>((resolve, reject) => {
      // @ts-ignore
      resolve(query);
    });
  }
);

export const removeSearchQueryProducts = createAsyncThunk(
  "REMOVE_SEARCH_QUERY_PRODUCTS",
  (query: string) => {
    return new Promise<string>((resolve, reject) => {
      // @ts-ignore
      resolve(query);
    });
  }
);

export const productsSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    clearFullState: () => initialState,
    addfilterBy: (state, { payload }) => {
      state.search.filterBy = [...state.search.filterBy, payload];
    },
    removeFilterBy: (state, { payload }) => {
      state.search.filterBy = state.search.filterBy.filter(
        (q) => q !== payload
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getProducts.fulfilled, (state, { payload }) => {
        state.products = payload.data;
        state.count.total = payload.count;
      })
      .addCase(getProduct.fulfilled, (state, { payload }) => {
        state.product = payload.data;
      })
      .addCase(searchProducts.fulfilled, (state, { payload }) => {
        state.products = payload.data;
        state.count.total = payload.count;
      })
      .addCase(setSearchQueryProducts.fulfilled, (state, { payload }) => {
        state.search.query = [...state.search.query, payload];
      })
      .addCase(removeSearchQueryProducts.fulfilled, (state, { payload }) => {
        state.search.query = state.search.query.filter((q) => q !== payload);
      })
      .addCase(getCategories.fulfilled, (state, { payload }) => {
        state.categories = payload.data;
        state.categoryCount = payload.count;
      })
      .addCase(addProductTag.fulfilled, (state, { payload }) => {
        state.products = [
          ...state.products.map((product) => {
            if (product.id === payload.data.product) {
              return {
                ...product,
                nickname: [...product.nickname, payload.data.tag],
              };
            }
            return product;
          })
        ]
        
      })
      .addCase(removeProductTag.fulfilled, (state, { payload }) => {
        state.products = [
          ...state.products.map((product) => {
            if (product.id === payload.data.product) {
              return {
                ...product,
                nickname: product.nickname.filter(
                  (q) => q !== payload.data.tag
                ),
              };
            }
            return product;
          })
        ]
      })
      // and provide a default case if no other handlers matched
      .addDefaultCase((state, action) => {});
  },
});

// for async thunk actions there are 3 states to be used with reducer cases
/**
 * builder
      .addCase(fetchProducts.pending, (state) => {
        // Handle pending state
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        // Handle fulfilled state
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        // Handle rejected state
      });
 */

export const { addfilterBy, removeFilterBy } = productsSlice.actions;

export const selectFilterBy = (state: AppState) =>
  state.products.search.filterBy;
export const selectCategoriesCount = (state: AppState) =>
  state.products.categoryCount;
export const selectCategories = (state: AppState) => state.products.categories;
export const selectProducts = (state: AppState) => state.products.products;
export const selectTotalNumberOfProducts = (state: AppState) =>
  state.products.count;
export const product = (state: AppState) => state.products.product;
export const selectSearchQuery = (state: AppState) =>
  state.products.search.query;

export default productsSlice.reducer;
