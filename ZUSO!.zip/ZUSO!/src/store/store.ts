import { configureStore, ThunkAction, Action } from "@reduxjs/toolkit";
import { authSlice } from "./authSlice";
import { registerSlice } from "./registerSlice";
import { createWrapper } from "next-redux-wrapper";
import { accountSlice } from "./accountSlice";
import { accountsAndBillingSecondaryNavbarSlice } from "./accountsAndBillingSecondaryNavbarSlice";
import { supplierPreferencesSlice } from "@/store/supplierPreferenceSlice";
import { productsSlice } from "@/store/productsSlice";
import { cartSlice } from "./cartSlice";
import { listsSlice } from "./listsSlice";
import { donotOrderAgainSlice } from "./donotOrderAgainSlice";
import { equipmentProposalsSlice } from "./equipmentproposalsSlice";
import { servicePartsProposalSlice } from "./techServiceAndPartsSlice";

const makeStore = () =>
  configureStore({
    reducer: {
      [authSlice.name]: authSlice.reducer,
      [registerSlice.name]: registerSlice.reducer,
      [accountSlice.name]: accountSlice.reducer,
      [accountsAndBillingSecondaryNavbarSlice.name]:
        accountsAndBillingSecondaryNavbarSlice.reducer,
      [supplierPreferencesSlice.name]: supplierPreferencesSlice.reducer,
      [productsSlice.name]: productsSlice.reducer,
      [cartSlice.name]: cartSlice.reducer,
      [listsSlice.name]: listsSlice.reducer,
      [donotOrderAgainSlice.name]: donotOrderAgainSlice.reducer,
      [equipmentProposalsSlice.name]: equipmentProposalsSlice.reducer,
      [servicePartsProposalSlice.name]: servicePartsProposalSlice.reducer,
    },
    devTools: true,
  });

export type AppStore = ReturnType<typeof makeStore>;
export type AppState = ReturnType<AppStore["getState"]>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  AppState,
  unknown,
  Action
>;

export const wrapper = createWrapper<AppStore>(makeStore);
