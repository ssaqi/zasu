import {createSlice, createAsyncThunk} from '@reduxjs/toolkit'
import {AppState} from './store'
import {get} from '@/utils/fetch';


export interface ISingleList {
    id: number,
    listName: string,
    items: number,
    total: number,
    description: string
}


export interface ILists {
    lists: ISingleList[]
}

const initialState: ILists = {
    lists: []
}


export const getLists = createAsyncThunk(
    "GET_LISTS",
    (thunkAPI) => {
        return new Promise<void>((resolve, reject) => {
            // @ts-ignore
            resolve()
            // get('users/cart/get')
            //     .then((response: any) => {
            //         if (response.success) {
            //             resolve(response.data)
            //         }
            //     }).catch((err: any) => {
            //     reject(err)
            // })
        })
    }
)

export const createList = createAsyncThunk(
    "CREATE_LIST",
    ({
        id,
        listName,
        items,
        total,
        description   
    }: any) => {
        return new Promise<void>((resolve, reject) => {
            // @ts-ignore
            resolve({id: id, listName: listName, items: items, total: total, description: description})
        })
    }
)

export const listsSlice = createSlice({
    name: "lists",
    initialState,
    reducers: {
        clearFullState: () => initialState
    },
    extraReducers: {
        [getLists.fulfilled.toString()]: (state, {payload}) => {
            state.lists = payload
        },
        [createList.fulfilled.toString()]: (state, {payload}) => {
            state.lists = [...state.lists, payload]
        }
    }
});

export const selectLists = (state: AppState) => state.lists.lists