import {get} from '@/utils/fetch';
import {ISuppliersList} from '@/store/supplierPreferenceSlice';

export const getSuppliersList = async () => {
    const response = await get('users/supplier/list')
    const suppliers: ISuppliersList[] = []
    response.forEach((_supplier: any) => {
        suppliers.push({value: _supplier.name, label: _supplier.name})
    })
    return suppliers
}

export const getSupplierAccountsList = async () => {
    const response = await get('users/supplierAccounts/list')
    return response
}
