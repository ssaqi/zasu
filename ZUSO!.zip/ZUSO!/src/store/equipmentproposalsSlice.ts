import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { AppState } from "./store";
import { post } from "@/utils/fetch";

export interface IEquipmentProposalsItem {
  requestNumber: string;
  requestDate: string;
  suppliers: string;
  firstName: string;
  lastName: string;
  email: string;
  officeName: string;
  action: "See Details";
  manufacturerName: string;
  mfrPartNumber: string;
  productName: string;
  notes: string;
}

export interface IEquipmentProposalsItems {
  equipmentProposalsItems: IEquipmentProposalsItem[];
  count: number;
}

const initialState: IEquipmentProposalsItems = {
  equipmentProposalsItems: [],
  count: 0,
};

export const getEquipmentProposalsItems = createAsyncThunk(
  "GET_EQUIPMENT_PROPOSALS_ITEMS",
  ({ limit, offset }: any) => {
    return new Promise<void>((resolve, reject) => {
      const body = {
        limit,
        offset,
        //    order,
        //    orderBy,
        //    filterBy,
      };

      post("users/equipmentProposals/listAll", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const addItem = createAsyncThunk(
  "ADD_EQUIPMENT_PROPOSALS_ITEM",
  ({
    suppliers,
    manufacturerName,
    mfrPartNumber,
    productName,
    notes,
    firstName,
    lastName,
    email,
    officeName,
    userId,
  }: any) => {
    return new Promise<void>((resolve, reject) => {
      const body = {
        suppliers: suppliers,
        manufacturer_name: manufacturerName,
        manufacturer_part_no: mfrPartNumber,
        product_name: productName,
        notes: notes,
        first_name: firstName,
        last_name: lastName,
        email: email,
        company_name: officeName,
        user_id: userId,
      };

      post("users/equipmentProposals/addProposal", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response.data);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const equipmentProposalsSlice = createSlice({
  name: "equipmentProposals",
  initialState,
  reducers: {
    clearFullState: () => initialState,
  },
  extraReducers: {
    [getEquipmentProposalsItems.fulfilled.toString()]: (state, { payload }) => {
      state.equipmentProposalsItems = payload.data;
      state.count = payload.count;
    },
    [addItem.fulfilled.toString()]: (state, { payload }) => {
      state.equipmentProposalsItems = [
        ...state.equipmentProposalsItems,
        payload,
      ];
    },
  },
});

export const selectEquipmentProposalsItems = (state: AppState) =>
  state.equipmentProposals.equipmentProposalsItems;
export const selectEquipmentProposalsItemsCount = (state: AppState) =>
  state.equipmentProposals.count;
