import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { AppState } from "./store";
import { post } from "@/utils/fetch";

export interface IServicePartsProposalItem {
  // part 2 vars send to office
  userId:number
  requestNumber: string;
  requestDate: string;
  requestType: string;
  emergency: string;
  requestedBy: string;
  action: string;
  preferredDay: string;
  preferredTime: string;
  problemLocation: string;
  notes: string;
  firstName: string;
  lastName: string;
  email: string;
  // other part 2 vars repair
  manufacturerName: string;
  underWarranty: string;
  contactMeBy: string;
  model: string;
  estimateFirst: string;
  serialNumber: string;
  sendShippingLabel: string;
  productName: string;
  companyName: string;
}

export interface IServicePartsProposalItems {
  servicePartsProposalItems: IServicePartsProposalItem[];
  count: number;
}

const initialState: IServicePartsProposalItems = {
  servicePartsProposalItems: [],
  count: 0,
};

export const getServicePartsProposalItems = createAsyncThunk(
  "GET_SERVICE_AND_PARTS_PROPOSAL_ITEMS",
  ({ limit, offset }: any) => {
    return new Promise<void>((resolve, reject) => {
      const body = {
        limit,
        offset,
        //    order,
        //    orderBy,
        //    filterBy,
      };

      post("users/serviceAndPartsProposals/listAll", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const addItem = createAsyncThunk(
  "ADD_SERVICE_AND_PARTS_PROPOSAL_ITEMS",
  ({
    requestType,
    emergency,
    productName,
    preferredDay,
    preferredTime,
    problemLocation,
    notes,
    firstName,
    lastName,
    email,
    manufacturerName,
    underWarranty,
    contactMeBy,
    model,
    estimateFirst,
    serialNumber,
    sendShippingLabel,
    companyName,
    userId,
  }: IServicePartsProposalItem) => {
    return new Promise<void>((resolve, reject) => {
      const body = {
        user_id: userId,
        request_type: requestType,
        emergency: emergency,
        preferred_day: preferredDay,
        preferred_time: preferredTime,
        notes: notes,
        first_name: firstName,
        last_name: lastName,
        email: email,
        company_name: companyName,
        manufacturer_name: manufacturerName,
        under_warranty: underWarranty,
        contact_me_by: contactMeBy,
        model: model,
        estimate_first: estimateFirst,
        serial_no: serialNumber,
        send_shipping_label: sendShippingLabel,
        product_name: productName,
        location_of_problem: problemLocation,
      };

      post("users/serviceAndPartsProposals/addProposal", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response.data);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }
);

export const servicePartsProposalSlice = createSlice({
  name: "servicePartsProposal",
  initialState,
  reducers: {
    clearFullState: () => initialState,
  },
  extraReducers: {
    [getServicePartsProposalItems.fulfilled.toString()]: (
      state,
      { payload }
    ) => {
      state.servicePartsProposalItems = payload.data;
      state.count = payload.count;
    },
    [addItem.fulfilled.toString()]: (state, { payload }) => {
      state.servicePartsProposalItems = [
        ...state.servicePartsProposalItems,
        payload,
      ];
    },
  },
});

export const selectServicePartsProposalItems = (state: AppState) =>
  state.servicePartsProposal
    .servicePartsProposalItems as IServicePartsProposalItem[];
    export const selectServicePartsProposalItemsCount = (state: AppState) =>
  state.servicePartsProposal.count;

