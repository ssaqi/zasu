import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { AppState } from "./store";
import { get, post } from "@/utils/fetch";

export interface ICartItem {
  id: number;
  name: string;
  image: string;
  price: number;
  cartPrice: number;
  supplierSku: string;
  productQuantity: string;
  caseQuantity: string;
  quantity: number;
  mpn: string;
}

export interface SpecialOrder {
  id: number;
  name: string;
  image: string;
  price: number;
  cartPrice: number;
  supplierSku: string;
  manufacturer: string;
  mfrPartNumber: string;
  quantity: number;
  notes: string;
  mpn: string;
}

export interface CartItems {
  cartItems: ICartItem[];
  specialOrderItems: SpecialOrder[];
  subtotal: number;
  grandTotal: number;
}

const initialState: CartItems = {
  cartItems: [],
  specialOrderItems: [],
  subtotal: 0,
  grandTotal: 0,
  //shipping
  //tax
};

export const getCartItems = createAsyncThunk("GET_CART_ITEMS", (thunkAPI) => {
  return new Promise<void>((resolve, reject) => {
    get("users/cart/get")
      .then((response: any) => {
        if (response.success) {
          resolve(response.data);
        }
      })
      .catch((err: any) => {
        reject(err);
      });
  });
});

export const addToCart = createAsyncThunk(
  "ADD_TO_CART",
  ({
    id,
    name,
    image,
    price,
    cartPrice,
    supplierSku,
    quantity,
    mpn,
  }: ICartItem) => {
    return new Promise<void>((resolve, reject) => {
      const addCartItemBody = {
        product_id: 0,
        quantity: quantity,
        special_product: false,
      };

      resolve({
        // @ts-ignore
        id: id,
        name: name,
        image: image,
        price: price,
        cartPrice: cartPrice,
        supplierSku: supplierSku,
        quantity: quantity,
        mpn: mpn,
      });
      // get('users/cart/get')
      //     .then((response: any) => {
      //         if (response.success) {
      //             resolve(response.data)
      //         }
      //     }).catch((err: any) => {
      //     reject(err)
      // })
    });
  }
);

export const removeFromCart = createAsyncThunk(
  "REMOVE_FROM_CART",
  ({ id }: any) => {
    return new Promise<void>((resolve, reject) => {
      const removeCartItemBody = {
        product_id: id,
        special_product: true,
      };

      // @ts-ignore
      resolve(removeCartItemBody);
      // get('users/cart/get')
      //     .then((response: any) => {
      //         if (response.success) {
      //             resolve(response.data)
      //         }
      //     }).catch((err: any) => {
      //     reject(err)
      // })
    });
  }
);

export const addSpecialOrder = createAsyncThunk(
  "ADD_SPECIAL_ORDER",
  ({
    manufacturer,
    mfrPartNumber,
    productName,
    quantity,
    supplier,
    notes,
    photo,
  }: any) => {
    return new Promise<void>((resolve, reject) => {
      const body = {
        manufacturer: manufacturer,
        manufacturer_part_no: mfrPartNumber,
        name: productName,
        supplier: supplier,
        description: notes,
        image_primary: photo,
        quantity: quantity,
      };

      post("users/cart/addSpecialProduct", body)
        .then((response: any) => {
          if (response.success) {
            resolve(response.data);
          }
        })
        .catch((err: any) => {
          reject(err);
        });

      // resolve({
      //   // @ts-ignore
      //   manufacturer: manufacturer,
      //   mfrPartNumber: mfrPartNumber,
      //   productName: productName,
      //   quantity: quantity,
      //   supplier: supplier,
      //   notes: notes,
      //   photo: photo,
      // });
    });
  }
);

export const updateCart = createAsyncThunk(
  "UPDATE_CART",
  ({ id, quantity }: any) => {
    return new Promise<void>((resolve, reject) => {
      const updateCartBody = {
        product_id: id,
        quantity: quantity,
        special_product: false,
      };

      // post("users/cart/updateCart", updateCartBody)
      // .then((response: any) => {
      //   if (response.success) {
      //     resolve(response);
      //   }
      // })
      // .catch((err: any) => {
      //   reject(err);
      // });

      resolve({
        // @ts-ignore
        product_id: 0,
        price: 8.1,
        quantity: quantity,
        subtotal: 90,
      });
    });
  }
);

export const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    clearFullState: () => initialState,
    updateCartItem: (state, { payload }) => {
      state.cartItems = [
        ...state.cartItems.map((item) => {
          if (item.id === payload.id) {
            return {
              ...item,
              quantity: payload.quantity,
              cartPrice: payload.price,
            };
          }
          return item;
        }),
      ];
    },
    updateSubtotal: (state, { payload }) => {
      state.subtotal = payload;
    },
  },
  extraReducers: {
    [getCartItems.fulfilled.toString()]: (state, { payload }) => {
      state.cartItems = payload;
    },
    [addToCart.fulfilled.toString()]: (state, { payload }) => {
      state.cartItems = [...state.cartItems, payload];
    },
    [removeFromCart.fulfilled.toString()]: (state, { payload }) => {
      state.cartItems = state.cartItems.filter(
        (item) => item.id !== payload.product_id
      );
      if (payload.special_product) {
        state.specialOrderItems = state.specialOrderItems.filter(
          (item) => item.id !== payload.product_id
        );
      }
    },
    [addSpecialOrder.fulfilled.toString()]: (state, { payload }) => {
      const specialProduct:ICartItem = {
        id: payload.id,
        name: payload.name,
        image: payload.image_primary,
        price: 0,
        cartPrice: 0,
        supplierSku: payload.supplier,
        productQuantity: "",
        caseQuantity: "",
        quantity: payload.quantity,
        mpn: ""
      }
      state.specialOrderItems = [...state.specialOrderItems, payload];
      state.cartItems = [...state.cartItems, specialProduct];
    },
    [updateCart.fulfilled.toString()]: (state, { payload }) => {
      state.cartItems = [
        ...state.cartItems.map((item) => {
          if (item.id === payload.product_id) {
            return {
              ...item,
              quantity: payload.quantity,
              cartPrice: payload.price,
            };
          }
          return item;
        }),
      ];
      state.subtotal = payload.subtotal;
    },
  },
});

export const selectCartSubtotal = (state: AppState) => state.cart.subtotal;
export const selectCartItems = (state: AppState) => state.cart.cartItems;
export const selectSpecialOrderitems = (state: AppState) =>
  state.cart.specialOrderItems;
export const { updateCartItem, updateSubtotal } = cartSlice.actions;
