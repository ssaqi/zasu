import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {get} from '@/utils/fetch';
import { AppState } from './store';


export interface ISingleItem {
    id: number,
    productName: string,
    option1: string,
    option2: string,
    shortNote: string
}

export interface IRemovedItems {
    removedItems: ISingleItem[]
}

const initialState: IRemovedItems = {
    removedItems: []
}

export const getRemovedItems = createAsyncThunk(
    "GET_REMOVED_ITEMS",
    (thunkAPI) => {
        return new Promise<void>((resolve, reject) => {
            // @ts-ignore
            resolve()
            // get('users/cart/get')
            //     .then((response: any) => {
            //         if (response.success) {
            //             resolve(response.data)
            //         }
            //     }).catch((err: any) => {
            //     reject(err)
            // })
        })
    }
)

export const addToRemovedItems = createAsyncThunk(
    "ADD_TO_REMOVED_ITEMS",
    ({
        id,
        productName,
        option1,
        option2,
        shortNote
    }:any) => {
        return new Promise<void>((resolve, reject) => {
            // @ts-ignore
            resolve({id: id, productName: productName, option1: option1, option2: option2, shortNote: shortNote})
        })
    }
)

export const donotOrderAgainSlice = createSlice({
    name: "donotOrderAgain",
    initialState,
    reducers: {
        clearFullState: () => initialState
    },
    extraReducers: {
        [getRemovedItems.fulfilled.toString()]: (state, {payload}) => {
            state.removedItems = payload
        },
        [addToRemovedItems.fulfilled.toString()]: (state, {payload}) => {
            state.removedItems = [...state.removedItems, payload]
        }
    }
})


export const selectRemovedItems = (state: AppState) => state.donotOrderAgain.removedItems;