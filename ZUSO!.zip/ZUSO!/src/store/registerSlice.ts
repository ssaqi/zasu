import { createSlice } from "@reduxjs/toolkit";
import { AppState } from "./store";
// import { HYDRATE } from "next-redux-wrapper";
import { IRegister, ILocation, IPlan, IPayment } from '../types/registerTypes'
import { devNull } from "os";

// Type for our state
export interface RegisterState {
  registerStageIndex: number;
  registerStage: IRegister;
  locationStage: ILocation;
  planStage: IPlan;
  paymentStage: IPayment;
}

const registerInitial: IRegister = {
    userIdRef: 0,
    companyName : '',
    companyEmail : '',
    ownerEmail : '',
    firstName : '',
    lastName : '',
    password : '',
    confirmPassword : '',
    phoneNumber: '',
}

const locationInitial: ILocation = {
    userId: 0,
    streetAddress : '',
    country : 1,
    city : '',
    state : '',
    phoneNumber : '',
    zipCode : ''
}

const planInitial : IPlan = {
    planId : 1
}

const paymentInitial : IPayment = {
    userId: 0,
    cardName : '',
    cardNumber : Number(),
    monthExp : Number(),
    yearExp : Number(),
    cvv : Number()
}

// Initial state
const initialState: RegisterState = {
    registerStageIndex: 1,
    registerStage: registerInitial,
    locationStage: locationInitial,
    planStage: planInitial,
    paymentStage: paymentInitial
};

// Actual Slice
export const registerSlice = createSlice({
  name: "register",
  initialState,
  reducers: {

    setRegisterStageIndex(state, action) {state.registerStageIndex = action.payload},
    setRegisterStage(state, action) {
        const temp: IRegister = {
            ...action.payload
        }
        // console.log('Setting Register Stage', temp);
        state.registerStage = temp
        // state.registerStage = action.payload
    },
    setLocationStage(state, action) {state.locationStage = action.payload},
    setPlanStage(state, action) {state.planStage = action.payload},
    setPaymentStage(state, action) {state.paymentStage = action.payload},


    // Special reducer for hydrating the state. Special case for next-redux-wrapper
    // extraReducers: {
    //   [HYDRATE]: (state, action) => {
    //     return {
    //       ...state,
    //       ...action.payload.auth,
    //     };
    //   },
    // },

  },
});

export const { setRegisterStageIndex, setRegisterStage, setLocationStage, setPlanStage, setPaymentStage} = registerSlice.actions;
export const selectRegisterStageIndex = (state: AppState) => state.register.registerStageIndex;
export const selectRegisterStage = (state: AppState) => state.register.registerStage;
export const selectLocationStage = (state: AppState) => state.register.locationStage;
export const selectPlanStage = (state: AppState) => state.register.planStage;
export const selectPaymentStage = (state: AppState) => state.register.paymentStage;
export default registerSlice.reducer;
