export interface IRegister{
    userIdRef: number,
    companyName : string,
    companyEmail : string,
    ownerEmail : string,
    firstName : string,
    lastName : string,
    password : string,
    confirmPassword : string,
    phoneNumber: string,
}

export interface ILocation{
    userId: number,
    streetAddress : string,
    country : number,
    city : string,
    state : string,
    phoneNumber : string,
    zipCode : string,
}

export interface IPlan{
    planId : number,
}

export interface IPayment{
    userId: number,
    cardName : string,
    cardNumber : number,
    monthExp : number,
    yearExp : number,
    cvv : number,
}

export interface ILandingPage {
    landingPage: string,
}
