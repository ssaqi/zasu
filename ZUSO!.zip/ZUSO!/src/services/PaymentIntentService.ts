import CONSTANTS from '@/utils/constants';

export const createPaymentIntent = async (userId: number, planId: number, currency: string) => {
    // return fetch(CONSTANTS.api + "registration/createPayment",
    // method
    //     {
    //     userId: userId,
    //     planId: planId,
    //     currency: currency
    // })

    const res = await fetch(CONSTANTS.api + 'registration/createPayment', {
        method: 'POST',
        // credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(
            {
                userId: userId,
                planId: planId,
                currency: currency,
            }
        ),
    })
    return res.json()
}
