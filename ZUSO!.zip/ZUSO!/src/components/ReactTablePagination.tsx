import React from 'react'
import { ReactTablePaginationStyled, LeftColumn, MiddleColumn, RightColumn, ButtonStyled } from '@/styledComponents/equipmentProposals/reactTablePagination'
import { useState, useEffect } from 'react'


interface ReactTablePaginationProps {
    canPreviousPage: Function,
    canNextPage: Function,
    pageOptions: Function,
    pageCount: number,
    gotoPage: Function,
    nextPage: Function,
    previousPage: Function,
    setPageSize: Function,
    pageIndex: number,
    pageSize: number,
    totalResults: number,
    currentPageResults: number
}

const ReactTablePagination: React.FC<ReactTablePaginationProps> = ({
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    pageIndex,
    pageSize,
    totalResults,
    currentPageResults
}) => {

    // const [displaying, setDisplaying] = useState(0);

    // useEffect(() => {
    //     if (displaying >= totalResults) {
    //         setDisplaying(totalResults);
    //     } else {
    //         setDisplaying(currentPageResults);
    //     }
    // }, [pageSize])

    const gotoNextPage = () => {
        // setDisplaying(() => displaying + currentPageResults);
        // if (displaying >= totalResults) {
        //     setDisplaying(totalResults);
        // } else {
        //     setDisplaying(() => displaying + currentPageResults);
        // }
        nextPage();
    }

    const gotoPreviousPage = () => {
        // setDisplaying(() => displaying - currentPageResults);
        previousPage();
    }


    return (
        <ReactTablePaginationStyled>
            <LeftColumn>
                <span>Show</span>
                <select
                    value={pageSize}
                    onChange={e => {
                        setPageSize(Number(e.target.value))
                    }}
                >
                    {[10, 18, 27, 36, 45].map(pageSize => (
                        <option key={pageSize} value={pageSize}>
                            {pageSize}
                        </option>
                    ))}
                </select>
                <span>rows per page</span>
            </LeftColumn>
            <MiddleColumn>
                {/* <span>Displaying </span>
                <span>{displaying - pageSize + 1} - {displaying} </span>
                <span>of {totalResults} requests</span> */}
                <span>Displaying </span>
                <span>{pageIndex + 1} of {pageOptions?.length}</span>
                <span> pages</span>
            </MiddleColumn>
            <RightColumn>
                <ButtonStyled onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                    {canPreviousPage ? (
                        <img className="rotated" src="/images/equipmentProposals/chevron-right-icon.svg" alt="left arrow" />
                    ) : (
                        <img src="/images/equipmentProposals/chevron-left-icon.svg" alt="left arrow" />
                    )}
                </ButtonStyled>
                <ButtonStyled onClick={gotoPreviousPage} disabled={!canPreviousPage}>
                    {'Previous'}
                </ButtonStyled>
                <span>{pageIndex + 1}</span>
                <ButtonStyled onClick={gotoNextPage} disabled={!canNextPage}>
                    {'Next'}
                </ButtonStyled>
                <ButtonStyled onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                    {canNextPage ? (
                        <img src="/images/equipmentProposals/chevron-right-icon.svg" alt="right arrow" />
                    ) : (
                        <img className="rotated" src="/images/equipmentProposals/chevron-left-icon.svg" alt="right arrow" />
                    )}
                </ButtonStyled>
            </RightColumn>
        </ReactTablePaginationStyled>
    )
}

export default ReactTablePagination