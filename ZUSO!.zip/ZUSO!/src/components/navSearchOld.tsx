import {useState} from 'react';

// function Column(children) {
//   return <div className="w-full md:w-1/4 p-4">{children}</div>;
// }

export default function NavSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedManufacturer, setSelectedManufacturer] = useState('');

  // Fetch data from API or use static data
  const categories = ['Category 1', 'Category 2', 'Category 3'];
  const manufacturers = ['Manufacturer 1', 'Manufacturer 2', 'Manufacturer 3'];

  function handleSearch(e: any) {
    setSearchTerm(e.target.value);
  }

  function handleCategorySelect(e: any) {
    setSelectedCategory(e.target.value);
  }

  function handleManufacturerSelect(e: any) {
    setSelectedManufacturer(e.target.value);
  }

  function handleButtonClick() {
    // Handle button click
  }

  return (
    <div className="flex flex-wrap justify-center align-center bg-zuso-bg-search">
      <div className="md:w-1/4 p-4">
        <div className="bg-gray-100 rounded-lg shadow-md">
          <input
            type="text"
            placeholder="Search"
            className="w-full p-2 rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
      </div>
      <div className="md:w-1/4 p-4">
        <div className="bg-gray-100 rounded-lg shadow-md">
          <select
            className="w-full p-2 rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={selectedCategory}
            onChange={handleCategorySelect}
          >
            <option value="">All Categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="md:w-1/4 p-4">
        <div className="bg-gray-100 rounded-lg shadow-md">
          <select
            className="w-full p-2 rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={selectedManufacturer}
            onChange={handleManufacturerSelect}
          >
            <option value="">All Manufacturers</option>
            {manufacturers.map((manufacturer) => (
              <option key={manufacturer} value={manufacturer}>
                {manufacturer}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="md:w-1/6 p-4">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          onClick={handleButtonClick}
        >
          Search
        </button>
      </div>
    </div>
  );
}
