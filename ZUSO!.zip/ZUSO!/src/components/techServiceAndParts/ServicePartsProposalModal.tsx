/* eslint-disable @next/next/no-img-element */
import React from "react";
import Modal from "react-modal";
import {
  ServicePartsProposalsModalStyled,
  ModalHeader,
  ModalBody,
  DropdownContainer,
  DropdownMenu,
  MenuOptions,
  ButtonsContainer,
  PersonalInfoSection,
  PersonalInfoDetail,
  AddButton,
  ClearButton,
  BodyHeader,
  RadioInputs,
  RadioInput,
  RequestSections,
  SendTechStyled,
  BoxTitle,
  BoxDescription,
  Detail,
} from "@/styledComponents/techServiceAndParts/servicePartsProposalModal";
import closeIcon from "public/images/supplies/productModal/close-icon.svg";
import chevronDown from "public/images/supplies/removeItemModal/chevron-down.svg";
import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { addItem } from "@/store/techServiceAndPartsSlice";
import ThanksModal from "@/components/ThanksModal";
import { CheckboxLabel } from "@/styledComponents/practicePreferences/editAddress";
import { PermissionsCheckbox } from "@/styledComponents/users";
import { IUserState } from "@/store/accountSlice";
import { setConstantValue } from "typescript";

interface ServicePartsProposalModalProps {
  setIsOpen: Function;
  isOpen: boolean;
  closeModal: Function;
  user: IUserState;
}

const ServicePartsProposalModal: React.FC<ServicePartsProposalModalProps> = ({
  setIsOpen,
  isOpen,
  closeModal,
  user,
}) => {
  const dispatch = useDispatch();

  const [optionsShown, setOptionsShown] = useState(false);

  const [manufacturerName, setManufacturerName] = useState("");
  const [mfrPartNumber, setMfrPartNumber] = useState("");
  const [productName, setProductName] = useState("");
  const [notes, setNotes] = useState("");
  const [dropdownTitle, setDropdownTitle] = useState([
    "Midwest Dental, Henry Schein, Patterson",
  ]);
  const [firstName, setFirstName] = useState(user.first_name);
  const [lastName, setLastName] = useState(user.last_name);
  const [email, setEmail] = useState(user.email);
  const [officeName, setOfficeName] = useState(user.company_name);

  const [isThanksModalOpen, setIsThanksModalOpen] = useState(false);

  const [techOrRepairOption, setTechOrRepairOption] = useState("sendTech");

  // Send tech section state:
  const [yesOrNo, setYesOrNo] = useState("No"); // emergency
  const [dayOptionsTitle, setDayOptionsTitle] = useState("");
  const [timeOptionsTitle, setTimeOptionsTitle] = useState("");
  const [problemLocation, setProblemLocation] = useState("");

  // Repair section state:
  const [manufrName, setManufrName] = useState("");
  const [model, setModel] = useState("");
  const [serialNo, setSerialNo] = useState("");
  const [warranty, setWarranty] = useState("Unknown");
  const [estimate, setEstimate] = useState("No");
  const [shipping, setShipping] = useState("No");
  const [contact, setContact] = useState("Email");

  useEffect(() => {
    setFirstName(user.first_name);
    setLastName(user.last_name);
    setEmail(user.email);
    setOfficeName(user.company_name);
  }, [user]);

  const handleOptionChange = (event: any) => {
    setTechOrRepairOption(event.target.value);
  };

  const closeThanksModal = () => {
    setIsThanksModalOpen(false);
  };

  const changeTitle = (e: any) => {
    const isPresent = dropdownTitle.some((item) => item === e.target.innerText);
    if (!isPresent) {
      setDropdownTitle([...dropdownTitle, " ", e.target.innerText]);
    }
  };

  const clear = () => {
    setManufacturerName("");
    setMfrPartNumber("");
    setProductName("");
    setNotes("");
    setDropdownTitle(["Midwest Dental,"]);
    setFirstName(user.first_name);
    setLastName(user.last_name);
    setEmail(user.email);
    setOfficeName(user.company_name);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    dispatch(
      // @ts-ignore
      addItem({
        userId: user.id,
        requestType:
          techOrRepairOption === "sendTech"
            ? "Send a Tech to my office"
            : "Handpiece Repair",
        emergency: techOrRepairOption === "sendTech" ? yesOrNo : "",
        productName: productName,
        preferredDay: dayOptionsTitle,
        preferredTime: timeOptionsTitle,
        problemLocation: problemLocation,
        notes: notes,
        firstName: firstName,
        lastName: lastName,
        email: email,
        manufacturerName: manufrName,
        underWarranty: warranty,
        contactMeBy: contact,
        model: model,
        estimateFirst: estimate,
        serialNumber: serialNo,
        sendShippingLabel: shipping,
        companyName: officeName,
      })
    );
    clear();
    closeModal();
    setIsThanksModalOpen(true);
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onRequestClose={() => closeModal()}
        style={{
          content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            padding: "0",
            maxHeight: "98vh",
            overflow: "auto",
          },
        }}
      >
        <ServicePartsProposalsModalStyled onSubmit={handleSubmit}>
          <ModalHeader>
            <p>Request Technical Services and Parts</p>
            <img
              src={closeIcon.src}
              alt="..."
              onClick={() => setIsOpen(false)}
            />
          </ModalHeader>
          <ModalBody>
            <div>
              <BodyHeader>
                <p>What Do You Need?</p>
                <RadioInputs>
                  <RadioInput
                    type="radio"
                    value="sendTech"
                    checked={techOrRepairOption === "sendTech"}
                    onChange={handleOptionChange}
                    required={true}
                  />
                  <p>Send a Tech to my office</p>
                </RadioInputs>
                <RadioInputs>
                  <RadioInput
                    type="radio"
                    value="repair"
                    checked={techOrRepairOption === "repair"}
                    onChange={handleOptionChange}
                    required={true}
                  />
                  <p>Handpiece Repair</p>
                </RadioInputs>
              </BodyHeader>
              <RequestSections>
                {techOrRepairOption === "sendTech" ? (
                  <SendTechSection
                    yesOrNo={yesOrNo}
                    setYesOrNo={setYesOrNo}
                    dayOptionsTitle={dayOptionsTitle}
                    setDayOptionsTitle={setDayOptionsTitle}
                    timeOptionsTitle={timeOptionsTitle}
                    setTimeOptionsTitle={setTimeOptionsTitle}
                    notes={notes}
                    setNotes={setNotes}
                    problemLocation={problemLocation}
                    setProblemLocation={setProblemLocation}
                  />
                ) : (
                  <RepairSection
                    notes={notes}
                    setNotes={setNotes}
                    manufrName={manufrName}
                    setManufrName={setManufrName}
                    warranty={warranty}
                    setWarranty={setWarranty}
                    estimate={estimate}
                    setEstimate={setEstimate}
                    shipping={shipping}
                    setShipping={setShipping}
                    contact={contact}
                    setContact={setContact}
                    model={model}
                    setModel={setModel}
                    serialNo={serialNo}
                    setSerialNo={setSerialNo}
                  />
                )}
              </RequestSections>
            </div>
            <PersonalInfoSection>
              <PersonalInfoDetail>
                <label htmlFor="firstName">Your First Name</label>
                <input
                  id="firstName"
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  required={true}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="lastName">Your Last Name</label>
                <input
                  id="lastName"
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required={true}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="email">Your Email</label>
                <input
                  id="email"
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required={true}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="officeName">Your Office Name</label>
                <input
                  id="officeName"
                  type="text"
                  value={officeName}
                  onChange={(e) => setOfficeName(e.target.value)}
                  required={true}
                />
              </PersonalInfoDetail>
            </PersonalInfoSection>
          </ModalBody>
          <ButtonsContainer>
            <AddButton type="submit">Submit Request</AddButton>
            <ClearButton type="button" onClick={clear}>
              Clear
            </ClearButton>
          </ButtonsContainer>
        </ServicePartsProposalsModalStyled>
      </Modal>
      <ThanksModal
        setIsOpen={setIsThanksModalOpen}
        isOpen={isThanksModalOpen}
        closeModal={closeThanksModal}
      />
    </>
  );
};

function SendTechSection({
  yesOrNo,
  setYesOrNo,
  dayOptionsTitle,
  setDayOptionsTitle,
  timeOptionsTitle,
  setTimeOptionsTitle,
  notes,
  setNotes,
  problemLocation,
  setProblemLocation,
}: any) {
  const [dayOptionsShown, setDayOptionsShown] = useState(false);
  const [timeOptionsShown, setTimeOptionsShown] = useState(false);

  const handleEmergencyOptions = (event: any) => {
    setYesOrNo(event.target.value);
  };

  const changeDayTitle = (e: any) => {
    // const isPresent = dayOptionsTitle.some(
    //   (item) => item === e.target.innerText
    // );
    // if (!isPresent) {
    setDayOptionsTitle(e.target.innerText);
    // }
  };

  const changeTimeTitle = (e: any) => {
    setTimeOptionsTitle(e.target.innerText);
  };

  return (
    <SendTechStyled>
      <div>
        <p className="text-[#64748b]">Is this an emergency?</p>

        <RadioInputs>
          <RadioInput
            type="radio"
            value="Yes"
            checked={yesOrNo === "Yes"}
            onChange={handleEmergencyOptions}
            required={true}
          />
          <p>Yes</p>
        </RadioInputs>
        <RadioInputs>
          <RadioInput
            type="radio"
            value="No"
            checked={yesOrNo === "No"}
            onChange={handleEmergencyOptions}
            required={true}
          />
          <p>No</p>
        </RadioInputs>
      </div>
      <span>
        <BoxTitle>Description of Problem & Notes *</BoxTitle>
        <BoxDescription>
          <textarea
            name="problemNotes"
            id="problemNotes"
            cols={30}
            rows={10}
            placeholder="Enter text here"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            required={true}
          />
        </BoxDescription>
      </span>
      <span>
        <BoxTitle>Location of Problem *</BoxTitle>
        <BoxDescription small>
          <textarea
            name="locationProblem"
            id="locationProblem"
            cols={30}
            rows={10}
            placeholder="Enter text here"
            value={problemLocation}
            onChange={(e) => setProblemLocation(e.target.value)}
            required={true}
          />
        </BoxDescription>
      </span>
      <div className="flex ">
        <DropdownContainer>
          <p>Preferred Day *</p>
          <DropdownMenu onClick={() => setDayOptionsShown(!dayOptionsShown)}>
            {!dayOptionsTitle ? (
              <p id="placeholder">Select a day (M-F)</p>
            ) : (
              <p>{dayOptionsTitle}</p>
            )}

            <img src={chevronDown.src} alt="..." />
            <MenuOptions className={dayOptionsShown ? "shown" : ""}>
              <p onClick={changeDayTitle}>Monday</p>
              <p onClick={changeDayTitle}>Tuesday</p>
              <p onClick={changeDayTitle}>Wednesday</p>
              <p onClick={changeDayTitle}>Thursday</p>
              <p onClick={changeDayTitle}>Friday</p>
            </MenuOptions>
          </DropdownMenu>
        </DropdownContainer>
        <DropdownContainer>
          <p>Preferred Time *</p>
          <DropdownMenu onClick={() => setTimeOptionsShown(!timeOptionsShown)}>
            {!timeOptionsTitle ? (
              <p id="placeholder">Choose One</p>
            ) : (
              <p>{timeOptionsTitle}</p>
            )}
            <img src={chevronDown.src} alt="..." />
            <MenuOptions className={timeOptionsShown ? "shown" : ""}>
              <p onClick={changeTimeTitle}>8:00</p>
              <p onClick={changeTimeTitle}>9:00</p>
              <p onClick={changeTimeTitle}>10:00</p>
              <p onClick={changeTimeTitle}>11:00</p>
              <p onClick={changeTimeTitle}>12:00</p>
            </MenuOptions>
          </DropdownMenu>
        </DropdownContainer>
      </div>
    </SendTechStyled>
  );
}

function RepairSection({
  notes,
  setNotes,
  manufrName,
  setManufrName,
  warranty,
  setWarranty,
  estimate,
  setEstimate,
  shipping,
  setShipping,
  contact,
  setContact,
  model,
  setModel,
  serialNo,
  setSerialNo,
}: any) {
  const handleWarranty = (event: any) => {
    setWarranty(event.target.value);
  };
  const handleEstimate = (event: any) => {
    setEstimate(event.target.value);
  };
  const handleShipping = (event: any) => {
    setShipping(event.target.value);
  };
  const handleContact = (event: any) => {
    setContact(event.target.value);
  };

  return (
    <SendTechStyled>
      <span className="flex">
        <Detail>
          <label>Manufacturer Name *</label>
          <input
            id="manufacturerName"
            type="text"
            placeholder="Enter manufacturer"
            value={manufrName}
            onChange={(e) => setManufrName(e.target.value)}
            required={true}
          />
        </Detail>
        <Detail>
          <label>Model *</label>
          <input
            id="model"
            type="text"
            placeholder="Enter model"
            value={model}
            onChange={(e) => setModel(e.target.value)}
            required={true}
          />
        </Detail>
      </span>
      <span className="flex w-[100%] mt-4">
        <Detail>
          <label>Serial Number *</label>
          <input
            id="serialNum"
            type="text"
            placeholder="Enter number"
            value={serialNo}
            onChange={(e) => setSerialNo(e.target.value)}
            required={true}
          />
        </Detail>
      </span>
      <span className="flex w-[100%]   mt-4">
        <p className="text-[#64748b] ">Under Warranty</p>
        <span className="flex pl-[18%]">
          <RadioInputs>
            <RadioInput
              type="radio"
              value="Yes"
              checked={warranty === "Yes"}
              onChange={handleWarranty}
              required={true}
            />
            <p>Yes</p>
          </RadioInputs>
          <RadioInputs>
            <RadioInput
              type="radio"
              value="No"
              checked={warranty === "No"}
              onChange={handleWarranty}
              required={true}
            />
            <p>No</p>
          </RadioInputs>
          <RadioInputs>
            <RadioInput
              type="radio"
              value="Unknown"
              checked={warranty === "Unknown"}
              onChange={handleWarranty}
              required={true}
            />
            <p>Unknown</p>
          </RadioInputs>
        </span>
      </span>
      <span className="flex w-[100%]   mt-4">
        <p className="text-[#64748b] ">Estimate First</p>
        <span className="flex pl-[21%]">
          <RadioInputs>
            <RadioInput
              type="radio"
              value="Yes"
              checked={estimate === "Yes"}
              onChange={handleEstimate}
              required={true}
            />
            <p>Yes</p>
          </RadioInputs>
          <RadioInputs>
            <RadioInput
              type="radio"
              value="No"
              checked={estimate === "No"}
              onChange={handleEstimate}
              required={true}
            />
            <p>No</p>
          </RadioInputs>
        </span>
      </span>
      <span className="flex w-[100%]   mt-4">
        <p className="text-[#64748b] ">Send a Shipping Label</p>
        <span className="flex pl-[13%]">
          <RadioInputs>
            <RadioInput
              type="radio"
              value="Yes"
              checked={shipping === "Yes"}
              onChange={handleShipping}
              required={true}
            />
            <p>Yes</p>
          </RadioInputs>
          <RadioInputs>
            <RadioInput
              type="radio"
              value="No"
              checked={shipping === "No"}
              onChange={handleShipping}
              required={true}
            />
            <p>No</p>
          </RadioInputs>
        </span>
      </span>
      <span className="flex w-[100%]  mt-4">
        <p className="text-[#64748b] ">Contact Me By</p>
        <span className="flex pl-[21%]">
          <PermissionsCheckbox
            type="checkbox"
            value="email"
            checked={contact === "email"}
            onChange={handleContact}
          />
          <CheckboxLabel className="pr-2">Email</CheckboxLabel>
          <PermissionsCheckbox
            type="checkbox"
            value="phone"
            checked={contact === "phone"}
            onChange={handleContact}
          />
          <CheckboxLabel>Phone</CheckboxLabel>
        </span>
      </span>
      <span>
        <BoxTitle>Description of Problem & Notes</BoxTitle>
        <BoxDescription small>
          <textarea
            name="problemNotes"
            id="repairProblemNotes"
            cols={30}
            rows={10}
            placeholder="Enter text here"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            required={true}
          />
        </BoxDescription>
      </span>
    </SendTechStyled>
  );
}

export default ServicePartsProposalModal;
