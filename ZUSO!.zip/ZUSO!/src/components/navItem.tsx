import styled from 'styled-components';
import dropdownIcon from '../../public/Dropdown.svg'

const Icon = styled.img`
  width: 10px;
`

interface NavItemProps {
    title: string,
    icon: boolean,
}

const NavItem: React.FC<NavItemProps> = ({title, icon}) => {
    return (
        <>
            <span
                className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                {title}&nbsp;&nbsp;{icon ? <Icon src={dropdownIcon.src} alt=""/> : null}
            </span>
        </>
    )
}

export default NavItem;
