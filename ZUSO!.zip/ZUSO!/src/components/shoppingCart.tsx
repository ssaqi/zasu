import Image from "next/image";
import { useState, useEffect } from "react";
import {
  MainContainer,
  RowContainer,
  ColumnContainer,
  SKUContainer,
  SKUFont,
  SKUSpan,
  CartHeading,
  CartImage,
  CartItemContainer,
  ProductHeadingContainer,
  ProductHeading,
  QTYContainer,
  QTY,
  QTYIcon,
  BtnMinus,
  ProductPrice,
  Divider,
  LeftFloat,
  GrandTotal,
  BottomDivider,
  FloatContainer,
  Button,
} from "@/styledComponents/shoppingCart";
import { useDispatch, useSelector } from "react-redux";
import {
  removeFromCart,
  selectCartItems,
  selectCartSubtotal,
  updateCartItem,
  updateSubtotal,
} from "@/store/cartSlice";

export default function ShoppingCart() {
  const dispatch = useDispatch();
  const cartItems = useSelector(selectCartItems);
  const subtotal = useSelector(selectCartSubtotal);

  // useEffect(() => {
  //   dispatch(
  //     // @ts-ignore
  //     getCartItems()
  //   )
  // }, [])

  // console.log(_cartItems);

  const removeItemFromCart = (id: number) => {
    // @ts-ignore
    dispatch(removeFromCart({ id: id }));
  };

  // const updateItemFromCart = (id: number) => {
  //   // @ts-ignore
  //   dispatch(updateCartItem({ id: id,quantity: quantity  }))
  // }

  const increaseQuantity = (id: any, quantity: any, price: number) => {
    const newQuantity = parseInt(quantity) + 1;
    const newPrice = Number(price) * newQuantity;
    dispatch(
      updateCartItem({
        id: id,
        quantity: newQuantity,
        price: newPrice,
      })
    );
    dispatch(updateSubtotal(subtotal + price));
  };

  const decreaseQuantity = (id: any, quantity: any, price: any) => {
    if (quantity > 1) {
      const newQuantity = parseInt(quantity) - 1;
      const newPrice = Number(price) * newQuantity;
      dispatch(
        updateCartItem({
          id: id,
          quantity: newQuantity,
          price: newPrice,
        })
      );
      dispatch(updateSubtotal(subtotal - price));
    }
  };

  return (
    <MainContainer>
      <RowContainer>
        <ColumnContainer>
          <RowContainer>
            <CartHeading>
              Your Cart <span>({cartItems.length} ITEMS)</span>
            </CartHeading>
          </RowContainer>
        </ColumnContainer>
      </RowContainer>

      <CartItemContainer>
        {Boolean(cartItems.length) &&
          cartItems.map((item, index) => {
            return (
              <div key={index}>
                <RowContainer>
                  <ColumnContainer>
                    <RowContainer>
                      <CartImage
                        src="/Placeholder.jpg"
                        alt="CartProductImage"
                      />
                      <ProductHeadingContainer>
                        <ProductHeading>{item.name}</ProductHeading>
                        <Image
                          src="Hide.svg"
                          width="10"
                          height="10"
                          alt="hideButton"
                        />
                      </ProductHeadingContainer>
                    </RowContainer>
                  </ColumnContainer>
                </RowContainer>
                <SKUContainer>
                  <SKUFont>
                    {item.supplierSku}
                    <SKUSpan>{item.mpn}</SKUSpan>
                  </SKUFont>
                </SKUContainer>
                <RowContainer>
                  <ColumnContainer>
                    <QTYContainer>
                      <QTY>Qty:</QTY>
                      <BtnMinus
                        onClick={() =>
                          decreaseQuantity(item.id, item.quantity, item.price)
                        }
                      >
                        <Image
                          src="minus.svg"
                          width="10"
                          height="10"
                          alt="minus Sign"
                        />
                      </BtnMinus>
                      <QTYIcon>{item.quantity}</QTYIcon>
                      <BtnMinus
                        onClick={() =>
                          increaseQuantity(item.id, item.quantity, item.price)
                        }
                      >
                        <Image
                          src="plus.svg"
                          width="10"
                          height="10"
                          alt="plus Sign"
                        />
                      </BtnMinus>
                      <ProductPrice>
                        ${Number(item.cartPrice).toFixed(2)}
                      </ProductPrice>
                      <BtnMinus
                        onClick={() => {
                          removeItemFromCart(item.id);
                        }}
                      >
                        <Image
                          src="delete.svg"
                          width="12"
                          height="14"
                          alt="minus Sign"
                        />
                      </BtnMinus>
                      {/* only remove the IMG tag
                    <DeleteButton
                    onClick={() => deleteProduct(product.id)}>
                      <Image src='delete.svg'
                        width='10'
                        height='10'
                        alt='minus Sign' />
                    </DeleteButton> */}
                    </QTYContainer>
                  </ColumnContainer>
                </RowContainer>
              </div>
            );
          })}
      </CartItemContainer>

      {Boolean(cartItems.length) && (
        <>
          <Divider />
          <FloatContainer>
            <LeftFloat>
              <h4>Subtotal</h4>
              <span>${subtotal.toFixed(2)}</span>
            </LeftFloat>
            <LeftFloat>
              <h4>Shipping & Handling</h4>
              <span>$11.90</span>
            </LeftFloat>
            <LeftFloat>
              <h4>Tax</h4>
              <span>$21.17</span>
            </LeftFloat>
            <GrandTotal>
              <h5>Grand Total</h5>
              <h6>${(subtotal + 11.9 + 21.17).toFixed(2)}</h6>
            </GrandTotal>
          </FloatContainer>

          <BottomDivider />

          <FloatContainer>
            <LeftFloat>
              <Button>View Cart</Button>
              <Button>Checkout</Button>
            </LeftFloat>
          </FloatContainer>
        </>
      )}
    </MainContainer>
  );
}
