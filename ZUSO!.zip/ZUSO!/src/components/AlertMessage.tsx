import React from 'react'
import styled from 'styled-components'
// import cartIcon from 'public/images/supplies/card/cart.svg'

const AlertMessageStyled = styled.div`
    position: fixed;
    top: 10%;
    left: 50%;
    z-index: 1000;
    transform: translateX(-50%);

    display: flex;
    justify-content: center;
    align-items: center;

    width: 300px;
    height: 70px;
    padding: 10px;
    background: #14CA76;
    box-shadow: 2px 2px 4px rgba(200, 200, 200, 0.05);
    border-radius: 4px;

    > p {
        font-family: 'Open Sans', sans-serif;
        font-style: normal;
        font-weight: 600;
        font-size: 18px;
        line-height: 24px;
        text-align: center;
        color: #FFF;
    }
`

interface AlertMessageProps {
    message: string,
    top: string
}

const AlertMessage: React.FC<AlertMessageProps> = ({ message, top }) => {
    return (
        <AlertMessageStyled style={top ? { top: top } : {}} >
            <p>{message}</p>
            {/* <img src={cartIcon.src} alt="shopping cart" /> */}
        </AlertMessageStyled>
    )
}

export default AlertMessage