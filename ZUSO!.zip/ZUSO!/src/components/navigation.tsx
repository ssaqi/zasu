import {
  NavContainer,
  MenuContainer,
  LogoLink,
  NavLink,
  NavIconLink,
  CartQuantity,
  NotificationQuantity,
  NavigationContainer,
  SearchBar,
  SearchInput,
  SearchIcon,
  AvatarImage,
  AvatarImageIcon,
  NavbarIcons,
  NavigationRightContainer,
} from "@/styledComponents/navigation";
import Image from "next/image";
import React, { useState } from "react";
import { Transition } from "@headlessui/react";
import Menu from "./megaMenu";
import NavSearch from "./navSearch";
import Link from "next/link";
import AccountNav from "./accountNav";
import ShoppingCart from "./shoppingCart";
import defaultAvatar from "../../public/DefaultAvatarBg.png";
import dropdownIcon from "../../public/Dropdown.svg";
import cartIcon from "../../public/shopping-cart.svg";
import notificationIcon from "../../public/notification.svg";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import { selectCartItems } from "@/store/cartSlice";
import { getSuppliers } from "@/store/supplierPreferenceSlice";

export default function MainNavigation() {
  const cartItems = useSelector(selectCartItems);

  const [isOpen, setIsOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [accOpen, setAccClose] = useState(false);
  const router = useRouter();
  const dispatch = useDispatch();

  const [searchTerm, setSearchTerm] = useState("");

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const toggleCart = () => {
    setIsActive(!isActive);
  };

  const toggleAcc = () => {
    setAccClose(!accOpen);
  };

  function handleSearch(event: any) {
    setSearchTerm(event.target.value);
  }

  // const gotoSupplies = () => {
  //     router.push('/supplies')
  // }

  const gotoLink = (link: string) => {
    router.push(`/${link}`);
  };

  return (
    <>
      <NavContainer>
        <LogoLink href="/" />
        <MenuContainer>
          <NavigationContainer>
            <NavLink onClick={toggleMenu}>
              Menu
              <Image
                src={dropdownIcon.src}
                alt="dropdownSVGGFIle"
                height="4"
                width="8"
              />
            </NavLink>
            <NavLink onClick={() => gotoLink("supplies")}>Supplies</NavLink>
            <NavLink onClick={() => gotoLink("equipmentProposals")}>
              Equipment
            </NavLink>
            <NavLink onClick={() => gotoLink("techServiceAndParts")}>Technical Support</NavLink>
            <NavLink onClick={() => gotoLink("lists")}>Lists</NavLink>
            <NavLink onClick={() => gotoLink("orders")}>Orders</NavLink>
          </NavigationContainer>
          <NavigationRightContainer>
            <NavIconLink href="#">
              <NavbarIcons src={notificationIcon.src} alt="dropdownSVGGFIle" />
              <NotificationQuantity>
                <p>{1}</p>
              </NotificationQuantity>
            </NavIconLink>
            <NavIconLink href="#" onClick={toggleCart}>
              <NavbarIcons src={cartIcon.src} alt="dropdownSVGGFIle" />
              {Boolean(cartItems.length) && (
                <CartQuantity>
                  <p>{cartItems.length}</p>
                </CartQuantity>
              )}
            </NavIconLink>
            <NavIconLink href="#" onClick={toggleAcc}>
              <AvatarImage src={defaultAvatar.src} alt="dropdownSVGGFIle" />
              <AvatarImageIcon src={dropdownIcon.src} alt="dropdownSVGGFIle" />
            </NavIconLink>
          </NavigationRightContainer>
        </MenuContainer>
      </NavContainer>
      {/*<NavSearch/>*/}
      <div style={{ zIndex: "100" }}>
        <Transition
          show={accOpen}
          enter="transition ease-out duration-100 transform"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="transition ease-in duration-75 transform"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <AccountNav />
        </Transition>
      </div>
      <div style={{ zIndex: "100" }}>
        <Transition
          show={isActive}
          enter="transition ease-out duration-100 transform"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="transition ease-in duration-75 transform"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <ShoppingCart />
        </Transition>
      </div>
      <div style={{ zIndex: "100" }}>
        <Transition
          show={isOpen}
          enter="transition ease-out duration-100 transform"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="transition ease-in duration-75 transform"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <Menu />
        </Transition>
      </div>
    </>
  );
}
