import React from 'react'
import { ThanksModalStyled, ImageSection, ContentSection, ButtonSection } from '@/styledComponents/equipmentProposals/thanksModal'
import Modal from 'react-modal'
import modalIcon from 'public/images/equipmentProposals/thanks-modal-icon.svg'



interface ThanksModalProps {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function
}

const ThanksModal: React.FC<ThanksModalProps> = ({ setIsOpen, isOpen, closeModal }) => {
    return (
        <>
            <Modal
                isOpen={isOpen}
                onRequestClose={() => closeModal()}
                style={{
                    content: {
                        top: '50%',
                        left: '50%',
                        right: 'auto',
                        bottom: 'auto',
                        marginRight: '-50%',
                        transform: 'translate(-50%, -50%)',
                        padding: '0',
                    }
                }}
            >
                <ThanksModalStyled>
                    <ImageSection>
                        <img src={modalIcon.src} alt="..." />
                    </ImageSection>
                    <ContentSection>
                        <h1>Thank you for submitting your request!</h1>
                        <p>We will get back to you as soon as possible. Keep an eye on your emails.</p>
                    </ContentSection>
                    <ButtonSection>
                        <button onClick={() => closeModal()}>Continue</button>
                    </ButtonSection>
                </ThanksModalStyled>
            </Modal>
        </>
    )
}

export default ThanksModal