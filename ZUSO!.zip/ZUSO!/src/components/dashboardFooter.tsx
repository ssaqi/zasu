import Image from 'next/image'
import Link from 'next/link';
import logo from '../../public/logoBottom.svg'
import styled from 'styled-components';

const Container = styled.div`
  background: #F1F5F9;
`

export default function DashboardFooter() {
    return (
        <Container>
            <div className='flex items-start justify-center gap-4 mt-24'>
                <Image
                    src={logo}
                    alt='logo'
                    width='100'
                    height='100'/>
            </div>
            <div className='flex items-start justify-center gap-4 p-6'>
                <Link href="/" className='text-xs text-black'>© 2020 ZuSo Supply LLC</Link>
                <Link href="/" className='text-xs text-black'>Terms of Service</Link>
                <Link href="/" className='text-xs text-black'>Privacy Policy</Link>
                <Link href="/" className='text-xs text-black'>Send Feedback</Link>
            </div>
        </Container>
    )
}
