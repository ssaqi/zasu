import {
  CardStyled,
  CardTop,
  LastOrdered,
  Trash,
  Heart,
  ProductImage,
  ProductDesc,
  OtherDetails,
  Supplier,
  MFR,
  NickName,
  Bottom,
  BlueButton,
  GreenButton,
  Quantity,
  ModalContainer,
} from "@/styledComponents/supplies/cards";
import plusIcon from "public/images/supplies/card/plus.svg";
import minusIcon from "public/images/supplies/card/minus.svg";
import Link from "next/link";
import React, { useState } from "react";
import Modal from "react-modal";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, selectCartSubtotal, updateSubtotal } from "@/store/cartSlice";
import ProductModal from "./modals/ProductModal";
import RemoveItemModal from "./modals/RemoveItemModal";
import ConfirmRemoveModal from "./modals/ConfirmRemoveModal";
import { IProduct } from "@/store/productsSlice";
import AlertMessage from "@/components/AlertMessage";
import AddModal1 from "./modals/AddModal1";
import AddModal2 from "./modals/AddModal2";
import AddModal3 from "./modals/AddModal3";
import AddToListModal from "./modals/AddToListModal";
import CreateListModal from "./modals/CreateListModal";

interface ICard {
  product: IProduct;
}

const Card: React.FC<ICard> = ({ product }) => {
  const dispatch = useDispatch();
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isRemoveItemModalOpen, setIsRemoveItemModalOpen] = useState(false);
  const [isConfirmRemoveModalOpen, setIsConfirmRemoveModalOpen] =
    useState(false);
  const [isAddModal1Open, setIsAddModal1Open] = useState(false);
  const [isAddModal2Open, setIsAddModal2Open] = useState(false);
  const [isAddModal3Open, setIsAddModal3Open] = useState(false);
  const [isAddToListModalOpen, setIsAddToListModalOpen] = useState(false);
  const [isCreateListModalOpen, setIsCreateListModalOpen] = useState(false);
  const [quantity, setQuantity] = useState("1");
  const [showAlert, setShowAlert] = useState(false);
  const subtotal = useSelector(selectCartSubtotal);


  const displayAlert = () => {
    setShowAlert(true);
    setTimeout(() => {
      setShowAlert(false);
    }, 3000);
  };

  const addProductToCart = () => {
    const price = Number(product.price) * Number(quantity);
    dispatch(
      // @ts-ignore
      addToCart({
        id: product.id,
        name: product.name,
        image: product.image,
        price: Number(product.price),
        cartPrice: price,
        supplierSku: product.supplierSku,
        productQuantity: product.productQuantity,
        caseQuantity: product.caseQuantity,
        quantity: Number(quantity),
        mpn: product.mpn,
      })
    );
    dispatch(updateSubtotal(subtotal + price));
    displayAlert();
    setQuantity("1");
  };

  // product modal
  const openProductModal = () => {
    setIsProductModalOpen(true);
  };

  const closeProductModal = () => {
    setIsProductModalOpen(false);
  };

  // remove item modal
  const openRemoveItemModal = () => {
    setIsRemoveItemModalOpen(true);
  };

  const closeRemoveItemModal = () => {
    setIsRemoveItemModalOpen(false);
  };

  // confirm remove modal
  // const closeConfirmRemoveModal = () => {
  //     setIsConfirmRemoveModalOpen(false);
  // }

  // add modal 1
  const closeAddModal1 = () => {
    setIsAddModal1Open(false);
  };

  // add modal 2
  const closeAddModal2 = () => {
    setIsAddModal2Open(false);
  };

  // add modal 3
  const closeAddModal3 = () => {
    setIsAddModal3Open(false);
  };

  // add to list modal
  const openAddToListModal = () => {
    setIsAddToListModalOpen(true);
  };

  const closeAddToListModal = () => {
    setIsAddToListModalOpen(false);
  };

  // create list modal
  const closeCreateListModal = () => {
    setIsCreateListModalOpen(false);
  };

  const handleChange = (e: any) => {
    setQuantity(e.target.value);
  };

  const handleBlur = (e: any) => {
    if (!e.target.value) {
      setQuantity("1");
    }
  };

  const increaseQuantity = () => {
    setQuantity(String(Number(quantity) + 1));
  };

  const decreaseQuantity = () => {
    if (Number(quantity) > 1) {
      setQuantity(String(Number(quantity) - 1));
    }
  };

  return (
    <>
      {product !== undefined ? (
        <CardStyled key={product.id}>
          <CardTop>
            <LastOrdered>
              <span>Last Ordered:</span>
              <Link href="#">{product.lastOrdered}</Link>
            </LastOrdered>
            <Trash onClick={openRemoveItemModal}>
              <img src={product.trashIcon.icon} alt="..." />
              <span>{product.trashIcon.desc}</span>
            </Trash>
            <Heart onClick={openAddToListModal}>
              <img src={product.heartIcon.icon} alt="..." />
              <span>{product.heartIcon.desc}</span>
            </Heart>
          </CardTop>
          <ProductImage onClick={openProductModal}>
            <img src={product.image} alt="..." />
          </ProductImage>
          <ProductDesc onClick={openProductModal}>
            <p title={product.name}>{product.name}</p>
          </ProductDesc>
          <OtherDetails>
            <Supplier>
              <p>
                <span>Supplier SKU#</span>
                <span>{product.supplierSku}</span>
              </p>
              <p>{product.price}</p>
            </Supplier>
            <MFR>
              <span>Mfr:</span>
              <span>{product.mfr}</span>
            </MFR>
            <NickName>
              <span>Your nickname(s):</span>
              <span>{product.nickname.join(" ")}</span>
            </NickName>
          </OtherDetails>
          <Bottom>
            {product.inCart ? (
              <GreenButton>
                <img src={product.cartIcon} alt="..." />
                <span>In Cart</span>
              </GreenButton>
            ) : (
              <BlueButton onClick={addProductToCart}>
                <img src={product.cartIcon} alt="..." />
                <span>Add to Cart</span>
              </BlueButton>
            )}
            {/* <Quantity>
                            <div onClick={decreaseQuantity}>
                                <img src={product.minus} alt="..." />
                            </div>
                            <p>{quantity}</p>
                            <div onClick={increaseQuantity}>
                                <img src={product.plus} alt="..." />
                            </div>
                        </Quantity> */}
            <Quantity>
              <div onClick={decreaseQuantity}>
                <img src={minusIcon.src} alt="..." />
              </div>
              <div>
                <input
                  type="text"
                  value={quantity}
                  onChange={handleChange}
                  onBlur={handleBlur}
                />
              </div>
              <div onClick={increaseQuantity}>
                <img src={plusIcon.src} alt="..." />
              </div>
            </Quantity>
          </Bottom>
          <ModalContainer>
            <ProductModal
              setIsOpen={setIsProductModalOpen}
              isOpen={isProductModalOpen}
              closeModal={closeProductModal}
              setIsAddToListModalOpen={setIsAddToListModalOpen}
              product={product}
            />

            <RemoveItemModal
              setIsOpen={setIsRemoveItemModalOpen}
              isOpen={isRemoveItemModalOpen}
              closeModal={closeRemoveItemModal}
              product={product}
            />

            {/* <ConfirmRemoveModal
                            setIsOpen={setIsConfirmRemoveModalOpen}
                            isOpen={isConfirmRemoveModalOpen}
                            closeModal={closeConfirmRemoveModal}
                            setIsAddModal1Open={setIsAddModal1Open}
                            product={product}
                        /> */}

            {/* <AddModal1
                            setIsOpen={setIsAddModal1Open}
                            isOpen={isAddModal1Open}
                            closeModal={closeAddModal1}
                            setIsAddModal2Open={setIsAddModal2Open}
                            product={product}
                        />

                        <AddModal2
                            setIsOpen={setIsAddModal2Open}
                            isOpen={isAddModal2Open}
                            closeModal={closeAddModal2}
                            setIsAddModal3Open={setIsAddModal3Open}
                            product={product}
                        />

                        <AddModal3
                            setIsOpen={setIsAddModal3Open}
                            isOpen={isAddModal3Open}
                            closeModal={closeAddModal3}
                            product={product}
                        /> */}

            <AddToListModal
              setIsOpen={setIsAddToListModalOpen}
              isOpen={isAddToListModalOpen}
              closeModal={closeAddToListModal}
              setIsCreateListModalOpen={setIsCreateListModalOpen}
            />

            <CreateListModal
              setIsOpen={setIsCreateListModalOpen}
              isOpen={isCreateListModalOpen}
              closeModal={closeCreateListModal}
            />
          </ModalContainer>
          {showAlert && (
            <AlertMessage message={"Item added to cart"} top={""} />
          )}
        </CardStyled>
      ) : null}
    </>
  );
};

export default Card;
