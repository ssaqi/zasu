import { PaginationStyled, PerPage, PerPageDropDown, Displaying, PreviousBtn, Numbers, NextBtn } from "@/styledComponents/supplies/pagination"
import { useEffect, useState } from "react"


const Pagination = ({ data, setPageData, itemsPerPage }: any) => {

    // const [currentPage, setCurrentPage] = useState(1);
    // const [recordsPerPage, setRecordsPerPage] = useState(itemsPerPage);
    // const [totalPages, setTotalPages] = useState(0);
    // const [visiblePages, setVisiblePages] = useState(0);
    // const [firstLoad, setFirstLoad] = useState(true);

    return (
        <PaginationStyled>
            <PerPage>
                <span>Show</span>
                <PerPageDropDown>
                    <span>9</span>
                    <img src="/images/supplies/chevron-down.svg" alt="..." />
                </PerPageDropDown>
                <span>products per page</span>
            </PerPage>
            <Displaying>
                Displaying 1 - 9 of 367 Products
            </Displaying>
        </PaginationStyled >
    )
}

export default Pagination
