import {
  SidebarStyled,
  Search,
  SearchTop,
  SearchInput,
  PrevPurchased,
  SupplierPref,
  SupplierDropdown,
  SupplierTop,
  Option,
  ManufacturerTop,
  ManufacturerInput,
  CategoriesSection,
  CategoriesTop,
  Categories,
  Category,
  More,
  SearchesContainer,
  SuggestionsContainer,
} from "@/styledComponents/supplies/sidebar";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getCategories,
  removeSearchQueryProducts,
  selectCategories,
  selectCategoriesCount,
  selectSearchQuery,
  setSearchQueryProducts,
  addfilterBy,
  removeFilterBy,
} from "@/store/productsSlice";
import { get, post } from "@/utils/fetch";

interface ISidebar {
  setOrderBy: Dispatch<SetStateAction<string>>;
}

const Sidebar: React.FC<ISidebar> = ({ setOrderBy }) => {
  const [prevPurchased, setPrevPurchased] = useState(false);
  const [showMoreCategories, setShowMoreCategories] = useState(false);
  // const categories = [
  //   "Adhesives",
  //   "Anesthetics",
  //   "Burs & Diamonds",
  //   "CAD/Cam",
  //   "Cros & Bridge",
  //   "Dispensing Syringes",
  //   "Disposables",
  //   "Endodontic Products",
  // ];
  const dispatch = useDispatch();
  const categories = useSelector(selectCategories);
  const categoryCount = useSelector(selectCategoriesCount);

  const searchQueries = useSelector(selectSearchQuery);
  const [suggestions, setSuggestions] = useState([]);
  const [query, setQuery] = useState("");

  const removeSearchQueries = (event: any) => {
    // @ts-ignore
    dispatch(removeSearchQueryProducts(searchQueries[event.target.id]));
  };

  const onEnter = (event: any) => {
    if (event.key === "Enter") {
      dispatch(
        // @ts-ignore
        setSearchQueryProducts(event.target.value)
      );
      setQuery("");
    }
  };

  const handleInput = (event: any) => {
    setQuery(event.target.value);
  };

  const getSuggestions = (query: string) => {
    get("users/product/suggestions?name=" + query).then((res: any) => {
      setSuggestions(res.data);
    });
  };

  const setSuggestedQuery = (event: any) => {
    dispatch(
      // @ts-ignore
      setSearchQueryProducts(suggestions[event.target.id])
    );
    setSuggestions([]);
    setQuery("");
  };

  // useEffect(() => {
  //   if (query.length > 3) {
  //     getSuggestions(query);
  //   }
  //   if (query.length <= 3) {
  //     setSuggestions([]);
  //   }
  // }, [query]);

  useEffect(() => {
    const delay = 200; // debounce delay in milliseconds
    const timerId = setTimeout(() => {
      // Perform search logic here using the updated searchTerm value
      console.log("Perform search:", query);
      if (query.length > 3) {
        getSuggestions(query);
      }
      if (query.length <= 3) {
        setSuggestions([]);
      }
    }, delay);

    return () => {
      clearTimeout(timerId);
    };
  }, [query]);

  useEffect(() => {
    dispatch(
      // @ts-ignore
      getCategories({ showMore: showMoreCategories })
    );
  }, [showMoreCategories]);

  useEffect(() => {
    if (prevPurchased) {
      setOrderBy("PreviouslyOrdered");
    } else {
      setOrderBy("");
    }
  }, [prevPurchased]);

  return (
    <SidebarStyled>
      <Search>
        <SearchTop>
          <p>Search & Filter</p>
          <button>Reset</button>
        </SearchTop>
        <SearchInput>
          <input
            type="text"
            placeholder="Search Products Here"
            value={query}
            onInput={handleInput}
            onKeyUp={onEnter}
          />
          <div>
            <img src="/images/supplies/search-dark.svg" alt="..." />
          </div>
        </SearchInput>
        {suggestions.length > 0 ? (
          <SuggestionsContainer>
            {suggestions.map((suggestion, index) => {
              // @ts-ignore
              return (
                <span key={index} id={`${index}`} onClick={setSuggestedQuery}>
                  {suggestion}
                </span>
              );
            })}
          </SuggestionsContainer>
        ) : null}
        {searchQueries.length > 0 ? (
          <SearchesContainer>
            {searchQueries.map((query, index) => {
              return (
                <div key={index}>
                  <span>{query}</span>
                  <img
                    id={String(index)}
                    src="/images/supplies/cross.svg"
                    alt=""
                    onClick={removeSearchQueries}
                  />
                </div>
              );
            })}
          </SearchesContainer>
        ) : null}
      </Search>
      <PrevPurchased>
        <input
          type="checkbox"
          id="prevPurchased"
          onChange={() => setPrevPurchased(!prevPurchased)}
          checked={prevPurchased}
        />
        <label htmlFor="prevPurchased">Previously Purchased Only</label>
      </PrevPurchased>
      <SupplierPref>
        <SupplierTop>Supplier Preference</SupplierTop>
        <SupplierDropdown>
          <div>
            <Option>Midwest Dental</Option>
          </div>
          <img src="/images/supplies/chevron-down.svg" alt="..." />
        </SupplierDropdown>
      </SupplierPref>
      <div>
        <ManufacturerTop>Manufacturers</ManufacturerTop>
        <ManufacturerInput>
          <input type="search" placeholder="Enter Manufacturer" />
          <div>
            <img src="/images/supplies/search-light.svg" alt="..." />
          </div>
        </ManufacturerInput>
      </div>
      <CategoriesSection>
        <CategoriesTop>Categories</CategoriesTop>
        <Categories>
          {categories?.map((category, index) => (
            <Category key={index}>
              <input
                type="checkbox"
                value={category.name}
                id={`category${index + 1}`}
                onChange={(e) => {
                  if (e.target.checked) {
                    dispatch(addfilterBy(e.target.value));
                  } else {
                    dispatch(removeFilterBy(e.target.value));
                  }
                }}
              />
              <label htmlFor={`category${index + 1}`}>{category.name}</label>
            </Category>
          ))}
        </Categories>
        {showMoreCategories ? (
          <More onClick={() => setShowMoreCategories(false)}>- Show less</More>
        ) : (
          <More onClick={() => setShowMoreCategories(true)}>
            + {categoryCount} more
          </More>
        )}
      </CategoriesSection>
    </SidebarStyled>
  );
};

export default Sidebar;
