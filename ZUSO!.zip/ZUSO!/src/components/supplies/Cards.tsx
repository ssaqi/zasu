import {
    CardsStyled,
} from "@/styledComponents/supplies/cards"
import React from 'react'
import Card from "./Card";


interface ICards {
    products: any[]
}

const Cards: React.FC<ICards> = ({ products }) => {

    return (
        <>
            <CardsStyled>
                {products && products.map((item: any, index: number) => (
                    <>
                        <Card product={item} key={index} />
                    </>
                ))}
            </CardsStyled>
        </>
    )
}

export default Cards
