import React from 'react'
import {
    AddModal1Styled, CloseIcon, ImageContainer, MarkMessage, ProductName, DetailsSection, Detail, ConfirmMessage,
    ButtonsContainer, AddButton, CancelButton
} from '@/styledComponents/supplies/modals/addModal1'
import { IProduct } from '@/store/productsSlice'
import closeIcon from 'public/images/supplies/removeItemModal/close-icon.svg'
import bgImage from 'public/images/supplies/removeItemModal/bg-image.png'
import Modal from 'react-modal'


interface AddModal1Props {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function,
    setIsAddModal2Open: Function,
    product: IProduct
}

const AddModal1: React.FC<AddModal1Props> = ({ setIsOpen, isOpen, closeModal, setIsAddModal2Open, product }) => {
    return (
        <>
            <Modal
                isOpen={isOpen}
                onRequestClose={() => closeModal()}
                style={{
                    content: {
                        top: '50%',
                        left: '50%',
                        right: 'auto',
                        bottom: 'auto',
                        marginRight: '-50%',
                        transform: 'translate(-50%, -50%)',
                        padding: '0'
                    }
                }}
            >
                {product !== undefined ?
                    <AddModal1Styled>
                        <CloseIcon src={closeIcon.src} onClick={() => setIsOpen(false)} width="15" height="15" alt="..." />
                        <ImageContainer>
                            <div>
                                <img src={bgImage.src} alt="..." />
                            </div>
                            <img src={product.image} alt="..." />
                        </ImageContainer>
                        <MarkMessage>
                            You&#39;ve previously marked this item:
                        </MarkMessage>
                        <ProductName>{product.name}</ProductName>
                        <DetailsSection>
                            <Detail>
                                <p>... as Do Not Order with the reason:</p>
                                <p>Wrong Size</p>
                            </Detail>
                            <Detail>
                                <p>... and you also marked:</p>
                                <p>No, I will NOT order this product again.</p>
                            </Detail>
                            <Detail>
                                <p>... with a note:</p>
                                <p>My notes here. My notes here. My notes here. My notes here. My notes here.</p>
                            </Detail>
                        </DetailsSection>
                        <ConfirmMessage>Are you sure you want to ORDER this product now?</ConfirmMessage>
                        <ButtonsContainer>
                            <AddButton onClick={() => setIsAddModal2Open(true)}>Yes, Add to cart</AddButton>
                            <CancelButton onClick={() => setIsOpen(false)}>Cancel</CancelButton>
                        </ButtonsContainer>
                    </AddModal1Styled>
                    : null}
            </Modal>
        </>
    )
}

export default AddModal1