import React from 'react'
import {
    CreateListModalStyled, ModalHeader, ModalBody, InputsContainer, ListName, Description,
    ButtonContainer, CreateListButton, CancelButton
} from '@/styledComponents/supplies/modals/createListModal'
import closeIcon from 'public/images/supplies/productModal/close-icon.svg'
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createList } from '@/store/listsSlice';
import Modal from 'react-modal'


interface CreateListModalProps {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function
}

const CreateListModal: React.FC<CreateListModalProps> = ({ setIsOpen, isOpen, closeModal }) => {
    const dispatch = useDispatch();

    const [inputs, setInputs] = useState({
        listName: '',
        items: 15,
        total: 39.95,
        description: ''
    });

    const handleChange = (e: any) => {
        const name = e.target.id;
        const value = e.target.value;
        setInputs(prevValue => ({ ...prevValue, [name]: value }))
    }

    const handleSubmit = (e: any) => {
        e.preventDefault();
        // @ts-ignore
        dispatch(createList(inputs));
        setInputs({
            listName: '',
            items: 15,
            total: 39.95,
            description: ''
        });
        closeModal();
    }

    return (
        <Modal
            isOpen={isOpen}
            onRequestClose={() => closeModal()}
            style={{
                content: {
                    top: '50%',
                    left: '50%',
                    right: 'auto',
                    bottom: 'auto',
                    marginRight: '-50%',
                    transform: 'translate(-50%, -50%)',
                    padding: '0'
                }
            }}
        >
            <CreateListModalStyled>
                <ModalHeader>
                    <p>Create List</p>
                    <img src={closeIcon.src} alt="..." onClick={() => setIsOpen(false)} />
                </ModalHeader>
                <ModalBody onSubmit={handleSubmit}>
                    <InputsContainer>
                        <ListName>
                            <label htmlFor="listName">List Name:</label>
                            <input id="listName" type="text" placeholder="Enter text here" value={inputs.listName || ''} onChange={handleChange} required={true} />
                        </ListName>
                        <Description>
                            <label htmlFor="description">Description:</label>
                            <textarea id="description" placeholder="Enter text here" value={inputs.description || ''} onChange={handleChange} required={true}></textarea>
                        </Description>
                    </InputsContainer>
                    <ButtonContainer>
                        <CreateListButton type="submit">Create list</CreateListButton>
                        <CancelButton onClick={() => setIsOpen(false)}>Cancel</CancelButton>
                    </ButtonContainer>
                </ModalBody>
            </CreateListModalStyled>
        </Modal>
    )
}

export default CreateListModal