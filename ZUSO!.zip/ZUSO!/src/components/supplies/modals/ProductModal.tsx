import {
  ProductModalStyled,
  ModalHeader,
  ModalBody,
  ModalBreadcrumb,
  ModalColumns,
  ImageColumn,
  ContentColumn,
  ProductName,
  ProductDetails,
  ProductDetailsLeft,
  ProductDetailContainer,
  ProductDetailsRight,
  InputContainer,
  Tag,
  MoreDetails,
  Price,
  CenterPara,
  SKU,
  ButtonsSection,
  GreenButton,
  BlueButton,
  Quantity,
  AddToList,
  ProductDescription,
  FurtherDetails,
  FurtherDetailsLeft,
  FurtherDetailContainer,
  FurtherDetailsRight,
  SafetyData,
  ProductSpecs,
  ProductSpecsTop,
  ProductSpecsBody,
  ModalFooter,
  Tags,
} from "@/styledComponents/supplies/modals/productModal";
import React from "react";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  addProductTag,
  getProduct,
  product,
  removeProductTag,
} from "@/store/productsSlice";
import {
  addToCart,
  selectCartSubtotal,
  updateSubtotal,
} from "../../../store/cartSlice";
import closeIcon from "public/images/supplies/productModal/close-icon.svg";
import plusIcon from "public/images/supplies/card/plus.svg";
import minusIcon from "public/images/supplies/card/minus.svg";
import cartIcon from "public/images/supplies/card/cart.svg";
import tagPlusIcon from "public/images/supplies/productModal/search-plus-icon.svg";
import tagRemoveIcon from "public/images/supplies/productModal/tag-close-icon.svg";
import listIcon from "public/images/supplies/productModal/add-to-list-icon.svg";
import footerIcon from "public/images/supplies/productModal/footer-icon.svg";
import chevronUpIcon from "public/images/supplies/productModal/chevron-up.svg";
import AlertMessage from "@/components/AlertMessage";
import Modal from "react-modal";
import { Span } from "@/styledComponents/catalog";

interface ProductModalProps {
  setIsOpen: Function;
  isOpen: boolean;
  closeModal: Function;
  setIsAddToListModalOpen: Function;
  product: any;
}

const ProductModal: React.FC<ProductModalProps> = ({
  setIsOpen,
  isOpen,
  closeModal,
  setIsAddToListModalOpen,
  product,
}) => {
  const dispatch = useDispatch();
  // const _product = useSelector(product);

  // useEffect(() => {
  //     dispatch(
  //         // @ts-ignore
  //         getProduct(productName)
  //     )
  // }, [])

  const [specsIsOpen, setSpecsIsOpen] = useState(false);
  const [productImgSrc, setProductImgSrc] = useState("");
  const [showAlert, setShowAlert] = useState(false);
  const [quantity, setQuantity] = useState("1");
  const subtotal = useSelector(selectCartSubtotal);
  const [tags, setTags] = useState([]);
  const [tag, setTag] = useState("");

  useEffect(() => {
    if (product !== undefined) {
      setProductImgSrc(product.image);
      setTags(product.nickname);
    }
  }, [product]);

  const displayAlert = () => {
    setShowAlert(true);
    setTimeout(() => {
      setShowAlert(false);
    }, 3000);
  };

  const addProductToCart = () => {
    const price = Number(product.price) * Number(quantity);
    dispatch(
      // @ts-ignore
      addToCart({
        id: product.id,
        name: product.name,
        image: product.image,
        price: Number(product.price),
        cartPrice: price,
        supplierSku: product.supplierSku,
        productQuantity: product.productQuantity,
        caseQuantity: product.caseQuantity,
        quantity: Number(quantity),
        mpn: product.mpn,
      })
    );
    dispatch(updateSubtotal(subtotal + price));
    displayAlert();
    setQuantity("1");
  };

  const changeImage = (e: any) => {
    setProductImgSrc(e.target.src);
  };

  const increaseQuantity = () => {
    setQuantity(String(Number(quantity) + 1));
  };

  const decreaseQuantity = () => {
    if (Number(quantity) > 1) {
      setQuantity(String(Number(quantity) - 1));
    }
  };

  const handleChange = (e: any) => {
    setQuantity(e.target.value);
  };

  const handleBlur = (e: any) => {
    if (!e.target.value) {
      setQuantity("1");
    }
  };

  const addTag = (e: any) => {
    dispatch(
      // @ts-ignore
      addProductTag({ productId: product.id, tag: tag })
    );
    setTag("");
  };

  const removeTag = (tag: string) => {
    dispatch(
      // @ts-ignore
      removeProductTag({ productId: product.id, tag: tag })
    );
  };

  const onEnter = (event: any) => {
    if (event.key === "Enter") {
      addTag(event);
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onRequestClose={() => closeModal()}
        style={{
          content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            padding: "0",
            zIndex: "1000",
          },
        }}
      >
        <ProductModalStyled>
          <ModalHeader>
            <p>Product Info</p>
            <img
              src={closeIcon.src}
              alt="..."
              onClick={() => setIsOpen(false)}
            />
          </ModalHeader>
          {product !== undefined ? (
            <ModalBody>
              <ModalColumns>
                <ImageColumn>
                  <div>
                    <img src={productImgSrc} alt="..." />
                  </div>
                  <div>
                    <img
                      src={product.image}
                      alt="..."
                      onMouseEnter={changeImage}
                    />
                    <img
                      src="/images/supplies/productModal/smImage2.png"
                      alt="..."
                      onMouseEnter={changeImage}
                    />
                    <img
                      src="/images/supplies/productModal/smImage3.png"
                      alt="..."
                      onMouseEnter={changeImage}
                    />
                  </div>
                </ImageColumn>
                <ContentColumn>
                  <ModalBreadcrumb>
                    <p>{product.category}</p>
                    <span>&#62;</span>
                    <p>{product.subCategory}</p>

                    {product.subSubCategory ? (
                      <span>&#62;</span>
                    ) : (
                      <span></span>
                    )}
                    <p> {product.subSubCategory}</p>
                  </ModalBreadcrumb>
                  <ProductName>{product.name}</ProductName>
                  <ProductDetails>
                    <ProductDetailsLeft>
                      <ProductDetailContainer>
                        <p>MPN#</p>
                        <p>{product.mpn}</p>
                      </ProductDetailContainer>
                      <ProductDetailContainer>
                        <p>Manufacturer:</p>
                        <p>{product.mfr}</p>
                      </ProductDetailContainer>
                      <ProductDetailContainer>
                        <p>Brand:</p>
                        <p>{product.brand}</p>
                      </ProductDetailContainer>
                      <ProductDetailContainer>
                        <p>Last Ordered:</p>
                        <p>{product.lastOrdered}</p>
                      </ProductDetailContainer>
                    </ProductDetailsLeft>
                    <ProductDetailsRight>
                      <p>Nicknames for this product:</p>
                      <InputContainer>
                        <input
                          type="text"
                          placeholder="Type new tag name here"
                          value={tag}
                          onKeyUp={onEnter}
                          onChange={(e) => setTag(e.target.value)}
                        />
                        <div onClick={addTag}>
                          <img src={tagPlusIcon.src} alt="..." />
                        </div>
                      </InputContainer>
                      <Tags>
                        {tags.map((item: any) => {
                          return (
                            <Tag key={`${item}`}>
                              <p>{item}</p>
                              <img
                                onClick={() => removeTag(item)}
                                src={tagRemoveIcon.src}
                                alt="..."
                              />
                            </Tag>
                          );
                        })}
                      </Tags>
                    </ProductDetailsRight>
                  </ProductDetails>
                  <MoreDetails>
                    <Price>
                      <span>$</span>
                      <p>{product.price}</p>
                    </Price>
                    <CenterPara>Midwest Dental</CenterPara>
                    <SKU>
                      <p>SKU:</p>
                      <p>{product.supplierSku}</p>
                    </SKU>
                  </MoreDetails>
                  <ButtonsSection>
                    <Quantity>
                      <div onClick={decreaseQuantity}>
                        <img src={minusIcon.src} alt="..." />
                      </div>
                      <div>
                        <input
                          type="text"
                          value={quantity}
                          onChange={handleChange}
                          onBlur={handleBlur}
                        />
                      </div>
                      <div onClick={increaseQuantity}>
                        <img src={plusIcon.src} alt="..." />
                      </div>
                    </Quantity>
                    {product.inCart ? (
                      <GreenButton>
                        <img src={cartIcon.src} alt="..." />
                        <span>In Cart</span>
                      </GreenButton>
                    ) : (
                      <BlueButton onClick={addProductToCart}>
                        <img src={cartIcon.src} alt="..." />
                        <span>Add to Cart</span>
                      </BlueButton>
                    )}
                    <AddToList onClick={() => setIsAddToListModalOpen(true)}>
                      <img src={listIcon.src} alt="..." />
                      <span>Add to List</span>
                    </AddToList>
                  </ButtonsSection>
                  <ProductDescription>
                    <h3>Description</h3>
                    <p>{product.description}</p>
                  </ProductDescription>
                  <FurtherDetails>
                    <FurtherDetailsLeft>
                      <FurtherDetailContainer>
                        <p>Package Quantity:</p>
                        <p>{product.productQuantity}</p>
                      </FurtherDetailContainer>
                      <FurtherDetailContainer>
                        <p>Case Quantity:</p>
                        <p>{product.caseQuantity}</p>
                      </FurtherDetailContainer>
                      <FurtherDetailContainer>
                        <p>Weight:</p>
                        <p>{product.weight}</p>
                      </FurtherDetailContainer>
                      <ProductDetailContainer>
                        <p>Size:</p>
                        <p>{product.size}</p>
                      </ProductDetailContainer>
                    </FurtherDetailsLeft>
                    <FurtherDetailsRight>
                      <ProductDetailContainer>
                        <p>Shade Type:</p>
                        <p>{product.shadeType}</p>
                      </ProductDetailContainer>
                      <ProductDetailContainer>
                        <p>Composite:</p>
                        <p>{product.composition}</p>
                      </ProductDetailContainer>
                    </FurtherDetailsRight>
                  </FurtherDetails>
                  <SafetyData>
                    <p>Safety Data Sheet:</p>
                    {product.dataSheetPdf ? (
                      <p>{product.dataSheetPdf}</p>
                    ) : (
                      <p>Not available currently</p>
                    )}
                  </SafetyData>
                  <ProductSpecs>
                    <ProductSpecsTop
                      onClick={() => setSpecsIsOpen(!specsIsOpen)}
                    >
                      <p>Product Specs</p>
                      <img
                        className={specsIsOpen ? "is-open" : ""}
                        src={chevronUpIcon.src}
                        alt="..."
                      />
                    </ProductSpecsTop>
                    <ProductSpecsBody className={specsIsOpen ? "is-open" : ""}>
                      {product.productSpecs ? (
                        <p> {product.productSpecs}</p>
                      ) : (
                        <p>
                          {" "}
                          Contains: 4 (40 g) GEO Expert modeling waxes, 1 of
                          each shade: enamel, translucent, sculpture, dentin; 4
                          (4 g) GEO Expert Effect waxes, 1 of each color: white,
                          orange, blue, brown; 1 manual with step-by-step
                          instructions | Package Quantity: 1/Pkg
                        </p>
                      )}
                    </ProductSpecsBody>
                  </ProductSpecs>
                </ContentColumn>
              </ModalColumns>
              <ModalFooter>
                <img src={footerIcon.src} alt="..." />
                <p>
                  Please note the information for products, including pricing
                  and stock info, may not be fully up to date. Take it as a
                  reference only.
                </p>
              </ModalFooter>
            </ModalBody>
          ) : null}
        </ProductModalStyled>
      </Modal>
      {showAlert && (
        <AlertMessage message={"Item added to cart"} top={"56px"} />
      )}
    </>
  );
};

export default ProductModal;
