import React from "react";
import {
  SpecialOrderModalStyled,
  ModalHeader,
  ModalBody,
  InputContainer,
  NotesInfo,
  UploadPhoto,
  Quantity,
  ButtonsContainer,
  AddButton,
  ClearButton,
} from "@/styledComponents/supplies/modals/specialOrderModal";
import closeIcon from "public/images/supplies/productModal/close-icon.svg";
import plusIcon from "public/images/supplies/card/plus.svg";
import minusIcon from "public/images/supplies/card/minus.svg";
import uploadIcon from "public/images/supplies/specialOrderModal/upload-icon.svg";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addSpecialOrder, selectSpecialOrderitems } from "@/store/cartSlice";
import Modal from "react-modal";

interface SpecialOrderModalProps {
  setIsOpen: Function;
  isOpen: boolean;
  closeModal: Function;
}

const SpecialOrderModal: React.FC<SpecialOrderModalProps> = ({
  setIsOpen,
  isOpen,
  closeModal,
}) => {
  const dispatch = useDispatch();
  const items = useSelector(selectSpecialOrderitems);

  const [manufacturer, setManufacturer] = useState("");
  const [mfrPartNumber, setMfrPartNumber] = useState("");
  const [productName, setProductName] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [supplier, setSupplier] = useState("Special Order");
  const [notes, setNotes] = useState("");
  const [photo, setPhoto] = useState("");

  const clearValues = () => {
    setManufacturer("");
    setMfrPartNumber("");
    setProductName("");
    setQuantity("1");
    setNotes("");
    setPhoto("");
  };

  const addToCart = (e: any) => {
    e.preventDefault();
    dispatch(
        // @ts-ignore
      addSpecialOrder({
        manufacturer: manufacturer,
        mfrPartNumber: mfrPartNumber,
        productName: productName,
        quantity: Number(quantity),
        supplier: supplier,
        notes: notes,
        photo: photo,
      })
    );
    clearValues();
    console.log(items);
    closeModal();
  };

  const increaseQuantity = () => {
    setQuantity(String(Number(quantity) + 1));
  };

  const decreaseQuantity = () => {
    if (Number(quantity) > 1) {
      setQuantity(String(Number(quantity) - 1));
    }
  };

  const handleChange = (e: any) => {
    setQuantity(e.target.value);
  };

  const handleBlur = (e: any) => {
    if (!e.target.value) {
      setQuantity("1");
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={() => closeModal()}
      style={{
        content: {
          top: "50%",
          left: "50%",
          right: "auto",
          bottom: "auto",
          marginRight: "-50%",
          transform: "translate(-50%, -50%)",
          padding: "0",
        },
      }}
    >
      <SpecialOrderModalStyled onSubmit={addToCart}>
        <ModalHeader>
          <p>Special Order Product</p>
          <img src={closeIcon.src} alt="..." onClick={() => setIsOpen(false)} />
        </ModalHeader>
        <ModalBody id="specialOrderForm">
          <InputContainer>
            <div>
              <label>Manufacturer:</label>
            </div>
            <div>
              <input
                type="text"
                placeholder="Unknown"
                value={manufacturer}
                onChange={(e) => setManufacturer(e.target.value)}
                required={true}
              />
            </div>
          </InputContainer>
          <InputContainer>
            <div>
              <label>Manufacturer Part Number:</label>
            </div>
            <div>
              <input
                type="text"
                placeholder="Unknown"
                value={mfrPartNumber}
                onChange={(e) => setMfrPartNumber(e.target.value)}
                required={true}
              />
            </div>
          </InputContainer>
          <InputContainer>
            <div>
              <label>Product Name:</label>
            </div>
            <div>
              <input
                type="text"
                placeholder="Unknown"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                required={true}
              />
            </div>
          </InputContainer>
          <InputContainer>
            <div>
              <label>Quantity Needed:</label>
            </div>
            <div>
              <Quantity>
                <div onClick={decreaseQuantity}>
                  <img src={minusIcon.src} alt="..." />
                </div>
                <div>
                  <input
                    type="text"
                    value={quantity}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                </div>
                <div onClick={increaseQuantity}>
                  <img src={plusIcon.src} alt="..." />
                </div>
              </Quantity>
            </div>
          </InputContainer>
          <InputContainer>
            <div>
              <label>
                Supplier Last
                <br />
                Purchased From:
              </label>
            </div>
            <div>
              <input
                type="text"
                placeholder="Unknown"
                defaultValue={supplier}
                disabled
                // onChange={(e) => setSupplier(e.target.value)}
              />
            </div>
          </InputContainer>
          <NotesInfo>
            <div>
              <label>Notes/Additional Info:</label>
            </div>
            <div>
              <textarea
                rows={4}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              ></textarea>
            </div>
          </NotesInfo>
          <UploadPhoto>
            <div>
              <label>Upload Photo:</label>
            </div>
            <div>
              <img src={uploadIcon.src} alt="upload" width="26" height="26" />
              <p>
                Drop an image or <span>click here</span>
              </p>
            </div>
          </UploadPhoto>
        </ModalBody>
        <ButtonsContainer>
          <AddButton type="submit">Add item to cart</AddButton>
          <ClearButton type="button" onClick={clearValues}>
            Clear
          </ClearButton>
        </ButtonsContainer>
      </SpecialOrderModalStyled>
    </Modal>
  );
};

export default SpecialOrderModal;
