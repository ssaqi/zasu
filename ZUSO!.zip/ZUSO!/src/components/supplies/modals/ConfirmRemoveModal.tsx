import React from 'react'
import {
    ConfirmRemoveModalStyled, CloseIcon, ImageContainer, RemovalMessage, ProductName, DetailsSection, Detail, ConfirmMessage,
    ButtonsContainer, RemoveButton, BackButton
} from '@/styledComponents/supplies/modals/confirmRemoveModal'
import closeIcon from 'public/images/supplies/removeItemModal/close-icon.svg'
import bgImage from 'public/images/supplies/removeItemModal/bg-image.png'
import { IProduct } from '@/store/productsSlice'
import Modal from 'react-modal'
import { useDispatch, useSelector } from 'react-redux'
import { addToRemovedItems, selectRemovedItems } from '@/store/donotOrderAgainSlice'


interface ConfirmRemoveModalProps {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function,
    setIsRemoveItemModalOpen: Function,
    product: IProduct,
    option1: string,
    option2: string,
    shortNote: string
}

const ConfirmRemoveModal: React.FC<ConfirmRemoveModalProps> = ({ setIsOpen, isOpen, closeModal, setIsRemoveItemModalOpen, product, option1, option2, shortNote }) => {
    const dispatch = useDispatch();
    const removedItems = useSelector(selectRemovedItems);

    // console.log(removedItems);

    const confirmRemovingItem = () => {
        // @ts-ignore
        dispatch(addToRemovedItems({
            id: product.id,
            productName: product.name,
            option1: option1,
            option2: option2,
            shortNote: shortNote
        }))
        setIsOpen(false);
        setIsRemoveItemModalOpen(false);
    }

    return (
        <Modal
            isOpen={isOpen}
            onRequestClose={() => closeModal()}
            style={{
                content: {
                    top: '50%',
                    left: '50%',
                    right: 'auto',
                    bottom: 'auto',
                    marginRight: '-50%',
                    transform: 'translate(-50%, -50%)',
                    padding: '0'
                }
            }}
        >
            <>
                {product !== undefined ?
                    <ConfirmRemoveModalStyled>
                        <CloseIcon src={closeIcon.src} onClick={() => setIsOpen(false)} width="15" height="15" alt="..." />
                        <ImageContainer>
                            <div>
                                <img src={bgImage.src} alt="..." />
                            </div>
                            <img src={product.image} alt="..." />
                        </ImageContainer>
                        <RemovalMessage>
                            You are about to remove this product<br />from your Previously Purchased list:
                        </RemovalMessage>
                        <ProductName>{product.name}</ProductName>
                        <DetailsSection>
                            <Detail>
                                <p>... as Do Not Order with the reason:</p>
                                <p>{option1}</p>
                            </Detail>
                            <Detail>
                                <p>... and you also marked:</p>
                                <p>{option2}</p>
                            </Detail>
                            <Detail>
                                <p>... with a note:</p>
                                <p>{shortNote}</p>
                            </Detail>
                        </DetailsSection>
                        <ConfirmMessage>Are you sure you want to CONFIRM this?</ConfirmMessage>
                        <ButtonsContainer>
                            <RemoveButton onClick={confirmRemovingItem}>Confirm Removing Item</RemoveButton>
                            <BackButton onClick={() => setIsOpen(false)}>Go Back</BackButton>
                        </ButtonsContainer>
                    </ConfirmRemoveModalStyled>
                    : null}
            </>
        </Modal>
    )
}

export default ConfirmRemoveModal