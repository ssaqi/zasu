import React, { useState } from "react";
import {
  AddToListModalStyled,
  ModalHeader,
  ModalBody,
  ListsTable,
  NoListsFound,
  ImageContainer,
  NoListsText,
  ButtonContainer,
} from "@/styledComponents/supplies/modals/addToListModal";
import closeIcon from "public/images/supplies/productModal/close-icon.svg";
import plusIcon from "public/images/supplies/addToListModal/plus-icon.svg";
import noListsIcon from "public/images/supplies/addToListModal/no-lists-icon.svg";
import bgImage from "public/images/supplies/removeItemModal/bg-image.png";
import { useSelector, useDispatch } from "react-redux";
import { getLists, selectLists } from "@/store/listsSlice";
import { useEffect } from "react";
import Modal from "react-modal";
import AlertMessage from "@/components/AlertMessage";

interface AddToListModalProps {
  setIsOpen: Function;
  isOpen: boolean;
  closeModal: Function;
  setIsCreateListModalOpen: Function;
}

const AddToListModal: React.FC<AddToListModalProps> = ({
  setIsOpen,
  isOpen,
  closeModal,
  setIsCreateListModalOpen,
}) => {
  const lists = useSelector(selectLists);
  const [showAlert, setShowAlert] = useState(false);

  // const dispatch = useDispatch();

  // useEffect(() => {
  //     // @ts-ignore
  //     dispatch(getLists());
  // }, [])

  const displayAlert = () => {
    setShowAlert(true);
    setTimeout(() => {
      setShowAlert(false);
    }, 3000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={() => closeModal()}
      style={{
        content: {
          top: "50%",
          left: "50%",
          right: "auto",
          bottom: "auto",
          marginRight: "-50%",
          transform: "translate(-50%, -50%)",
          padding: "0",
        },
      }}
    >
      <AddToListModalStyled>
        <ModalHeader>
          <p>Add to List</p>
          <img src={closeIcon.src} alt="..." onClick={() => setIsOpen(false)} />
        </ModalHeader>
        <ModalBody>
          {Boolean(lists.length) ? (
            <ListsTable>
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {lists.map((item, index) => (
                    <tr key={index}>
                      <td>{item.listName}</td>
                      <td>
                        <span>{item.items} items</span>
                      </td>
                      <td>${item.total}</td>
                      <td>
                        <span>
                          <img
                            onClick={displayAlert}
                            src={plusIcon.src}
                            alt="Add"
                            width="10"
                            height="10"
                          />
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </ListsTable>
          ) : (
            <NoListsFound>
              <ImageContainer>
                <div>
                  <img src={bgImage.src} alt="..." />
                </div>
                <img src={noListsIcon.src} alt="..." />
              </ImageContainer>
              <NoListsText>
                <h3>No lists found</h3>
                <p>Create a new list by clicking the button below.</p>
              </NoListsText>
            </NoListsFound>
          )}
          <ButtonContainer>
            <button onClick={() => setIsCreateListModalOpen(true)}>
              Create a new list
            </button>
          </ButtonContainer>
        </ModalBody>
      </AddToListModalStyled>
      {showAlert && <AlertMessage message={"Item added to list"} top={""} />}
    </Modal>
  );
};

export default AddToListModal;
