import React from 'react'
import {
    RemoveItemModalStyled, CloseIcon, ImageContainer, RemovalMessage, ProductName,
    DropdownsContainer, DropdownContainer, DropdownMenu, MenuOptions, ShortNote, ButtonsContainer, RemoveButton, CancelButton
} from '@/styledComponents/supplies/modals/removeItemModal'
import { useState, useEffect } from 'react'
import closeIcon from 'public/images/supplies/removeItemModal/close-icon.svg'
import bgImage from 'public/images/supplies/removeItemModal/bg-image.png'
import chevronDown from 'public/images/supplies/removeItemModal/chevron-down.svg'
import { IProduct } from '@/store/productsSlice'
import Modal from 'react-modal'
import ConfirmRemoveModal from './ConfirmRemoveModal'


interface RemoveItemModalProps {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function,
    product: IProduct
}

const RemoveItemModal: React.FC<RemoveItemModalProps> = ({ setIsOpen, isOpen, closeModal, product }) => {
    const [options1Shown, setOptions1Shown] = useState(false);
    const [options2Shown, setOptions2Shown] = useState(false);
    const [dropdown1Title, setDropdown1Title] = useState('Wrong size');
    const [dropdown2Title, setDropdown2Title] = useState('No, I will NOT order this product again.');
    const [shortNote, setShortNote] = useState('');
    const [isConfirmRemoveModalOpen, setIsConfirmRemoveModalOpen] = useState(false);

    useEffect(() => {
        // reset values if user clicks confirm removing item button in ConfirmRemoveModal
        if (!isOpen) {
            setDropdown1Title('Wrong size');
            setDropdown2Title('No, I will NOT order this product again.');
            setShortNote('');
        }
    }, [isOpen])

    // confirm remove modal
    const closeConfirmRemoveModal = () => {
        setIsConfirmRemoveModalOpen(false);
    }

    const changeTitle1 = (e: any) => {
        setDropdown1Title(e.target.innerText);
    }

    const changeTitle2 = (e: any) => {
        setDropdown2Title(e.target.innerText);
    }

    return (
        <>
            <Modal
                isOpen={isOpen}
                onRequestClose={() => {
                    closeModal();
                    setDropdown1Title('Wrong size');
                    setDropdown2Title('No, I will NOT order this product again.');
                    setShortNote('');
                }}
                style={{
                    content: {
                        top: '50%',
                        left: '50%',
                        right: 'auto',
                        bottom: 'auto',
                        marginRight: '-50%',
                        transform: 'translate(-50%, -50%)',
                        padding: '0'
                    }
                }}
            >
                {product !== undefined ?
                    <RemoveItemModalStyled>
                        <CloseIcon src={closeIcon.src} onClick={() => setIsOpen(false)} width="15" height="15" alt="..." />
                        <ImageContainer>
                            <div>
                                <img src={bgImage.src} alt="..." />
                            </div>
                            <img src={product.image} alt="..." />
                        </ImageContainer>
                        <RemovalMessage>
                            You are about to remove this product<br />from your Previously Purchased list:
                        </RemovalMessage>
                        <ProductName>{product.name}</ProductName>
                        <DropdownsContainer>
                            <DropdownContainer>
                                <p>Please tell us why you re removing it:</p>
                                <DropdownMenu onClick={() => setOptions1Shown(!options1Shown)}>
                                    <p>{dropdown1Title}</p>
                                    <img src={chevronDown.src} alt="..." />
                                    <MenuOptions className={options1Shown ? 'shown' : ''}>
                                        <p onClick={changeTitle1}>Wrong Size</p>
                                        <p onClick={changeTitle1}>Wrong Shade</p>
                                        <p onClick={changeTitle1}>Do Not Like Product</p>
                                        <p onClick={changeTitle1}>Wrong Item Ordered</p>
                                        <p onClick={changeTitle1}>Too Expensive</p>
                                        <p onClick={changeTitle1}>Wrong Package Size (ie. 5 pack vs 1 pack)</p>
                                        <p onClick={changeTitle1}>Other (describe in notes section below)</p>
                                    </MenuOptions>
                                </DropdownMenu>
                            </DropdownContainer>
                            <DropdownContainer>
                                <p>Will you order this product again?</p>
                                <DropdownMenu onClick={() => setOptions2Shown(!options2Shown)}>
                                    <p>{dropdown2Title}</p>
                                    <img src={chevronDown.src} alt="..." />
                                    <MenuOptions className={options2Shown ? 'shown' : ''} style={{ bottom: '-190%' }}>
                                        <p onClick={changeTitle2}>Yes, I will order this product again.</p>
                                        <p onClick={changeTitle2}>No, I will not order this product again.</p>
                                    </MenuOptions>
                                </DropdownMenu>
                            </DropdownContainer>
                            <ShortNote>
                                <label>Short note for yourself:</label>
                                <input type="text" value={shortNote} onChange={(e) => setShortNote(e.target.value)} />
                            </ShortNote>
                        </DropdownsContainer>
                        <ButtonsContainer>
                            <RemoveButton onClick={() => setIsConfirmRemoveModalOpen(true)}>Remove Item</RemoveButton>
                            <CancelButton onClick={() => setIsOpen(false)}>Cancel</CancelButton>
                        </ButtonsContainer>
                    </RemoveItemModalStyled>
                    : null}
            </Modal>
            <ConfirmRemoveModal
                setIsOpen={setIsConfirmRemoveModalOpen}
                isOpen={isConfirmRemoveModalOpen}
                closeModal={() => closeConfirmRemoveModal()}
                setIsRemoveItemModalOpen={setIsOpen}
                product={product}
                option1={dropdown1Title}
                option2={dropdown2Title}
                shortNote={shortNote}
            />
        </>
    )
}

export default RemoveItemModal