import React from 'react'
import {
    AddModal3Styled, CloseIcon, ImageContainer, ProductName, DetailsSection, Detail, ConfirmMessage,
    ButtonsContainer, AddButton, CancelButton
} from '@/styledComponents/supplies/modals/addModal3'
import { IProduct } from '@/store/productsSlice'
import closeIcon from 'public/images/supplies/removeItemModal/close-icon.svg'
import bgImage from 'public/images/supplies/removeItemModal/bg-image.png'
import Modal from 'react-modal'


interface AddModal3Props {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function,
    product: IProduct
}

const AddModal3: React.FC<AddModal3Props> = ({ setIsOpen, isOpen, closeModal, product }) => {
    return (
        <>
            <Modal
                isOpen={isOpen}
                onRequestClose={() => closeModal()}
                style={{
                    content: {
                        top: '50%',
                        left: '50%',
                        right: 'auto',
                        bottom: 'auto',
                        marginRight: '-50%',
                        transform: 'translate(-50%, -50%)',
                        padding: '0'
                    }
                }}
            >
                {product !== undefined ?
                    <AddModal3Styled>
                        <CloseIcon src={closeIcon.src} onClick={() => setIsOpen(false)} width="15" height="15" alt="..." />
                        <ImageContainer>
                            <div>
                                <img src={bgImage.src} alt="..." />
                            </div>
                            <img src={product.image} alt="..." />
                        </ImageContainer>
                        <ProductName>{product.name}</ProductName>
                        <DetailsSection>
                            <Detail>
                                <p>You&#39;ve been using <span>8 pcs</span> of this product<br />for the last <span>8 weeks</span>.</p>
                            </Detail>
                            <Detail>
                                <p>
                                    ZuSo recommends buying <span>8 pcs</span><br /> at this time, but you can order the<br /> lower quantity you selected if you wish.
                                </p>
                            </Detail>
                        </DetailsSection>
                        <ConfirmMessage>Do you want to continue?</ConfirmMessage>
                        <ButtonsContainer>
                            <AddButton>Yes, Add to cart</AddButton>
                            <CancelButton onClick={() => setIsOpen(false)}>Cancel</CancelButton>
                        </ButtonsContainer>
                    </AddModal3Styled>
                    : null}
            </Modal>
        </>
    )
}

export default AddModal3