import React from 'react'
import {
    AddModal2Styled, CloseIcon, ImageContainer, ProductName, DetailsSection, Detail, ConfirmMessage,
    ButtonsContainer, AddButton, CancelButton
} from '@/styledComponents/supplies/modals/addModal2'
import { IProduct } from '@/store/productsSlice'
import closeIcon from 'public/images/supplies/removeItemModal/close-icon.svg'
import bgImage from 'public/images/supplies/removeItemModal/bg-image.png'
import Modal from 'react-modal'


interface AddModal2Props {
    setIsOpen: Function,
    isOpen: boolean,
    closeModal: Function,
    setIsAddModal3Open: Function,
    product: IProduct
}

const AddModal2: React.FC<AddModal2Props> = ({ setIsOpen, isOpen, closeModal, setIsAddModal3Open, product }) => {
    return (
        <>
            <Modal
                isOpen={isOpen}
                onRequestClose={() => closeModal()}
                style={{
                    content: {
                        top: '50%',
                        left: '50%',
                        right: 'auto',
                        bottom: 'auto',
                        marginRight: '-50%',
                        transform: 'translate(-50%, -50%)',
                        padding: '0'
                    }
                }}
            >
                {product !== undefined ?
                    <AddModal2Styled>
                        <CloseIcon src={closeIcon.src} onClick={() => setIsOpen(false)} width="15" height="15" alt="..." />
                        <ImageContainer>
                            <div>
                                <img src={bgImage.src} alt="..." />
                            </div>
                            <img src={product.image} alt="..." />
                        </ImageContainer>
                        <ProductName>{product.name}</ProductName>
                        <DetailsSection>
                            <Detail>
                                <p>You&#39;ve been using <span>8 pcs</span> of this product for the last <span>8 weeks</span>.</p>
                            </Detail>
                            <Detail>
                                <p>Adding more would be unnecessary,<br />but you can.</p>
                            </Detail>
                        </DetailsSection>
                        <ConfirmMessage>Do you want to continue?</ConfirmMessage>
                        <ButtonsContainer>
                            <AddButton onClick={() => setIsAddModal3Open(true)}>Yes, Add to cart</AddButton>
                            <CancelButton onClick={() => setIsOpen(false)}>Cancel</CancelButton>
                        </ButtonsContainer>
                    </AddModal2Styled>
                    : null}
            </Modal>
        </>
    )
}

export default AddModal2