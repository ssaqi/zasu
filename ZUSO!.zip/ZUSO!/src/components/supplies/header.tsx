import {
    AddSpecialOrderButton,
    Header,
    SortBy,
    SortByDropdown,
    MainHeading,
} from "@/styledComponents/supplies/supplies";
import { useState } from "react";
import { useRouter } from 'next/router';
import Modal from 'react-modal'
import SpecialOrderModal from "./modals/SpecialOrderModal"


export default function UserHeader() {
    const router = useRouter()
    const [isSortByOpen, setIsSortByOpen] = useState(false);
    const [sortByValue, setSortByValue] = useState('Previously Ordered')
    const [isSpecialOrderModalOpen, setIsSpecialOrderModalOpen] = useState(false);

    const toggleSortBy = () => {
        setIsSortByOpen(!isSortByOpen);
    }

    const changeSortByValue = (e: any) => {
        setSortByValue(e.target.innerText);
    }

    // const addSpecialOrder = () => {
    //     router.push('accountsAndBilling/users/add')
    // }

    // special order modal
    const openSpecialOrderModal = () => {
        setIsSpecialOrderModalOpen(true)
    }

    const closeSpecialOrderModal = () => {
        setIsSpecialOrderModalOpen(false)
    }

    return (
        <>
            <Header>
                <MainHeading>Supplies</MainHeading>
                <div>
                    <SortBy>
                        <img src="/images/supplies/sort.svg" alt="..." />
                        <p>Sort by:</p>
                        <p onClick={toggleSortBy}>{sortByValue}</p>
                        <img src="/images/supplies/chevron-down.svg" alt="..." />
                        <SortByDropdown className={isSortByOpen ? 'is-open' : ''}>
                            <p onClick={changeSortByValue}>Previously Ordered</p>
                            <p onClick={changeSortByValue}>Most Frequently Ordered</p>
                            <p onClick={changeSortByValue}>Sort by Price (High-Low)</p>
                            <p onClick={changeSortByValue}>Sort by Price (Low-High)</p>
                        </SortByDropdown>
                    </SortBy>
                    <AddSpecialOrderButton onClick={openSpecialOrderModal}>Add Special Order Product</AddSpecialOrderButton>
                </div>
            </Header>
            <SpecialOrderModal
                setIsOpen={setIsSpecialOrderModalOpen}
                isOpen={isSpecialOrderModalOpen}
                closeModal={closeSpecialOrderModal}
            />
        </>
    )
}
