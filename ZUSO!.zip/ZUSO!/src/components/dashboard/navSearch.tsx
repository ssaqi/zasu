import React from "react";
import {
  Container,
  Column,
  SearchInput,
  Dropdown,
  Button
} from "@/styledComponents/navSearch"



const navSearch = () => {
  return (
    <Container>
      <Column>
        <SearchInput placeholder="Search for a product by SKU or Name" />
      </Column>
      <Column>
        <Dropdown>
          <option value="">Select a category</option>
          <option value="category1">Category 1</option>
          <option value="category2">Category 2</option>
          <option value="category3">Category 3</option>
        </Dropdown>
      </Column>
      <Column>
        <Dropdown>
          <option value="">Select a manufacturer</option>
          <option value="manufacturer1">Manufacturer 1</option>
          <option value="manufacturer2">Manufacturer 2</option>
          <option value="manufacturer3">Manufacturer 3</option>
        </Dropdown>
      </Column>
      <Column>
        <Button>Search</Button>
      </Column>
    </Container>
  );
};

export default navSearch;