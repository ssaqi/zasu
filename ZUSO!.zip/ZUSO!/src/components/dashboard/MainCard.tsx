import React from 'react'
import { MainCardStyled, ImageSection, CardBody, Title, Description, ButtonContainer } from '@/styledComponents/dashboard/mainCard'


interface MainCardProps {
    icon: string
    title: string,
    description: string,
    buttonText: string,
    largeFont: boolean
    goToLink: () => {}
}

const MainCard: React.FC<MainCardProps> = ({ icon, title, description, buttonText, largeFont, goToLink }) => {
    return (
        <MainCardStyled>
            <ImageSection>
                <img src={icon} alt="..." width="100" height="100" />
                {/* <img src={icon} alt={title} width="50" height="50" /> */}
            </ImageSection>
            <CardBody>
                <Title className={largeFont ? 'large-font' : 'small-font'}>{title}</Title>
                <Description>{description}</Description>
            </CardBody>
            <ButtonContainer>
                <button onClick={goToLink}>{buttonText}</button>
            </ButtonContainer>
        </MainCardStyled>
    )
}

export default MainCard