import Image from 'next/image'

interface IconBoxProps {
    image: string
    title: string;
    description: string;
    className?: string;
}

export default function iconBox({image, title, description, className}: IconBoxProps) {
    return (
     <div>
        <div className="flex flex-wrap text-center">
                <div className='mt-8 ml-8'>
                    <div className={className}>
                        <Image src={image} alt={title} width={50} height={10} />
                    </div>
                    <div >
                        <h2 className='mt-4'>
                            {title}
                        </h2>
                    </div>
                        <div className='mt-2'>
                        <p dangerouslySetInnerHTML={{ __html: description }} />
                        </div>
                </div>
        </div>
     </div>
    )
}
