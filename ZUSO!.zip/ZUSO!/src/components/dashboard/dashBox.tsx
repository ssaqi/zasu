import Image from 'next/image'

interface IconBoxProps {
}

export default function DashBox() {
    return (
        <div>
        </div>
    )
}
