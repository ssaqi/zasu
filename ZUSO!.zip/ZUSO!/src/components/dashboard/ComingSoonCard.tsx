import React from 'react'
import { ComingSoonCardStyled } from '@/styledComponents/dashboard/comingSoonCard'


interface ComingSoonCardProps {
    text: string
}

const ComingSoonCard: React.FC<ComingSoonCardProps> = ({ text }) => {
    return (
        <ComingSoonCardStyled>
            <img src="/images/userDashboard/coming-soon-icon.svg" alt="Coming Soon" width="100" height="100" />
            <p>{text}</p>
        </ComingSoonCardStyled>
    )
}

export default ComingSoonCard