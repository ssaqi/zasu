import React from 'react'
import { OrderCardStyled, OrdersSection, OrderDetail, OrderButtonContainer } from '@/styledComponents/dashboard/orderCard'


const OrderCard = () => {
    return (
        <OrderCardStyled>
            <OrdersSection>
                <h1>Recent Orders</h1>
                <div>
                    <OrderDetail><span><b>Order #ZS010-2005</b></span> - 2 items ordered from <b>Midwest Dental</b> on <b>March 12, 2023</b></OrderDetail>
                    <OrderDetail><span><b>Order #ZS010-0013</b></span> - 5 items ordered from <b>Midwest Dental</b> on <b>Feb 12, 2023</b></OrderDetail>
                    <OrderDetail><span><b>Order #ZS010-0001</b></span> - 4 items ordered from <b>Henry Schein</b> on <b>Jan 6, 2023</b></OrderDetail>
                </div>
            </OrdersSection>
            <OrderButtonContainer>
                <button>See Reports</button>
            </OrderButtonContainer>
        </OrderCardStyled>
    )
}

export default OrderCard