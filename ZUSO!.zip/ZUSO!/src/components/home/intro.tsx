import React, {useEffect, useState} from 'react';
import {FeaturesContainer, IntroContainer , Image} from '@/styledComponents/home';
import {isMobile} from 'react-device-detect';

interface ComponentProps {

}

const Intro: React.FC<ComponentProps> = ({}) => {

    return (
        <IntroContainer>
            <p className='text-white font-bold heading'>Introducing ZuSo Supply</p>
            <p className='text-white px-5 mb-2 description'>ZuSo is a software service that will
                simplify and manage all dental-related procurement. This application will greatly reduce
                the costs and time involved with supply-ordering, equipment research and purchasing, and
                repair and maintenance management. It is the only product that links the dental clinics
                to their chosen local providers and their services. ZuSo is subscription-based and
                focused on lowering costs, reducing mistakes, and elevating productivity for its dental
                clients.</p>
            <div className='flex items-center justify-center'><Image src="/login-right.png" alt=""/>
            </div>
            <FeaturesContainer>
                <div className="basis-2/6">
                    <h1 className='text-white font-bold sub-heading'>Feature 1</h1>
                    <p className='text-white description'>Provides full-service functionality with
                        supplies, equipment, repair and maintenance.</p>
                </div>
                <div className="basis-2/6">
                    <h1 className='text-white font-bold sub-heading'>Feature 2</h1>
                    <p className='text-white description'>Direct connections to all vendor sales and
                        service representatives.</p>
                </div>
                <div className="basis-2/6">
                    <h1 className='text-white font-bold sub-heading'>Feature 3</h1>
                    <p className='text-white description'>Smart Purchasing Technology™ designed to help
                        offices get no more and no less than what they need.</p>
                </div>
            </FeaturesContainer>
        </IntroContainer>
    )
}
export default Intro
