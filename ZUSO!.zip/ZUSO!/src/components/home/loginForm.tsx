import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";

import {
  Container,
  FormWrapper,
  LoginButton,
  LoginHeading,
  LoginSubHeading,
  Logo,
  LogoContainer,
  RememberMeContainer,
} from "@/styledComponents/home";
import CONSTANTS from "@/utils/constants";
import { useDispatch } from "react-redux";
import { getUserAccountDetails } from "@/store/accountSlice";

interface ComponentProps {}

const LoginForm: React.FC<ComponentProps> = ({}) => {
  const [formData, setFormData] = React.useState<any>({
    email: "",
    password: "",
  });

  const router = useRouter();
  const dispatch = useDispatch();

  const handleChange = (e: React.FormEvent<HTMLInputElement>): void => {
    setFormData({
      ...formData,
      [e.currentTarget.id]: e.currentTarget.value,
    });
  };

  const onEnter = (event: any) => {
    if (event.key === "Enter") {
      handleSubmit();
    }
  };

  const handleSubmit = async () => {
    console.log(`FormData: ${formData.email} ${formData.password}`);

    if (!(formData.email && formData.password)) {
      return;
    }
    // console.log(formData)
    await fetch(CONSTANTS.api + "auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: formData.email, // because its username in backend, will be changed later
        password: formData.password,
      }),
      credentials: "include",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((r) => r.json())
      .then((rsp: any) => {
        // console.log(rsp);
        if (rsp.message === "success") {
          localStorage.setItem("token", rsp.token);
          dispatch(
            // @ts-ignore
            getUserAccountDetails()
          );
          router.push("/dashboard");
        } else {
          alert("Invalid login attempt.");
        }
      });
  };

  return (
    <Container>
      <LogoContainer>
        <Logo src="/logo-new.png" alt="" />
      </LogoContainer>
      <FormWrapper>
        <LoginHeading className="text-left font-bold text-zuso-dark-blue">
          Login to your account
        </LoginHeading>
        <LoginSubHeading className="text-left text-zuso-label mb-10">
          Don&#39;t have an account yet?
          <Link href="/register" passHref legacyBehavior>
            <span className="text-zuso-blue hover:cursor-pointer">
              {" "}
              Sign up now!
            </span>
          </Link>
        </LoginSubHeading>
        <div className="text-left text-zuso-input ">Email Address</div>
        <div className="w-64 flex items-center mb-3">
          <input
            type="email"
            id="email"
            onChange={handleChange}
            value={formData.email}
            className="bg-white text-sm flex-1 input-bordered"
          ></input>
        </div>
        <div className="text-left text-zuso-input ">Password</div>
        <div className="w-64 flex items-center mb-3">
          <input
            type="password"
            id="password"
            onChange={handleChange}
            onKeyUp={onEnter}
            value={formData.password}
            className="bg-white text-sm flex-1 input-bordered"
          ></input>
        </div>
        <RememberMeContainer>
          <label className="flex items-center text-xs">
            <input type="checkbox" id="remember" className="mr-1 checkbox" />{" "}
            Remember Me
          </label>
          <a
            href="#"
            className="text-xs font-bold text-zuso-blue float-right align-center"
          >
            Forgot Password?
          </a>
        </RememberMeContainer>
        <div>
          <LoginButton onClick={handleSubmit}>Login to Zuso</LoginButton>
        </div>
      </FormWrapper>
    </Container>
  );
};
export default LoginForm;
