import {
    Container,
    Header,
    Heading,
    Form
} from "@/styledComponents/filter"

export default function Filter() {
    return(
        <>
        <Container>
          <Header>
            <Heading>Filter & Refine</Heading>  
          </Header>
          <Form>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label >On Promotion
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Previously Purchased
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Only Linked Suppliers
            </label><br></br>
          </Form>
          <Header>
           <Heading>Suppliers</Heading> 
          </Header>
          <Form>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Midwest Dental
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Henry Schein
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Burkhart
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Patterson
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Benco
            </label><br></br>
          </Form> 
          <Header>
           <Heading>Manufacturers</Heading> 
          </Header>
          <Form>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >3M Unitek
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Ada Products
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >AMD Lasers
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >American Orthodontics
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Bisco
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Brasseler
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Common Sense Dental
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Cosmodent
            </label><br></br>
          </Form>
          <Header>
           <Heading>Categories</Heading> 
          </Header>
          <Form>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Adhesives
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Anesthetics
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Burs & Diamonds
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >CAD/Cam
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Cros & Bridge
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Dispensing Syringes
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Disposables
            </label><br></br>
            <input 
                type="checkbox" 
                id="promo"></input>
            <label 
                >Endodontic Products
            </label><br></br>
          </Form> 
        </Container>  
        </>
    )
}
