import {
  AccountInfoBody,
  AccountInfoContainer,
  AccountInfoHeading,
  AccountInfoHeadingContainer,
  AccountInfoTopHeading,
  Container,
  FirstRow,
  FirstRowLeft,
  FirstRowRight,
  Header,
  MainHeading,
  ProfileDescriptionInput,
  ProfileInput,
  ProfileInputContainer,
  ProfileInputError,
  ProfileInputLabel,
  ProfileRows,
  UpdateAccountButton,
  AvatarBody,
  AvatarImageIcon,
  AvatarInput,
  AvatarTitle,
  ClickHereSpan,
  AvatarImage,
  AvatarBodyWrapper,
} from "@/styledComponents/accountsAndBilling/editAccount";
import * as React from "react";
import { useSelector } from "react-redux";
import { selectAccountState } from "@/store/accountSlice";
import { useRouter } from "next/router";
import { useState } from "react";
import imageIcon from "../../../public/ImageIcon.svg";
import avatarPlaceHolder from "../../../public/AvatarPlaceholder.png";
import Heading from "./heading";
import { validateEmail } from "@/utils/utils";
import CONSTANTS from "@/utils/constants";
import { post } from "@/utils/fetch";
import { password } from "@hapi/iron";

export default function EditAccount() {
  const router = useRouter();
  const userDetails = useSelector(selectAccountState);
  const [emailError, setEmailError] = useState(false);
  const [emailInvalidError, setEmailInvalidError] = useState(false);
  const [firstNameError, setFirstNameError] = useState(false);
  const [lastNameError, setLastNameError] = useState(false);
  const [phoneNumberError, setPhoneNumberError] = useState(false);
  const [positionError, setPositionError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [infoError, setInfoError] = useState(false);
  const [confirmPasswordError, setConfirmPasswordError] = useState(false);
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const [previousPasswordLengthError, setPreviousPasswordLengthError] =
    useState(false);
  const [passwordLengthError, setPasswordLengthError] = useState(false);

  const [accountForm, setAccountForm] = useState({
    firstName: userDetails.first_name,
    lastName: userDetails.last_name,
    email: userDetails.email,
    position: userDetails.position,
    info: userDetails.info,
    phoneNumber: userDetails.phone_number,
    profileImage: userDetails.profile_image,
  });

  const [passwordForm, setPasswordForm] = useState({
    previousPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleAccountInfoChange = (e: any): void => {
    setAccountForm({
      ...accountForm,
      [e.target.id]: e.target.value,
    });
  };

  const handlePasswordChange = (e: any): void => {
    setPasswordForm({
      ...passwordForm,
      [e.target.id]: e.target.value,
    });
  };

  const submitAccountForm = () => {
    let formValid = true;
    if (accountForm.phoneNumber == "") {
      formValid = false;
      setPhoneNumberError(true);
    } else {
      setPhoneNumberError(false);
    }
    if (accountForm.email == "") {
      formValid = false;
      setEmailError(true);
    } else {
      setEmailError(false);
    }
    if (!validateEmail(accountForm.email)) {
      formValid = false;
      setEmailInvalidError(true);
    } else {
      setEmailInvalidError(false);
    }
    if (accountForm.info == "") {
      formValid = false;
      setInfoError(true);
    } else {
      setInfoError(false);
    }
    if (accountForm.firstName == "") {
      formValid = false;
      setFirstNameError(true);
    } else {
      setFirstNameError(false);
    }
    if (accountForm.lastName == "") {
      formValid = false;
      setLastNameError(true);
    } else {
      setLastNameError(false);
    }
    if (accountForm.position == "") {
      formValid = false;
      setPositionError(true);
    } else {
      setPositionError(false);
    }

    if (formValid) {
      updateUserAccountInfo();
    }
  };

  const submitPasswordForm = () => {
    let formValid = true;
    if (passwordForm.previousPassword == "") {
      formValid = false;
      setPasswordError(true);
    } else {
      setPasswordError(false);
    }
    if (passwordForm.confirmPassword == "") {
      formValid = false;
      setConfirmPasswordError(true);
    } else {
      setConfirmPasswordError(false);
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      formValid = false;
      setPasswordsMatch(false);
    } else {
      setPasswordsMatch(true);
    }
    if (passwordForm.newPassword.length < 8) {
      formValid = false;
      setPasswordLengthError(true);
    } else {
      setPasswordLengthError(false);
    }
    if (passwordForm.previousPassword.length < 8) {
      formValid = false;
      setPreviousPasswordLengthError(true);
    } else {
      setPreviousPasswordLengthError(false);
    }
    if (formValid) {
      updateUserPassword();
    }
  };

  const updateUserPassword = () => {
    post("users/updatePassword", passwordForm)
      .then((res: any) => {
        if (res.success) {
          alert("Account password updated successfully");
          router.push("/accountsAndBilling");
        } else {
          alert(res.message);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const updateUserAccountInfo = () => {
    post("users/edit", accountForm)
      .then((res: any) => {
        console.log(`edit res:> ${res} && editForm ${JSON.stringify(accountForm)}`);

        if (res.success) {
          alert("Account info updated successfully");
          router.push("/accountsAndBilling");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Container>
      <Heading />
      <FirstRow>
        <FirstRowLeft>
          <AccountInfoTopHeading>
            Edit Account Information
          </AccountInfoTopHeading>
          <AccountInfoContainer>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>ACCOUNT INFORMATION</AccountInfoHeading>
              <UpdateAccountButton onClick={submitAccountForm}>
                Update account
              </UpdateAccountButton>
            </AccountInfoHeadingContainer>
            <AccountInfoBody>
              <ProfileRows>
                <ProfileInputLabel>
                  First name:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="firstName"
                    type="text"
                    placeholder="First name"
                    value={accountForm.firstName}
                    onChange={handleAccountInfoChange}
                  />
                  {firstNameError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  Last name:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="lastName"
                    type="text"
                    placeholder="Last name"
                    value={accountForm.lastName}
                    onChange={handleAccountInfoChange}
                  />
                  {lastNameError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Position</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="position"
                    type="text"
                    placeholder="Position"
                    value={accountForm.position}
                    onChange={handleAccountInfoChange}
                  />
                  {positionError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Phone Number</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="phoneNumber"
                    type="number"
                    placeholder="Phone"
                    value={accountForm.phoneNumber}
                    onChange={handleAccountInfoChange}
                  />
                  {phoneNumberError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Profile Description</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileDescriptionInput
                    id="info"
                    placeholder="Please Describe this profile here"
                    value={accountForm.info}
                    onChange={handleAccountInfoChange}
                  />
                  {infoError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
            </AccountInfoBody>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>Avatar</AccountInfoHeading>
            </AccountInfoHeadingContainer>
            <AvatarBody>
              <AvatarImage src={avatarPlaceHolder.src} alt="" />
              <AvatarBodyWrapper>
                <AvatarInput type="file" />
                <AvatarImageIcon src={imageIcon.src} alt="" />
                <AvatarTitle>
                  Drop an image or <ClickHereSpan>click here</ClickHereSpan>
                </AvatarTitle>
              </AvatarBodyWrapper>
            </AvatarBody>
          </AccountInfoContainer>
        </FirstRowLeft>
        <FirstRowRight>
          <AccountInfoContainer>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>CHANGE EMAIL</AccountInfoHeading>
              <UpdateAccountButton onClick={submitAccountForm}>
                Change Email
              </UpdateAccountButton>
            </AccountInfoHeadingContainer>
            <AccountInfoBody>
              <ProfileRows>
                <ProfileInputLabel>
                  Email:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="email"
                    type="text"
                    placeholder="Your email here"
                    value={accountForm.email}
                    onChange={handleAccountInfoChange}
                  />
                  {emailError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                  {emailInvalidError ? (
                    <ProfileInputError>Invalid Email</ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
            </AccountInfoBody>
          </AccountInfoContainer>
          <AccountInfoContainer>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>CHANGE PASSWORD</AccountInfoHeading>
              <UpdateAccountButton onClick={submitPasswordForm}>
                Change Password
              </UpdateAccountButton>
            </AccountInfoHeadingContainer>
            <AccountInfoBody>
              <ProfileRows>
                <ProfileInputLabel>
                  Current Password:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="previousPassword"
                    type="password"
                    placeholder="Type your current password here"
                    value={passwordForm.previousPassword}
                    onChange={handlePasswordChange}
                  />
                  {passwordError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                  {previousPasswordLengthError ? (
                    <ProfileInputError>
                      Previous password could not be less than 8 characters*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  New Password:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="newPassword"
                    type="password"
                    placeholder="Type your new password here"
                    value={passwordForm.newPassword}
                    onChange={handlePasswordChange}
                  />
                  {confirmPasswordError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                  {passwordLengthError ? (
                    <ProfileInputError>
                      Password should be at least 8 characters*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  Confirm Password:<span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="confirmPassword"
                    type="password"
                    placeholder="Retype new password here"
                    value={passwordForm.confirmPassword}
                    onChange={handlePasswordChange}
                  />
                  {confirmPasswordError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                  {!passwordsMatch ? (
                    <ProfileInputError>
                      Passwords do not match.
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
            </AccountInfoBody>
          </AccountInfoContainer>
        </FirstRowRight>
      </FirstRow>
    </Container>
  );
}
