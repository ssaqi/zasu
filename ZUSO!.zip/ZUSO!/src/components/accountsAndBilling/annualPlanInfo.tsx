import {
    AnnualPlanImage, AnnualPlanInfoCheckmark,
    AnnualPlanInfoContainer,
    AnnualPlanInfoDescription,
    AnnualPlanInfoHeading, AnnualPlanInfoPointers,
    AnnualPlanInfoSubHeading, AnnualPlanPointersContainer,
    SwitchNowButton,
} from '@/styledComponents/accountsAndBilling/accountAndBilling';
import * as React from 'react';
import {useRouter} from 'next/router';
import greenTickEmptyIcon from '../../../public/greenTickEmpty.svg';
import cardBackground from '../../../public/AnnualPlan.png';

export default function AnnualPlanInfo() {

    const router = useRouter()

    const gotoChangePlan = () => {
        router.push('accountsAndBilling/choosePlan')
    }

    return (
        <>
            <AnnualPlanInfoContainer>
                <AnnualPlanInfoHeading>Switch to annual payments and save $399 on setup
                    fee!</AnnualPlanInfoHeading>
                <AnnualPlanInfoDescription>We will adjust the amount we charge you according to
                    the remaining days on the current subscription.</AnnualPlanInfoDescription>
                <AnnualPlanInfoSubHeading>More Features. Less hassle</AnnualPlanInfoSubHeading>
                <AnnualPlanPointersContainer>
                    <AnnualPlanInfoCheckmark src={greenTickEmptyIcon.src} alt=""/>
                    <AnnualPlanInfoPointers>Morbi vehicula dolor libero, id aliquet nulla
                        ultrices tempus.</AnnualPlanInfoPointers>
                </AnnualPlanPointersContainer>
                <AnnualPlanPointersContainer>
                    <AnnualPlanInfoCheckmark src={greenTickEmptyIcon.src} alt=""/>
                    <AnnualPlanInfoPointers>Morbi vehicula dolor libero, id aliquet nulla
                        ultrices tempus.</AnnualPlanInfoPointers>
                </AnnualPlanPointersContainer>
                <AnnualPlanPointersContainer>
                    <AnnualPlanInfoCheckmark src={greenTickEmptyIcon.src} alt=""/>
                    <AnnualPlanInfoPointers>Morbi vehicula dolor libero, id aliquet nulla
                        ultrices tempus.</AnnualPlanInfoPointers>
                </AnnualPlanPointersContainer>
                <AnnualPlanPointersContainer>
                    <AnnualPlanInfoCheckmark src={greenTickEmptyIcon.src} alt=""/>
                    <AnnualPlanInfoPointers>Morbi vehicula dolor libero, id aliquet nulla
                        ultrices tempus.</AnnualPlanInfoPointers>
                </AnnualPlanPointersContainer>
                <SwitchNowButton onClick={gotoChangePlan}>Switch Now</SwitchNowButton>
            </AnnualPlanInfoContainer>
            <AnnualPlanImage src={cardBackground.src} alt=""/>
        </>
    )
}
