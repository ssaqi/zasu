import React from "react";
import {
  Container,
  Headings,
} from "@/styledComponents/accountsAndBilling/secondaryNavBar";
import { useDispatch, useSelector } from "react-redux";
import {
  selectedTab,
  setSelectedTab,
} from "@/store/accountsAndBillingSecondaryNavbarSlice";
import { useRouter } from "next/router";
import { router } from "next/client";
import { getSuppliers } from "@/store/supplierPreferenceSlice";

export default function SecondaryNavBar() {
  const _selectedTab = useSelector(selectedTab);
  const dispatch = useDispatch();
  const router = useRouter();
  const selectAccountsAndBilling = () => {
    // @ts-ignore
    dispatch(setSelectedTab(1));
    router.push("/accountsAndBilling");
  };

  const selectPracticePrefs = () => {
    // @ts-ignore
    dispatch(setSelectedTab(2));
    router.push("/accountsAndBilling/practicePreferences");
  };

  const selectPracticeUsers = () => {
    // @ts-ignore
    dispatch(setSelectedTab(3));
    router.push("/accountsAndBilling/users");
  };

  return (
    <Container>
      <Headings
        selectedColor={_selectedTab === 1 ? "#1E9ED4" : "#64748B"}
        onClick={selectAccountsAndBilling}
      >
        Account & Billing
      </Headings>
      <Headings
        selectedColor={_selectedTab === 2 ? "#1E9ED4" : "#64748B"}
        onClick={selectPracticePrefs}
      >
        Practice Preferences
      </Headings>
      <Headings
        selectedColor={_selectedTab === 3 ? "#1E9ED4" : "#64748B"}
        onClick={selectPracticeUsers}
      >
        Practice Users
      </Headings>
    </Container>
  );
}
