import {
    Hourglass,
    HourglassContainer,
    SearchBarContainer,
    SearchInput,
} from "@/styledComponents/users";
import hourglassIcon from '../../../../public/Search.svg'

export default function UserSearchBar() {

    const searchUsers = (event: any) => {
        if (event.key === "Enter") {
            console.log('search users')
        }
    }

    return (
        <SearchBarContainer>
            <HourglassContainer>
                <Hourglass src={hourglassIcon.src} alt=""/>
            </HourglassContainer>
            <SearchInput type="text" placeholder="Search users and press Enter" onKeyPress={searchUsers}/>
        </SearchBarContainer>
    )
}
