import {
    AddUserButton,
    Header,
    MainHeading,
} from "@/styledComponents/users";
import {useRouter} from 'next/router';

export default function UserHeader() {

    const router = useRouter()

    const addUser = () => {
        router.push('/accountsAndBilling/users/add')
    }

    return (
        <Header>
            <MainHeading>Practice Users</MainHeading>
            <AddUserButton onClick={addUser}>Add a User</AddUserButton>
        </Header>
    )
}
