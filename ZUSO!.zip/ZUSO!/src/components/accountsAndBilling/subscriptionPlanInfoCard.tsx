import {
  AccountInfoButtons,
  BottomRow,
  CancelPlanButton,
  Icon,
  PlanInfoBody,
  PlanInfoContainer,
  PlanInfoHeading,
  PlanInfoHeadingContainer,
  PlanInfoHeadings,
  PlanInfoStatus,
  PlanInfoTopRightHeading,
  PlanInfoValueMuted,
  PlanInfoValues,
} from "@/styledComponents/accountsAndBilling/accountAndBilling";
import * as React from "react";
import changePlanIcon from "../../../public/changePlan.svg";
import crossIcon from "../../../public/cross.svg";
import { useRouter } from "next/router";

export default function SubscriptionPlanInfoCard() {
  const router = useRouter();

  const gotoChangePlan = () => {
    if (!router.pathname.includes(`accountsAndBilling/choosePlan`)) {
      router.push("accountsAndBilling/choosePlan");
    }
  };

  return (
    <PlanInfoContainer>
      <PlanInfoHeadingContainer>
        <PlanInfoHeading>Current plan</PlanInfoHeading>
        <PlanInfoTopRightHeading>Monthly</PlanInfoTopRightHeading>
      </PlanInfoHeadingContainer>
      <PlanInfoBody>
        <PlanInfoHeadings>Subscription plan</PlanInfoHeadings>
        <PlanInfoValues>ZuSo Membership = $99 / month</PlanInfoValues>
        <PlanInfoHeadings>Subscription renewal date</PlanInfoHeadings>
        <PlanInfoValues>29 June 2021 (30 days)</PlanInfoValues>
        <PlanInfoHeadings>Additional Charges</PlanInfoHeadings>
        <span>
          <PlanInfoValues>Usd$ 0.00</PlanInfoValues>
          <PlanInfoValueMuted> (including tax)</PlanInfoValueMuted>
        </span>
        <PlanInfoHeadings>Status</PlanInfoHeadings>
        <PlanInfoStatus>Active</PlanInfoStatus>
        <BottomRow>
          <Icon src={changePlanIcon.src} alt="" />
          {!router.pathname.includes(`accountsAndBilling/choosePlan`) && (
            <div>
              <AccountInfoButtons onClick={gotoChangePlan}>
                Change Plan
              </AccountInfoButtons>
              <Icon src={crossIcon.src} alt="" />
            </div>
          )}
          <CancelPlanButton>Cancel</CancelPlanButton>
        </BottomRow>
      </PlanInfoBody>
    </PlanInfoContainer>
  );
}
