import * as React from 'react';
import Heading from './heading';
import styled from 'styled-components';
import darkBackground from '../../../public/paymentBackgroundPolygonDark.svg';
import lightBackground from '../../../public/paymentBackgroundPolygonWhite.svg';
import {useEffect, useState} from 'react';
import {isMobile} from 'react-device-detect';
import {useDispatch, useSelector} from 'react-redux';
import {selectPlanStage, setPlanStage} from '@/store/registerSlice';
import {useRouter} from 'next/router';
import {IPlan} from '@/types/registerTypes';
import SubscriptionPlanInfoCard from './subscriptionPlanInfoCard';
import CONSTANTS from '@/utils/constants';
import Modal from 'react-modal';
import {Column, Form, FormContainer, FormHeading, SubmitButton, Title} from '@/styledComponents/Forms';
import {CardElement, useElements, useStripe} from '@stripe/react-stripe-js';
import {createPaymentIntent} from '@/services/PaymentIntentService';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding: 0rem 5rem 2rem 5rem;
  background: #F1F5F9;

  @media only screen and (max-width: 1025px) {
    // for mobile 
    padding: 0rem 1rem 2rem 1rem;
  }
`

export const SubHeading = styled.p`
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 18px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #334155;
  align-self: flex-start;
`

export const Description = styled.p`
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #64748B;
  padding-top: 0.5rem;
  align-self: flex-start;
`


export const Row = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  width: 100%;
  margin-top: 2rem;
  
  @media (max-width: 1024px) {
    justify-content: space-evenly;
    flex-wrap: wrap;
  }
`

const PlansContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 6rem;
  padding: 1rem 0.5rem;

  @media only screen and (max-width: 1025px) {
    gap: 2rem;
  }

  @media only screen and (max-width: 500px) {
    flex-direction: column;
  }
`
const Plan = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  //gap: 6rem;
  padding: 1.5rem 1.5rem;
  border-radius: 5px;

  @media only screen and (max-width: 500px) {
    //flex-direction: column;
  }
`

const ImageWrapper = styled.div`
  padding: 3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  background-position: center;
  background-repeat: no-repeat;
`

const Image = styled.img`
  width: 120px;
`

export const ContinueButton = styled.button`
  color: white;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  padding: 10px 0px;
  background: #1E9ED4;
  border-radius: 4px;
  width: 300px;
  transition-duration: 1s;
  margin-top: 20px;

  @media only screen and (max-width: 1024px) {
    //width: 100%;
  }

  :hover {
    background: #17325E;
  }
`

export const ModalContainer = styled.div`
  background: #F1F5F9;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
  border-radius: 8px 8px 0px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`

export default function ChoosePlan() {

    const dispatch = useDispatch();
    const [_isMobile, setIsMobile] = useState(false)
    const [modalOpen, setModalOpen] = useState(false)
    const planStage = useSelector(selectPlanStage);
    const stripe = useStripe()
    const elements = useElements()
    const router = useRouter()
    const {id} = router.query;
    const [formData, setFormData] = React.useState<IPlan>({
        planId: planStage.planId
    });

    const openModal = () => {
        setModalOpen(true)
    }

    const closeModal = () => {
        setModalOpen(false)
    }

    useEffect(() => {
        if (isMobile) {
            setIsMobile(true)
        }
    }, [])

    const handleChange = (e: React.FormEvent<HTMLButtonElement>): void => {
        // console.log(formData)
        if (formData.planId == Number(e.currentTarget.value)) {
            // dispatch(setPlanStage(formData))
            // router.push('/registerPayment?id=' + id)
            openModal()
        } else {
            setFormData({
                ...formData,
                [e.currentTarget.id]: e.currentTarget.value,
            })
        }
    }

    const handleContinue = (event: any) => {
        // console.log('handleContinue');
        event.preventDefault()
        if (elements !== null) {
            const cardElement = elements.getElement(CardElement)
            // dispatch(setPaymentStage(formData))

            createPaymentIntent(Number(id), planStage.planId, 'usd')
                .then((paymentIntent: any) => {
                    // console.log(paymentIntent, ' <<< response from backend')
                    // @ts-ignore
                    stripe.createPaymentMethod({
                        type: 'card',
                        // @ts-ignore
                        card: cardElement
                    }).then((paymentMethod: any) => {
                        // console.log(paymentIntent.client_secret, ' <<<< response from stripe')
                        stripe?.confirmCardPayment(paymentIntent.client_secret, {payment_method: paymentMethod.paymentMethod.id})
                            .then((paymentConfirm: any) => {
                                // console.log(paymentConfirm.paymentIntent, ' <<<< payment confirm')
                                if (paymentConfirm.paymentIntent.status === "succeeded") {
                                    paymentSucceeded(paymentConfirm.paymentIntent.id)
                                } else {
                                    alert('Something Went Wrong!, Please try again later')
                                }
                            })
                    })
                })
        }
    }

    const paymentSucceeded = (paymentId: string) => {
        fetch(CONSTANTS.api + 'registration/registerPayment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(
                {
                    paymentId: paymentId,
                    userId: id,
                }
            ),
        }).then(response => response.json())
            .then((rsp) => {
                // console.log(rsp, ' <<<< final response from backend')
                if (rsp.message == "success") {
                    router.push('/accountsAndBilling/paymentConfirmed');
                } else {
                    throw Error(rsp.statusText);
                }
            }).catch((error) => {
            console.log(error)
            alert('Request not completed!');
        });
    }

    return (
        <Container>
            <Modal
                isOpen={modalOpen}
                // onAfterOpen={afterOpenModal}
                onRequestClose={closeModal}
                style={CONSTANTS.modalStyles}
                contentLabel="Delete User"
                ariaHideApp={false}
            >
                <ModalContainer>
                    <FormContainer>
                        <Column>
                            <FormHeading>Enter your payment details</FormHeading>
                        </Column>
                        <Column>
                            <Title>You have selected</Title>
                            <div className='col-span-2'>
                                <input type="button"
                                       className="rounded-sm mb-3 w-full text-zuso-dark-blue text-sm font-bold bg-zuso-yellow p-2"
                                       value={planStage.planId == 1 ? "ZuSo Membership - $199 / month" : "ZuSo Membership - $1,999 / year"}/>
                            </div>
                        </Column>
                        <Form onSubmit={handleContinue}>
                            {/*<Column>*/}
                            <CardElement className="card-container" options={{
                                hidePostalCode: true,
                                style: {
                                    base: {
                                        color: "black",
                                        fontSize: '14px',
                                        lineHeight: "14px",
                                        backgroundColor: "white",
                                        padding: "10px",
                                        "::placeholder": {
                                            color: 'black'
                                        }
                                    }
                                }
                            }}/>
                            {/*</Column>*/}
                            <Column>
                                <SubmitButton type="submit">Complete Registration</SubmitButton>
                            </Column>
                        </Form>
                        <Column>
                            <p className="text-right text-xs text-white">*All fields required</p>
                        </Column>
                    </FormContainer>
                </ModalContainer>
            </Modal>
            <Heading/>
            <SubHeading>Change Your Current Plan</SubHeading>
            <Description>We will adjust the amount we charge you according to the remaining days on the current
                subscription.</Description>
            <Row>
                <PlansContainer>
                    <Plan className={formData.planId == 1 ? " bg-zuso-btn-pressed" : "bg-white"}>
                        <button style={{background: '#47BAEB'}}
                                className="hover:bg-blue-700 text-white font-bold py-2 px-4 w-32 rounded-full mb-2.5">MONTHLY
                        </button>
                        <ImageWrapper
                            style={{backgroundImage: formData.planId == 1 ? `url(${darkBackground.src})` : `url(${lightBackground.src})`}}>
                            <Image src='/plan-monthly.png' alt=""></Image>
                        </ImageWrapper>
                        <div>
                            <span className='text-zuso-blue font-extrabold'>$199.00<span
                                className='text-zuso-label font-thin'>/mo</span> </span>
                        </div>
                        <span className='text-zuso-label font-thin mb-2'>+ $399 setup fee</span>
                        <ContinueButton id='planId' value="1"
                                        onClick={handleChange}>{formData.planId == 1 ? "Continue" : "Choose Plan"}</ContinueButton>
                    </Plan>
                    <Plan className={formData.planId == 2 ? " bg-zuso-btn-pressed" : "bg-white"}>
                        <button style={{background: '#47BAEB'}}
                                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 w-32 rounded-full mb-2.5">ANNUAL
                        </button>
                        <ImageWrapper
                            style={{backgroundImage: formData.planId == 2 ? `url(${darkBackground.src})` : `url(${lightBackground.src})`}}>
                            <Image src='/planYearly.svg' alt=""></Image>
                        </ImageWrapper>
                        <div>
                            <span className='text-zuso-blue font-extrabold'>$1,999.00<span
                                className='text-zuso-label font-thin'>/year</span> </span>
                        </div>
                        <span className='text-yellow-300 font-bold mb-2'>$399 setup fee is waived!</span>
                        <ContinueButton id='planId' value="2"
                                        onClick={handleChange}>{formData.planId == 2 ? "Continue" : "Choose Plan"}</ContinueButton>
                    </Plan>
                </PlansContainer>
                <SubscriptionPlanInfoCard/>
            </Row>
        </Container>
    )
}
