import {
  AccountInfoBody,
  AccountInfoButtons,
  AccountInfoContainer,
  AccountInfoEmail,
  AccountInfoHeading,
  AccountInfoHeadingContainer,
  AccountInfoName,
  AccountInfoPhoneNumber,
  AccountInfoTopHeading,
  AnnualPlanImage,
  AnnualPlanInfoCheckmark,
  AnnualPlanInfoContainer,
  AnnualPlanInfoDescription,
  AnnualPlanInfoHeading,
  AnnualPlanInfoPointers,
  AnnualPlanInfoSubHeading,
  AnnualPlanPointersContainer,
  BottomRow,
  CancelPlanButton,
  ChooseLandingPageContainer,
  ChoosePageSelect,
  ChoosePageSelectOptions,
  Container,
  FirstRow,
  FirstRowLeft,
  FirstRowRight,
  Header,
  Icon,
  MainHeading,
  PlanInfoBody,
  PlanInfoContainer,
  PlanInfoHeading,
  PlanInfoHeadingContainer,
  PlanInfoHeadings,
  PlanInfoStatus,
  PlanInfoTopHeading,
  PlanInfoTopRightHeading,
  PlanInfoValueMuted,
  PlanInfoValues,
  SaveLandingPageButton,
  SecondRow,
  SecondRowLeft,
  SecondRowRight,
  SwitchNowButton,
} from "@/styledComponents/accountsAndBilling/accountAndBilling";
import * as React from "react";
import editIcon from "../../../public/editBlue.svg";
import lockIcon from "../../../public/lockBlue.svg";
import { useSelector } from "react-redux";
import { selectAccountState } from "@/store/accountSlice";
import { useRouter } from "next/router";
import { useState } from "react";
import { post } from "@/utils/fetch";
import { ILandingPage } from "@/types/registerTypes";
import Heading from "./heading";
import SubscriptionPlanInfoCard from "./subscriptionPlanInfoCard";
import AnnualPlanInfo from "@/components/accountsAndBilling/annualPlanInfo";

export default function AccountAndBilling() {
  const userDetails = useSelector(selectAccountState);
  const router = useRouter();
  const [isAnnualPlan, setIsAnnualPlan] = useState(false);
  const [formData, setFormData] = useState<ILandingPage>({
    landingPage: "",
  });

  const gotoUserEditPage = () => {
    router.push("accountsAndBilling/editAccount");
  };

  const gotoChangePasswordPage = () => {
    router.push("accountsAndBilling/editAccount");
  };

  const gotoChangePlan = () => {
    router.push("accountsAndBilling/choosePlan");
  };

  const selectLandingPage = (event: any) => {
    setFormData({
      ...formData,
      ["landingPage"]: event.currentTarget.value,
    });
  };

  const saveLandingPage = () => {
    post("users/landing", formData).then((res: any) => {
      alert("Landing Page Set.");
    });
  };

  return (
    <Container>
      <Heading />
      <FirstRow>
        <FirstRowLeft>
          <AccountInfoTopHeading>Account Information</AccountInfoTopHeading>
          <AccountInfoContainer>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>CONTACT INFORMATION</AccountInfoHeading>
            </AccountInfoHeadingContainer>
            <AccountInfoBody>
              <AccountInfoName>
                {userDetails.first_name} {userDetails.last_name}
              </AccountInfoName>
              <AccountInfoEmail>{userDetails.email}</AccountInfoEmail>
              <AccountInfoPhoneNumber>
                {userDetails.phone_number}
              </AccountInfoPhoneNumber>
              <BottomRow>
                <Icon src={editIcon.src} alt="" />
                <AccountInfoButtons onClick={gotoUserEditPage}>
                  Edit
                </AccountInfoButtons>
                <Icon src={lockIcon.src} alt="" />
                <AccountInfoButtons onClick={gotoChangePasswordPage}>
                  Change Password
                </AccountInfoButtons>
              </BottomRow>
            </AccountInfoBody>
          </AccountInfoContainer>
        </FirstRowLeft>
        <FirstRowRight>
          <AccountInfoTopHeading>My Default Landing Page</AccountInfoTopHeading>
          <AccountInfoContainer>
            <AccountInfoHeadingContainer>
              <AccountInfoHeading>
                CHOOSE THE PAGE YOU SEE AFTER LOGGING IN
              </AccountInfoHeading>
            </AccountInfoHeadingContainer>
            <AccountInfoBody>
              <ChooseLandingPageContainer>
                {userDetails.landing_page !== "" ? (
                  <ChoosePageSelect
                    onChange={selectLandingPage}
                    defaultValue={userDetails.landing_page}
                  >
                    <ChoosePageSelectOptions value={"supplies"}>
                      Supplies Page
                    </ChoosePageSelectOptions>
                    <ChoosePageSelectOptions value={"dashboard"}>
                      Dashboard Page
                    </ChoosePageSelectOptions>
                    <ChoosePageSelectOptions value={"orders"}>
                      Orders Page
                    </ChoosePageSelectOptions>
                    <ChoosePageSelectOptions value={"reports"}>
                      Reports Page
                    </ChoosePageSelectOptions>
                  </ChoosePageSelect>
                ) : null}
                <SaveLandingPageButton onClick={saveLandingPage}>
                  Save
                </SaveLandingPageButton>
              </ChooseLandingPageContainer>
            </AccountInfoBody>
          </AccountInfoContainer>
        </FirstRowRight>
      </FirstRow>
      {userDetails.is_owner ? (
        <SecondRow>
          <SecondRowLeft>
            <PlanInfoTopHeading>My Office Subscription</PlanInfoTopHeading>
            <SubscriptionPlanInfoCard />
          </SecondRowLeft>
          {!isAnnualPlan ? (
            <SecondRowRight>
              <AnnualPlanInfo />
            </SecondRowRight>
          ) : null}
        </SecondRow>
      ) : null}
    </Container>
  );
}
