import {
    MegaMenuStyled, MenuLeftSection, SuppliesColumn, ResearchColumn, EquipmentSupportColumn, EquipmentColumn, SupportColumn, OfficeColumn, MenuBanner
} from "@/styledComponents/megaMenu"
import Link from 'next/link'


const Menu = () => {
    return (
        <MegaMenuStyled>
            <MenuLeftSection>
                <SuppliesColumn>
                    <h1>Supplies</h1>
                    <div>
                        <Link href="/supplies">Supplies</Link>
                        <Link href="/lists">Lists</Link>
                        <Link href="/orders">Orders</Link>
                        <Link href="#">Cart</Link>
                        <Link href="/dashboard">Dashboard</Link>
                    </div>
                </SuppliesColumn>
                <ResearchColumn>
                    <h1>Research</h1>
                    <div>
                        <Link href="/supplies">Request Product Info</Link>
                        <Link href="/digitalCatalog">Digital Catalogs</Link>
                    </div>
                </ResearchColumn>
                <EquipmentSupportColumn>
                    <EquipmentColumn>
                        <h1>Equipment</h1>
                        <div>
                            <Link href="/equipmentProposals">Equipment Inquiry</Link>
                        </div>
                    </EquipmentColumn>
                    <SupportColumn>
                        <h1>Technical Support</h1>
                        <div>
                            <Link href="/techServiceAndParts">Technical Services & Parts Inquiry</Link>
                        </div>
                    </SupportColumn>
                </EquipmentSupportColumn>
                <OfficeColumn>
                    <h1>Office Management</h1>
                    <div>
                        <Link href="/accountAndBilling">Account & Billing</Link>
                        <Link href="#">Notifications</Link>
                        <Link href="#">Contact Support</Link>
                        <Link href="#">Practice Preferences</Link>
                        <Link href="#">Practice Users</Link>
                    </div>
                </OfficeColumn>
            </MenuLeftSection>
            <MenuBanner>
                <img src='/Banner.jpg' alt='banner' />
            </MenuBanner>
        </MegaMenuStyled>
    );
};

export default Menu;
