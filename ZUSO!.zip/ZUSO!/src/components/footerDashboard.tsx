import styled from "styled-components"

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  position: relative;
  width: 100%;
  height: 200px;

  @media only screen and (max-width: 500px) {
    height: 300px;
  }
`

const ImageContainer = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 15px;

  > img {
    width: 120px;
  }

  @media only screen and (max-width: 500px) {
    > img {
      width: 70px;
    }
  }
`

export const LinksContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 15px;
`

const Links = styled.a`
  font-family: 'Roboto', sans-serif;
  font-style: normal;
  font-weight: 500;
  font-size: 12px;
  line-height: 14px;
  color: #94A3B8;

  @media only screen and (max-width: 1025px) {
    font-size: 10px;
    color: white;
    padding-left: 7rem;
  }

  @media only screen and (max-width: 500px) {
    font-size: 12px;
    margin-bottom: 20px;
    padding: 0.75rem;
    color: #8390A5;
  }
`

export default function FooterDashboard() {
  return (
    <Container>
      <ImageContainer>
        <img src="/logoBottom.svg" alt="Logo" />
      </ImageContainer>
      <LinksContainer>
        <Links href="/">© 2023 ZuSo Technologies, Inc.</Links>
        <Links href="/">Terms of Service</Links>
        <Links href="/">Privacy Policy</Links>
        {/* <Links href="/">Send Feedback</Links> */}
        <Links href="/">Contact Us</Links>
      </LinksContainer>
    </Container>
  )
}
