import React from 'react'
import './style.css'
function Card() {
    return (
        <div className='card'>
            <h4 className='Heading'>Total</h4>
            <hr className='line' />
            <div className='parent'>
                <p className='item'>Heny Schen items
                    &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp; &emsp;
                    <span className='span'>$1239.95</span></p>
                <hr />
                <p className='item'>Midwest Dental items
                    &emsp;&emsp;&emsp;&emsp;&emsp; &emsp; &ensp;
                    <span className='span'>$1412.95</span></p>
                <hr />
                <p className='item'>Special Order items
                    &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp; &emsp; &ensp;
                    <span className='span'>$0.00</span></p>
                <hr />
                <div className='subtotal'>
                    <br />
                    <p className='item, color '>Savings
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;
                        &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;
                        &ensp;
                        <span className='span1'>-$TBD</span></p>
                    <p className='item , fcolor'>Subtotal
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp; &emsp;
                        &emsp;&emsp; &emsp; &emsp;
                        <span className='span'>$1652.90</span></p>
                    <p className='item , fcolor'>Shipping & Handling
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp; &emsp; &emsp;
                        <span className='span'>$TBD</span></p>
                    <p className='item , fcolor'>Tax
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;
                        &emsp; &emsp;&emsp; &emsp;&emsp; &emsp;&emsp; &emsp;
                        &ensp;
                        <span className='span'>$TBD</span></p>
                    <hr />
                </div>
            </div>
            <h4 className='Heading'>Grand Total
                &emsp; &emsp;&emsp; &emsp;&emsp;&emsp;
                <span className='span1'>$1652.90</span> </h4>

            <div className='userinput'>
                <input type='text' placeholder='Enter Coupon Here' className='inp' />
                <button className='btn'>Remove</button>
            </div>
            <div className='userinput'>
                <button className='btnn'>Checkout with Selected Products</button>
            </div>

            <div className='userinput'>
                <button className='btnnn'> Add Selected Products to List</button>
            </div>


            <div className='userTax'>
                <p className='tax'>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                    Lorem Ipsum has been the industry's standard dummy text
                    Lorem Ipsum has been the industry's standard dummy text
                </p>
            </div>

        </div>
    )
}

export default Card