// @ts-nocheck
import React from 'react'
import { ReactPaginateStyled, LeftColumn, MiddleColumn, RightColumn } from '@/styledComponents/equipmentProposals/reactPaginateComponent'
import ReactPaginate from 'react-paginate'
import { useState, useEffect } from 'react'


interface ReactPaginateComponentProps {
    itemsPerPage: number,
    items: Array,
    setCurrentItems: Function
}

const ReactPaginateComponent: React.FC<ReactPaginateComponentProps> = ({ itemsPerPage, items, setCurrentItems }) => {
    const [itemOffset, setItemOffset] = useState(0);
    const endOffset = itemOffset + itemsPerPage;
    const currentItems = items?.slice(itemOffset, endOffset);
    const pageCount = Math.ceil(items?.length / itemsPerPage);
    const handlePageClick = (event: any) => {
        const newOffset = (event.selected * itemsPerPage) % items?.length;
        setItemOffset(newOffset);
    }

    useEffect(() => {
        setCurrentItems(currentItems);
    }, [])
    // console.log(currentItems);

    return (
        <ReactPaginateStyled>
            {/* <LeftColumn>
                <span>Show</span>
                <select
                    value={5}
                    onChange={e => {

                    }}
                >
                    {[2, 4, 6, 8, 10].map(pageSize => (
                        <option key={pageSize} value={pageSize}>
                            {pageSize}
                        </option>
                    ))}
                </select>
                <span>rows per page</span>
            </LeftColumn>
            <MiddleColumn>
                <span>Displaying </span>
                <span>{1} - {10} </span>
                <span>of {50} requests</span>
            </MiddleColumn>
            <RightColumn>
                <button onClick={() => { }} disabled={false}>
                    {'<'}
                </button>
                <button onClick={() => { }} disabled={false}>
                    {'Previous'}
                </button>
                <span>{5}</span>
                <button onClick={() => { }} disabled={false}>
                    {'Next'}
                </button>
                <button onClick={() => { }} disabled={false}>
                    {'>'}
                </button>
            </RightColumn> */}
            <ReactPaginate
                pageCount={10}
                breakLabel="..."
                nextLabel="Next"
                previousLabel="Previous"
                onPageChange={handlePageClick}
                pageRangeDisplayed={3}
            />
        </ReactPaginateStyled>
    )
}

export default ReactPaginateComponent