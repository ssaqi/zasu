import React from "react";
import Modal from "react-modal";
import {
  EquipmentProposalsModalStyled,
  ModalHeader,
  ModalBody,
  ManufacturerSection,
  Detail,
  ProductName,
  ProductDescription,
  DropdownContainer,
  DropdownMenu,
  MenuOptions,
  ButtonsContainer,
  PersonalInfoSection,
  PersonalInfoDetail,
  AddButton,
  ClearButton,
} from "@/styledComponents/equipmentProposals/equipmentProposalsModal";
import closeIcon from "public/images/supplies/productModal/close-icon.svg";
import chevronDown from "public/images/supplies/removeItemModal/chevron-down.svg";
import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { addItem } from "@/store/equipmentproposalsSlice";
import ThanksModal from "@/components/ThanksModal";
import { IUserState } from "@/store/accountSlice";

interface EquipmentProposalsModalProps {
  setIsOpen: Function;
  isOpen: boolean;
  closeModal: Function;
  user: IUserState;
}

const EquipmentProposalsModal: React.FC<EquipmentProposalsModalProps> = ({
  setIsOpen,
  isOpen,
  closeModal,
  user,
}) => {
  const dispatch = useDispatch();

  const [optionsShown, setOptionsShown] = useState(false);

  const [manufacturerName, setManufacturerName] = useState("");
  const [mfrPartNumber, setMfrPartNumber] = useState("");
  const [productName, setProductName] = useState("");
  const [notes, setNotes] = useState("");
  const [suppliers, setSuppliers] = useState(["Midwest Dental,"]);
  const [firstName, setFirstName] = useState(user.first_name);
  const [lastName, setLastName] = useState(user.last_name);
  const [email, setEmail] = useState(user.email);
  const [officeName, setOfficeName] = useState(user.company_name);

  const [isThanksModalOpen, setIsThanksModalOpen] = useState(false);

  useEffect(() => {
    setFirstName(user.first_name);
    setLastName(user.last_name);
    setEmail(user.email);
    setOfficeName(user.company_name);
  }, [user])
  

  const closeThanksModal = () => {
    setIsThanksModalOpen(false);
  };

  const changeTitle = (e: any) => {
    const isPresent = suppliers.some((item) => item === e.target.innerText);
    if (!isPresent) {
      setSuppliers([...suppliers, " ", e.target.innerText]);
    }
  };

  const clear = () => {
    setManufacturerName("");
    setMfrPartNumber("");
    setProductName("");
    setNotes("");
    setSuppliers(["Midwest Dental,"]);
    setFirstName(user.first_name);
    setLastName(user.last_name);
    setEmail(user.email);
    setOfficeName(user.company_name);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    dispatch(
      // @ts-ignore
      addItem({
        manufacturerName,
        mfrPartNumber,
        productName,
        notes,
        firstName,
        lastName,
        email,
        officeName,
        suppliers: suppliers.join(" "),
        userId: user.id,
      })
    );
    clear();
    closeModal();
    setIsThanksModalOpen(true);
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onRequestClose={() => closeModal()}
        style={{
          content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            padding: "0",
            maxHeight: "98vh",
            overflow: "auto",
          },
        }}
      >
        <EquipmentProposalsModalStyled onSubmit={handleSubmit}>
          <ModalHeader>
            <p>Request Equipment Proposal</p>
            <img
              src={closeIcon.src}
              alt="..."
              onClick={() => setIsOpen(false)}
            />
          </ModalHeader>
          <ModalBody>
            <div>
              <ManufacturerSection>
                <Detail>
                  <label htmlFor="manufacturerName">Manufacturer Name</label>
                  <input
                    id="manufacturerName"
                    type="text"
                    placeholder="Enter name"
                    value={manufacturerName}
                    onChange={(e) => setManufacturerName(e.target.value)}
                    required={true}
                  />
                </Detail>
                <Detail>
                  <label htmlFor="mfrPartNumber">
                    Manufacturer Part Number
                  </label>
                  <input
                    id="mfrPartNumber"
                    type="text"
                    placeholder="Enter number"
                    value={mfrPartNumber}
                    onChange={(e) => setMfrPartNumber(e.target.value)}
                    required={true}
                  />
                </Detail>
              </ManufacturerSection>
              <ProductName>
                <label htmlFor="productName">Product Name</label>
                <input
                  id="productName"
                  type="text"
                  placeholder="Enter product name"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  required={true}
                />
              </ProductName>
              <ProductDescription>
                <label htmlFor="notes">
                  Product Description / Additional Notes
                </label>
                <textarea
                  id="notes"
                  placeholder="Enter text here"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  required={true}
                ></textarea>
              </ProductDescription>
              <DropdownContainer>
                <p>
                  Distributors to Include for Quote (Primary supplier default;
                  add others, if interested)
                </p>
                <DropdownMenu onClick={() => setOptionsShown(!optionsShown)}>
                  <p>{suppliers}</p>
                  <img src={chevronDown.src} alt="..." />
                  <MenuOptions className={optionsShown ? "shown" : ""}>
                    <p onClick={changeTitle}>Midwest Dental,</p>
                    <p onClick={changeTitle}>Henry Schein,</p>
                    <p onClick={changeTitle}>Patterson,</p>
                  </MenuOptions>
                </DropdownMenu>
              </DropdownContainer>
            </div>
            <PersonalInfoSection>
              <PersonalInfoDetail>
                <label htmlFor="firstName">Your First Name</label>
                <input
                  id="firstName"
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="lastName">Your Last Name</label>
                <input
                  id="lastName"
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="email">Your Email</label>
                <input
                  id="email"
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </PersonalInfoDetail>
              <PersonalInfoDetail>
                <label htmlFor="officeName">Your Office Name</label>
                <input
                  id="officeName"
                  type="text"
                  value={officeName}
                  onChange={(e) => setOfficeName(e.target.value)}
                />
              </PersonalInfoDetail>
            </PersonalInfoSection>
          </ModalBody>
          <ButtonsContainer>
            <AddButton type="submit">Submit Request</AddButton>
            <ClearButton type="button" onClick={clear}>
              Clear
            </ClearButton>
          </ButtonsContainer>
        </EquipmentProposalsModalStyled>
      </Modal>
      <ThanksModal
        setIsOpen={setIsThanksModalOpen}
        isOpen={isThanksModalOpen}
        closeModal={closeThanksModal}
      />
    </>
  );
};

export default EquipmentProposalsModal;
