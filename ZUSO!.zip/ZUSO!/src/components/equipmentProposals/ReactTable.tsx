// @ts-nocheck
import {
  TableContainer,
  Table,
  THead,
  TBody,
  DetailsButton,
  TrAccordion,
  AccordionCard,
  AccordionBody,
  Detail,
} from "@/styledComponents/equipmentProposals/reactTable";
import { useTable, usePagination, useSortBy } from "react-table";
import { useDispatch, useSelector } from "react-redux";

import Link from "next/link";
import React, { useMemo, useState, useEffect } from "react";
import ReactTablePagination from "../ReactTablePagination";
import {
  selectEquipmentProposalsItems,
  getEquipmentProposalsItems,
  selectEquipmentProposalsItemsCount,
} from "@/store/equipmentproposalsSlice";

export async function getStaticPaths() {
  // Specify the paths that should be pre-rendered
  const paths = [
    { params: { slug: "" } },
    // ...
  ];

  return { paths, fallback: "blocking" };
}

// interface ReactTableProps {
//   dataArray: Array;
// }

const ReactTable: React.FC<> = () => {
  const dispatch = useDispatch();
  const items = useSelector(selectEquipmentProposalsItems);
  const totalItemsCount = useSelector(selectEquipmentProposalsItemsCount);

  const [itemOffset, setItemOffset] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(9);
  console.log(items);

  useEffect(() => {
    dispatch(
      getEquipmentProposalsItems({ limit: itemsPerPage, offset: itemOffset })
    );
  }, [itemOffset, itemsPerPage]);

  useEffect(() => {
    if (items.length > 0) {
      // first accordion opened and button changed by default
      setTimeout(() => {
        const firstTr = document.querySelectorAll("tbody tr:first-child");
        firstTr[0].classList.add("is-open");

        const detailsButton = document.querySelectorAll(".details-button");
        const spanElement = detailsButton[0].querySelectorAll("span");
        const imgElement = detailsButton[0].querySelectorAll("img");
        detailsButton[0].classList.add("is-changed");
        spanElement[0].innerText = "Close Details";
        imgElement[0].src = "/images/equipmentProposals/chevron-up-icon.svg";
      }, 100);
    }
  }, [items]);

  const handlePageClick = (selected: any) => {
    const newOffset = (selected * itemsPerPage) % totalItemsCount;
    setItemOffset(newOffset);
    setItemsPerPage(selected);
  };

  const data = useMemo(() => items, [items]);

  const toggleAccordion = (e: any) => {
    const trElement = e.target.closest("tr");

    const buttonElement = e.currentTarget;
    const spanElement = buttonElement.querySelector("span");
    const imgElement = buttonElement.querySelector("img");

    // open accordion that is clicked and change button
    if (trElement.classList.contains("is-open")) {
      trElement.classList.remove("is-open");

      spanElement.innerText = "See Details";
      imgElement.src = "/images/equipmentProposals/chevron-down-icon.svg";
      buttonElement.classList.remove("is-changed");
    } else {
      // close previously opened accordion
      const openedAccordion = document.querySelectorAll(".is-open");
      if (openedAccordion[0]) {
        openedAccordion[0].classList.remove("is-open");
      }
      trElement.classList.add("is-open");

      // change button of previously opened accordion
      const previousButton = document.querySelectorAll(".is-changed");
      if (previousButton[0]) {
        const previousSpanElement = previousButton[0].querySelectorAll("span");
        const previousImgElement = previousButton[0].querySelectorAll("img");
        previousButton[0].classList.remove("is-changed");
        previousSpanElement[0].innerText = "See Details";
        previousImgElement[0].src =
          "/images/equipmentProposals/chevron-down-icon.svg";
      }
      spanElement.innerText = "Close Details";
      imgElement.src = "/images/equipmentProposals/chevron-up-icon.svg";
      buttonElement.classList.add("is-changed");
    }
  };

  const columns = useMemo(
    () => [
      {
        Header: "Request #",
        accessor: "requestNo", // accessor is the "key" in the data
      },
      {
        Header: "Request Date",
        accessor: "requestDate",
      },
      {
        Header: "Supplier(s)",
        accessor: "suppliers",
        disableSortBy: true,
      },
      {
        Header: "Requested By",
        accessor: "requestedBy",
        disableSortBy: true,
        Cell: ({ row: { original } }) => (
          <>
            <p>{original.requestedBy.split(",")[0]}</p>
            <Link href="/supplies">{original.requestedBy.split(",")[1]}</Link>
          </>
        ),
      },
      {
        Header: "Actions",
        accessor: "action",
        disableSortBy: true,
        Cell: ({ row: { original } }) => (
          <DetailsButton onClick={toggleAccordion} className="details-button">
            <span>{original.action}</span>
            <img
              src="/images/equipmentProposals/chevron-down-icon.svg"
              alt="..."
            />
          </DetailsButton>
        ),
      },
    ],
    []
  );

  const tableInstance = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: itemOffset, pageSize: itemsPerPage,  setPageSize: handlePageClick, },
    },
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    // rows,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = tableInstance;

  return (
    <>
      <TableContainer {...getTableProps()}>
        <Table {...getTableProps()}>
          <THead>
            {headerGroups.map((headerGroup: any, index: number) => (
              <tr {...headerGroup.getHeaderGroupProps()} key={index}>
                {headerGroup.headers.map((column: any, i: number) => (
                  <th
                    {...column.getHeaderProps(column.getSortByToggleProps())}
                    key={i}
                  >
                    {column.render("Header")}
                    <span>
                      {column.isSorted
                        ? column.isSortedDesc
                          ? " 🔽"
                          : " 🔼"
                        : ""}
                    </span>
                  </th>
                ))}
              </tr>
            ))}
          </THead>
          <TBody {...getTableBodyProps()}>
            {page.map((row: any, index: number) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()} key={index}>
                  {row.cells.map((cell: any, i: number) => {
                    return (
                      <td {...cell.getCellProps()} key={i}>
                        {cell.render("Cell")}
                      </td>
                    );
                  })}
                  <TrAccordion key={index}>
                    <div>
                      <AccordionCard>
                        <h2>
                          Details for request # {row.original.requestNumber}
                        </h2>
                        <AccordionBody>
                          <Detail>
                            <h3>Manufacturer Name</h3>
                            <p>{row.original.manufacturerName}</p>
                          </Detail>
                          <Detail>
                            <h3>Product Name</h3>
                            {row.original.productName}
                          </Detail>
                          <Detail>
                            <h3>Manufacturer Part Number</h3>
                            {row.original.manufacturerPartNo}
                          </Detail>
                          <Detail>
                            <h3>Product Description / Additional Notes</h3>
                            {row.original.notes}
                          </Detail>
                        </AccordionBody>
                      </AccordionCard>
                    </div>
                  </TrAccordion>
                </tr>
              );
            })}
          </TBody>
        </Table>
        <ReactTablePagination
          canPreviousPage={canPreviousPage}
          canNextPage={canNextPage}
          pageOptions={pageOptions}
          pageCount={pageCount}
          gotoPage={gotoPage}
          nextPage={nextPage}
          previousPage={previousPage}
          setPageSize={setPageSize}
          pageIndex={pageIndex}
          pageSize={pageSize}
          totalResults={data.length}
          currentPageResults={page.length}
        />
      </TableContainer>
    </>
  );
};

export default ReactTable;
