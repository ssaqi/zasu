import Image from 'next/image'
import styled from 'styled-components';
import polygonBackground from '../../public/polygonBg.svg'

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-size: contain;
  width: 100px;
  height: 100px;
  align-self: center;
  background: url("${polygonBackground.src}") center no-repeat;
`

interface IconBoxProps {
    image: string
    title: string;
    description: string;
    className?: string;
}

export default function iconBox({image, title, description, className}: IconBoxProps) {
    return (
        <div>
            <div>
                <div className="flex flex-wrap text-center">
                    <div className='mt-8 ml-8'>
                        <div className="flex flex-col justify-center align-center">
                            <Container>
                                <Image src={image} alt={title} width={50} height={10}/>
                            </Container>
                            <div>
                                <h2 className='mt-4'>
                                    {title}
                                </h2>
                            </div>
                            <div className='mt-2'>
                                <p dangerouslySetInnerHTML={{__html: description}}/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
