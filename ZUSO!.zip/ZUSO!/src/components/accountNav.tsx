import Link from "next/link";
import { useRouter } from "next/router";
import CONSTANTS from "@/utils/constants";
import {
  AccountBox,
  AccountHeading,
  Divider,
  AccountSubTitle,
  IconColumn,
  IconRow,
  Icon,
  Head2,
  LogoutButton,
} from "@/styledComponents/navigation";
import { useSelector } from "react-redux";
import { selectAccountState } from "@/store/accountSlice";

export default function AccountNav() {
  const router = useRouter();

  const userDetails = useSelector(selectAccountState);

  const handleLogout = (e: React.MouseEvent<HTMLImageElement, MouseEvent>) => {
    // console.log(formData)
    fetch(CONSTANTS.api + "auth/logout", {
      method: "GET",
      credentials: "include",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    }).then((rsp) => {
      if (rsp.status == 200) {
        router.push("/");
        localStorage.removeItem("token");
      }
    });
  };

  return (
    <>
      <AccountBox>
        <AccountHeading>
          <h1>
            {userDetails.first_name} {userDetails.last_name}
          </h1>
          <span>{userDetails.email}</span>
        </AccountHeading>
        <Divider />
        <AccountSubTitle>
          <p>Company Name</p>
          <span>{userDetails.company_name}</span>
          <p>USER ID</p>
          <span>{userDetails.id}</span>
        </AccountSubTitle>
        <Divider />
        <IconColumn>
          <IconRow>
            <Icon src="./account.svg" alt="Home" />
            <Link href="/accountsAndBilling">Account & Billing</Link>
          </IconRow>
          <IconRow>
            <Icon src="./accountSupport.svg" alt="Search" />
            <Link href="#">Support</Link>
          </IconRow>
          <IconRow>
            <Icon src="./Pricing-feature.svg" alt="Heart" />
            <Link href="#">Pricing Features</Link>
          </IconRow>
          <IconRow>
            <Icon src="./accountContact.svg" alt="User" />
            <Link href="#">Contact</Link>
          </IconRow>
        </IconColumn>
        <Divider />
        <IconColumn>
          <IconRow onClick={handleLogout}>
            <Icon src="./signOut.svg" alt="User" onClick={handleLogout} />
            <LogoutButton>Logout</LogoutButton>
          </IconRow>
        </IconColumn>
      </AccountBox>
    </>
  );
}
