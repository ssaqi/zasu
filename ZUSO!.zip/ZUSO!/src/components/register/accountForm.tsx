import * as React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {IRegister} from '@/types/registerTypes';
import {selectRegisterStage, setRegisterStage} from '@/store/registerSlice';
import {
    FormContainer,
    SubmitButton,
    Title,
    Input,
    Row,
    Column,
    FormHeading,
    InputHalf,
    ErrorMessage
} from '@/styledComponents/Forms';
import {useState} from 'react';
import {useRouter} from 'next/router'
import CONSTANTS from '@/utils/constants';
import {validateEmail} from '@/utils/utils';

export default function AccountForm() {

    const router = useRouter();
    const dispatch = useDispatch();
    const [companyNameError, setCompanyNameError] = useState(false)
    const [companyEmailError, setCompanyEmailError] = useState(false)
    const [companyEmailInvalidError, setCompanyEmailInvalidError] = useState(false)
    const [ownerEmailError, setOwnerEmailError] = useState(false)
    const [ownerEmailInvalidError, setOwnerEmailInvalidError] = useState(false)
    const [firstNameError, setFirstNameError] = useState(false)
    const [lastNameError, setLastNameError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)
    const [confirmPasswordError, setConfirmPasswordError] = useState(false)
    const [passwordsMatch, setPasswordsMatch] = useState(true)
    const [passwordLengthError, setPasswordLengthError] = useState(false)
    const registerStage = useSelector(selectRegisterStage);

    const [formData, setFormData] = React.useState<IRegister>({
        userIdRef: 0,
        companyName: registerStage.companyName,
        companyEmail: registerStage.companyEmail,
        ownerEmail: registerStage.ownerEmail,
        firstName: registerStage.firstName,
        lastName: registerStage.lastName,
        password: registerStage.password,
        confirmPassword: registerStage.confirmPassword,
        phoneNumber: '12334',
    });

    const handleContinue = () => {
        // console.log('handleContinue', formData);
        let formValid = true;
        if (formData.companyName == '') {
            formValid = false
            setCompanyNameError(true)
        } else {
            setCompanyNameError(false)
        }
        if (formData.companyEmail == '') {
            formValid = false;
            setCompanyEmailError(true)
        } else {
            setCompanyEmailError(false)
        }
        if (!validateEmail(formData.companyEmail)) {
            formValid = false;
            setCompanyEmailInvalidError(true)
        } else {
            setCompanyEmailInvalidError(false)
        }
        if (formData.ownerEmail == '') {
            formValid = false;
            setOwnerEmailError(true)
        } else {
            setOwnerEmailError(false)
        }
        if (!validateEmail(formData.ownerEmail)) {
            formValid = false;
            setOwnerEmailInvalidError(true)
        } else {
            setOwnerEmailInvalidError(false)
        }
        if (formData.firstName == '') {
            formValid = false;
            setFirstNameError(true)
        } else {
            setFirstNameError(false)
        }
        if (formData.lastName == '') {
            formValid = false;
            setLastNameError(true)
        } else {
            setLastNameError(false)
        }
        if (formData.password == '') {
            formValid = false;
            setPasswordError(true)
        } else {
            setPasswordError(false)
        }
        if (formData.confirmPassword == '') {
            formValid = false;
            setConfirmPasswordError(true)
        } else {
            setConfirmPasswordError(false)
        }
        if (formData.password !== formData.confirmPassword) {
            formValid = false;
            setPasswordsMatch(false)
        } else {
            setPasswordsMatch(true)
        }
        if (formData.password.length < 8) {
            formValid = false;
            setPasswordLengthError(true)
        } else {
            setPasswordLengthError(false)
        }

        if (formValid) {
            registerUser()
        }
    }

    const registerUser = () => {
        fetch(CONSTANTS.api + 'registration/register', {
            method: 'POST',
            // credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
        .then(r => r.json())
        .then((rsp: any) => {
            // console.log('Response:',rsp)
            if (rsp.message == 'success') {
                setFormData({
                    ...formData,
                    ['userIdRef']: rsp.userId,
                })
                dispatch(setRegisterStage(formData))
                router.push('/registerLocation?id=' + rsp.userId)
            } else {
                // console.log(rsp.message)
                throw Error(rsp.message);
            }
        }).catch((error) => {
            console.log(error.ErrorMessage)
            alert("Owner Email already taken");
        });
    }

    const handleChange = (e: React.FormEvent<HTMLInputElement>): void => {
        setFormData({
            ...formData,
            [e.currentTarget.id]: e.currentTarget.value,
        })
    }

    return (
        <FormContainer>
            <Column>
                <FormHeading>Create your Zuso account</FormHeading>
            </Column>
            <Column>
                <Title>Company Name</Title>
                <Input type="text" id="companyName" onChange={handleChange} value={formData.companyName}/>
                {
                    companyNameError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                }
            </Column>
            <Column>
                <Title>Company Email</Title>
                <Input type="email" id="companyEmail" onChange={handleChange} value={formData.companyEmail}/>
                {
                    companyEmailError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                }
                {
                    companyEmailInvalidError ? <ErrorMessage>*Invalid Email.</ErrorMessage> : null
                }
            </Column>
            <Column>
                <Title>Owner Email</Title>
                <Input type="email" id="ownerEmail" onChange={handleChange} value={formData.ownerEmail}/>
                {
                    ownerEmailError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                }
                {
                    ownerEmailInvalidError ? <ErrorMessage>*Invalid Email.</ErrorMessage> : null
                }
            </Column>
            <Row>
                <Title>First Name</Title>
                <Title>Last Name</Title>
            </Row>
            <Row>
                <Column style={{width: '50%'}}>
                    <InputHalf type="text" id="firstName" onChange={handleChange} value={formData.firstName}/>
                    {
                        firstNameError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                    }
                </Column>
                <Column style={{width: '50%'}}>
                    <InputHalf type="text" id="lastName" onChange={handleChange} value={formData.lastName}/>
                    {
                        lastNameError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                    }
                </Column>
            </Row>
            <Row>
                <Title>Password</Title>
                <Title>Confirm Password</Title>
            </Row>
            <Row>
                <Column style={{width: '50%'}}>
                    <InputHalf type="password" id="password" onChange={handleChange} value={formData.password}/>
                    {
                        passwordError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                    }
                    {
                        passwordLengthError ? <ErrorMessage>*Password should be at least 8 characters long.</ErrorMessage> : null
                    }
                </Column>
                <Column style={{width: '50%'}}>
                    <InputHalf type="password" id="confirmPassword" onChange={handleChange}
                               value={formData.confirmPassword}/>
                    {
                        confirmPasswordError ? <ErrorMessage>*This field is required.</ErrorMessage> : null
                    }
                    {
                        formData.password !== '' && formData.confirmPassword !== '' && !passwordsMatch ?
                            <ErrorMessage>*Passwords Do not match.</ErrorMessage> : null
                    }
                </Column>
            </Row>
            <Column>
                <SubmitButton onClick={handleContinue}>Continue</SubmitButton>
            </Column>
            <Column>
                <p className="text-right text-xs text-white">*All fields required</p>
            </Column>
        </FormContainer>
    )
}
