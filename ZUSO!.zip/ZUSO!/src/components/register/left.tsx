import * as React from 'react';
import styled from 'styled-components';

const InfoContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  padding: 4rem;
  
  @media only screen and (max-width: 1024px) {
    padding: 0.5rem;
  }

  @media only screen and (max-width: 500px) {
    padding: 0rem;
  }
`


const List = styled.ul`
    list-style: none;
`

const ListItem = styled.li`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  padding: 0.5rem;
  @media only screen and (max-width: 500px) {
    padding: 0.25rem;
  }
`

const Icon = styled.img`
  width: 30px;
  margin-right: 10px;
`

export default function Left() {

    return (
        <InfoContainer>
            <List>
                <ListItem><Icon src="/green-tick.png"/><p className='text-white'>Manage all your supplies in one place.</p></ListItem>
                <ListItem><Icon src="/green-tick.png"/><p className='text-white'>Request product samples and product demos.</p></ListItem>
                <ListItem><Icon src="/green-tick.png"/><p className='text-white'>Keep track of your preventative maintenance schedule.</p></ListItem>
                <ListItem><Icon src="/green-tick.png"/><p className='text-white'>Contact industry representatives for all dental-related products.</p></ListItem>
            </List>
        </InfoContainer>
    )
}
