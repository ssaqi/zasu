import Link from "next/link";
import * as React from "react";
import { useDispatch, useSelector } from "react-redux";
import { IPayment } from "@/types/registerTypes";
import {
  selectLocationStage,
  selectPaymentStage,
  selectPlanStage,
  selectRegisterStage,
  setPaymentStage,
} from "@/store/registerSlice";
import { useRouter } from "next/router";
import {
  Column,
  ErrorMessage,
  Form,
  FormContainer,
  FormHeading,
  Input,
  InputOneThird,
  Row,
  SelectMonth,
  SelectYear,
  SubmitButton,
  Title,
} from "@/styledComponents/Forms";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import CONSTANTS from "@/utils/constants";
import { CardElement, useElements, useStripe } from "@stripe/react-stripe-js";
import { createPaymentIntent } from "@/services/PaymentIntentService";
import { createDiffieHellman } from "crypto";
import { log } from "console";

export default function PaymentDetailsForm() {
  const stripe = useStripe();
  const elements = useElements();
  const [cardInputComplete, setCardInputComplete] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  // const [_isMobile, setIsMobile] = useState(false)
  // useEffect(() => {
  //     if (isMobile) {
  //         setIsMobile(true)
  //     }
  // })

  const router = useRouter();
  const { id } = router.query;
  const planStage = useSelector(selectPlanStage);
  // const dispatch = useDispatch();

  const handleCardChange = (event: any) => {
    console.log(`Card Input: ${JSON.stringify(event)}`);
    setCardInputComplete(event.complete);
    if (event.error) {
      setErrorMsg(event.error.message);
    } else {
      setErrorMsg("");
    }
  };

  const handleContinue = (event: any) => {
    event.preventDefault();
    if (!cardInputComplete) {
      return;
    }

    // console.log('handleContinue');
    if (elements !== null) {
      const cardElement = elements.getElement(CardElement);
      // dispatch(setPaymentStage(formData))

      createPaymentIntent(Number(id), planStage.planId, "usd").then(
        (paymentIntent: any) => {
          // console.log(paymentIntent, ' <<< response from backend')
          // @ts-ignore
          stripe
            .createPaymentMethod(
              // @ts-ignore
              { type: "card", card: cardElement }
            )
            .then((paymentMethod: any) => {
              // console.log(paymentIntent.client_secret, ' <<<< response from stripe')
              stripe
                ?.confirmCardPayment(paymentIntent.client_secret, {
                  payment_method: paymentMethod.paymentMethod.id,
                })
                .then((paymentConfirm: any) => {
                  // console.log(paymentConfirm.paymentIntent, ' <<<< payment confirm')
                  if (paymentConfirm.paymentIntent.status === "succeeded") {
                    paymentSucceeded(paymentConfirm.paymentIntent.id);
                  } else {
                    alert("Something Went Wrong!, Please try again later");
                  }
                });
            });
        }
      );
    }
  };

  const paymentSucceeded = (paymentId: string) => {
    fetch(CONSTANTS.api + "registration/registerPayment", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        paymentId: paymentId,
        userId: id,
      }),
    })
      .then((response) => response.json())
      .then((rsp) => {
        // console.log(rsp, ' <<<< final response from backend')
        if (rsp.message == "success") {
          router.push("/registerConfirm");
        } else {
          throw Error(rsp.statusText);
        }
      })
      .catch((error) => {
        console.log(error);
        alert("Request not completed!");
      });
  };

  return (
    <FormContainer>
      <Column>
        <FormHeading>Enter your payment details</FormHeading>
      </Column>
      <Column>
        <Title>You have selected</Title>
        <div className="col-span-2">
          <input
            type="button"
            className="rounded-sm mb-3 w-full text-zuso-dark-blue text-sm font-bold bg-zuso-yellow p-2"
            value={
              planStage.planId == 1
                ? "ZuSo Membership - $199 / month"
                : "ZuSo Membership - $1,999 / year"
            }
          />
        </div>
      </Column>
      <Form onSubmit={handleContinue}>
        <CardElement
          onChange={handleCardChange}
          className="card-container"
          options={{
            hidePostalCode: true,
            style: {
              base: {
                color: "black",
                fontSize: "14px",
                lineHeight: "14px",
                backgroundColor: "white",
                padding: "10px",
                "::placeholder": {
                  color: "black",
                },
              },
            },
          }}
        />

        <Column>
          {errorMsg ? <ErrorMessage>*{errorMsg}</ErrorMessage> : null}
          <SubmitButton type="submit">Complete Registration</SubmitButton>
        </Column>
      </Form>
      <Column>
        <p className="text-right text-xs text-white">*All fields required</p>
      </Column>
    </FormContainer>
  );
}
