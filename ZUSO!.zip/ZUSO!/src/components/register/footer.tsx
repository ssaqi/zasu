import Link from 'next/link';
import styled from 'styled-components';
import {isMobile} from 'react-device-detect';
import {useEffect, useState} from 'react';

const Container = styled.div`
  display: flex;
  justify-content: flex-start;
  width: 100%;
  padding-left: 2.5rem;
  padding-bottom: 2rem;
  gap: 0.5rem;
  position: absolute;
  bottom: 0px;

  @media only screen and (max-width: 1025px) {
    padding-bottom: 1rem;
    position: initial;
  }

  @media only screen and (max-width: 500px) {
    // for mobile 
    position: initial;
    padding: 1rem;
    flex-direction: column;
  }

`

const MobileSeparator = styled.div`
  width: 100%;
  margin-top: 10px;
`

const MobileContainer = styled.div`
  display: flex;
  flex-direction: row;
`

const FirstLink = styled.a`
  font-size: 12px;
  white-space: nowrap;
  color: white;
  font-weight: bolder;
  padding: 0rem 1rem;

  @media only screen and (max-width: 1025px) {
    font-size: 10px;
  }
  
  @media only screen and (max-width: 500px) {
    width: 100%;
    padding: 0rem 0rem 0rem 1rem;
  }
`

const Links = styled.a`
  font-size: 12px;
  white-space: nowrap;
  color: white;
  padding: 0rem 1rem;

  @media only screen and (max-width: 1025px) {
    font-size: 10px;
    color: white;
    padding-left: 7rem;
    
  }
  
  @media only screen and (max-width: 500px) {
    margin-bottom: 20px;
    padding-left: 1rem;
  }
`

export default function Footer() {

    const [_isMobile, setIsMobile] = useState(false)

    useEffect(() => {
        if (isMobile) {
            setIsMobile(true)
        }
    })
    return (
        <Container>
            {
                _isMobile ?
                    <>
                        <MobileSeparator>
                            <FirstLink href="/">© 2020 ZuSo Supply LLC</FirstLink>
                        </MobileSeparator>
                        <MobileContainer>
                            <Links href="/">Terms of Service</Links>
                            <Links href="/">Privacy Policy</Links>
                            <Links href="/">Send Feedback</Links>
                        </MobileContainer>
                    </> :
                    <>
                        <FirstLink href="/">© 2020 ZuSo Supply LLC</FirstLink>
                        <Links href="/">Terms of Service</Links>
                        <Links href="/">Privacy Policy</Links>
                        <Links href="/">Send Feedback</Links>
                    </>
            }
        </Container>
    )
}
