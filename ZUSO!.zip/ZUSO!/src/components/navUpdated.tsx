import React, {useState} from "react";
import {Transition} from "@headlessui/react";
import Image from "next/image"
import Link from 'next/link'
import CONSTANTS from "@/utils/constants";
import {useRouter} from "next/router";
import NavItem from "./navItem";
import Menu from '@/components/megaMenu';
import dropdownIcon from '../../public/Dropdown.svg'
import styled from 'styled-components';

const Icon = styled.img`
  width: 10px;
`

export default function Nav() {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const toggleMenu = () => {
        setIsOpen(!isOpen)
    }

    function handleSearch(event: any) {
        setSearchTerm(event.target.value);
    }

    const router = useRouter();

    const handleLogout = () => {

        // console.log(formData)
        fetch(CONSTANTS.api + 'auth/logout', {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then((rsp) => {
                if (rsp.status == 200) {
                    router.push('/')
                }
            })
    }

    return (
        <>
            <header className="bg-zuso-navbar-bg-dark">
                <div className="mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">

                        {/* First column - Navigation */}

                        <div className="flex-shrink-0">
                            <nav className="bg-zuso-navbar-bg-dark">
                                <div>
                                    <div className="flex items-center justify-start h-12">
                                        <div className="flex items-start">
                                            <div className="flex-shrink-0">
                                                <Image
                                                    width="30"
                                                    height='100'
                                                    src="/db-logo.svg"
                                                    alt="Workflow"
                                                />
                                            </div>
                                            <div className="hidden md:block">
                                                <div className="ml-4 flex items-baseline cursor-pointer">
                                                    {/*<NavItem title="Catalog" icon={true} onClick={setIsOpen(!isOpen)}/>*/}
                                                    <span onClick={toggleMenu}
                                                          className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                                                        Catalog&nbsp;&nbsp;
                                                        <Icon src={dropdownIcon.src} alt=""/>
                                                    </span>
                                                    <span onClick={toggleMenu}
                                                          className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                                                        Reorders&nbsp;&nbsp;
                                                        <Icon src={dropdownIcon.src} alt=""/>
                                                    </span>
                                                    <span onClick={toggleMenu}
                                                          className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                                                        Lists&nbsp;&nbsp;
                                                        <Icon src={dropdownIcon.src} alt=""/>
                                                    </span>
                                                    <Link href={'/order'}
                                                          className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                                                        Orders&nbsp;&nbsp;
                                                    </Link>
                                                    <Link href={'/approvals'}
                                                          className="flex justify-center align-center hover:bg-zuso-blue text-zuso-db-bg-gray px-3 py-2 rounded-md text-sm">
                                                        Approvals&nbsp;&nbsp;
                                                    </Link>
                                                    {/*<NavItem title="Reorders" icon={true}/>*/}
                                                    {/*<NavItem title="List" icon={true}/>*/}
                                                    {/*<NavItem title="Orders" icon={false}/>*/}
                                                    {/*<NavItem title="Approvals" icon={false}/>*/}
                                                </div>
                                            </div>
                                        </div>
                                        {/*<div className="-mr-2 flex md:hidden">*/}
                                        {/*    <button*/}
                                        {/*        onClick={() => setIsOpen(!isOpen)}*/}
                                        {/*        type="button"*/}
                                        {/*        className="bg-gray-900 inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white"*/}
                                        {/*        aria-controls="mobile-menu"*/}
                                        {/*        aria-expanded="false"*/}
                                        {/*    >*/}
                                        {/*        <span className="sr-only">Main menu</span>*/}
                                        {/*        {!isOpen ? (*/}
                                        {/*            <svg*/}
                                        {/*                className="block h-6 w-6"*/}
                                        {/*                xmlns="http://www.w3.org/2000/svg"*/}
                                        {/*                fill="none"*/}
                                        {/*                viewBox="0 0 24 24"*/}
                                        {/*                stroke="currentColor"*/}
                                        {/*                aria-hidden="true"*/}
                                        {/*            >*/}
                                        {/*                <path*/}
                                        {/*                    strokeLinecap="round"*/}
                                        {/*                    strokeLinejoin="round"*/}
                                        {/*                    strokeWidth="2"*/}
                                        {/*                    d="M4 6h16M4 12h16M4 18h16"*/}
                                        {/*                />*/}
                                        {/*            </svg>*/}
                                        {/*        ) : (*/}
                                        {/*            <svg*/}
                                        {/*                className="block h-6 w-6"*/}
                                        {/*                xmlns="http://www.w3.org/2000/svg"*/}
                                        {/*                fill="none"*/}
                                        {/*                viewBox="0 0 24 24"*/}
                                        {/*                stroke="currentColor"*/}
                                        {/*                aria-hidden="true"*/}
                                        {/*            >*/}
                                        {/*                <path*/}
                                        {/*                    strokeLinecap="round"*/}
                                        {/*                    strokeLinejoin="round"*/}
                                        {/*                    strokeWidth="2"*/}
                                        {/*                    d="M6 18L18 6M6 6l12 12"*/}
                                        {/*                />*/}
                                        {/*            </svg>*/}
                                        {/*        )}*/}
                                        {/*    </button>*/}
                                        {/*</div>*/}
                                    </div>
                                </div>
                            </nav>
                        </div>

                        {/* Second column - Search bar */}

                        {/*<div className="text-left items-start justify-between relative w-full max-w-md">*/}
                        {/*    <input*/}
                        {/*        type="text"*/}
                        {/*        placeholder="Search for a product by name or ID"*/}
                        {/*        value={searchTerm}*/}
                        {/*        onChange={handleSearch}*/}
                        {/*        className="py-2 pl-16 pr-3 block w-full leading-5 bg-white border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"*/}
                        {/*    />*/}
                        {/*    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">*/}
                        {/*        <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">*/}
                        {/*            <path*/}
                        {/*                fillRule="evenodd"*/}
                        {/*                d="M8 0a8 8 0 015.15 14.85l4.3 4.3a1 1 0 11-1.42 1.42l-4.3-4.3A8 8 0 118 0zm0 2a6 6 0 100 12A6 6 0 008 2z"*/}
                        {/*                clipRule="evenodd"*/}
                        {/*            />*/}
                        {/*        </svg>*/}
                        {/*    </div>*/}
                        {/*</div>*/}

                        {/* Third column - SVG */}

                        <div className="flex">
                            <div className='mx-auto px-4 sm:px-6 lg:px-8'>
                                <ul className='flex items-center justify-between h-16'>
                                    {/*<li className="ml-3 mr-5">*/}
                                    {/*    <Link href="/">*/}
                                    {/*        <Image*/}
                                    {/*            src='./Users.svg'*/}
                                    {/*            alt='usersImage'*/}
                                    {/*            width='20'*/}
                                    {/*            height='10'*/}
                                    {/*        />*/}
                                    {/*    </Link>*/}
                                    {/*</li>*/}
                                    {/*<li className="ml-3 mr-5">*/}
                                    {/*    <Link href="/">*/}
                                    {/*        <Image*/}
                                    {/*            src='./OrderNav.svg'*/}
                                    {/*            alt='usersImage'*/}
                                    {/*            width='20'*/}
                                    {/*            height='10'*/}
                                    {/*        />*/}
                                    {/*    </Link>*/}
                                    {/*</li>*/}
                                    {/*<li className="ml-3 mr-5">*/}
                                    {/*    <Link href="/">*/}
                                    {/*        <Image*/}
                                    {/*            src='./Settings.svg'*/}
                                    {/*            alt='usersImage'*/}
                                    {/*            width='20'*/}
                                    {/*            height='10'*/}
                                    {/*        />*/}
                                    {/*    </Link>*/}
                                    {/*</li>*/}
                                    <li className="ml-3 mr-5">
                                        <Link href="/">
                                            <Image
                                                src='./notification.svg'
                                                alt='usersImage'
                                                width='20'
                                                height='10'
                                            />
                                        </Link>
                                    </li>
                                    <li className="ml-3 mr-5">
                                        <Link href="/">
                                            <Image
                                                src='./shopping-cart.svg'
                                                alt='usersImage'
                                                width='20'
                                                height='10'
                                            />
                                        </Link>
                                    </li>
                                    <li className="ml-3 mr-5">
                                        {/* <Link href="/"> */}
                                        <Image
                                            style={{cursor: 'pointer'}}
                                            src='./signOut.svg'
                                            alt='usersImage'
                                            width='20'
                                            height='10'
                                            onClick={handleLogout}

                                        />
                                        {/* </Link> */}
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <Transition
                show={isOpen}
                enter="transition ease-out duration-100 transform"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="transition ease-in duration-75 transform"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
            >
                <Menu/>
            </Transition>
        </>
    )
}
