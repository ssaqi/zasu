// middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {
//      // Assume a "Cookie:nextjs=fast" header to be present on the incoming request
//   // Getting cookies from the request using the `RequestCookies` API
//   let cookie = request.cookies.get('access_token')?.value
//   console.log(cookie) // => 'fast'
//   const allCookies = request.cookies.getAll()
//   console.log(allCookies) // => [{ name: 'nextjs', value: 'fast' }]

//   request.cookies.has('access_token') // => true

//   // Setting cookies on the response using the `ResponseCookies` API
//   const response = NextResponse.next()
//   response.cookies.set('vercel', 'fast')
//   response.cookies.set({
//     name: 'vercel',
//     value: 'fast',
//     path: '/test',
//   })
//   cookie = response.cookies.get('vercel')?.value
// console.log('url',request.url);
    // if(!request.cookies.has('access_token')){
    //     return NextResponse.redirect(new URL('/', request.url))
    // }
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: '/api/:path*',
}