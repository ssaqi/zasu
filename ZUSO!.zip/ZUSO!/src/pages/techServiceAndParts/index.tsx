/* eslint-disable react-hooks/exhaustive-deps */
import {
  ServicePartsProposalsStyled,
  ContentWrapper,
  TopSection,
} from "@/styledComponents/techServiceAndParts/servicePartsProposal";
import MainNavigation from "@/components/navigation";
import DashboardFooter from "@/components/dashboardFooter";
import { useDispatch, useSelector } from "react-redux";
import ServicePartsProposalModal from "../../components/techServiceAndParts/ServicePartsProposalModal";
import { useState, useEffect } from "react";
import ReactTable from "@/components/techServiceAndParts/ReactTable";
import {
  selectServicePartsProposalItems,
  addItem,
} from "@/store/techServiceAndPartsSlice";
import { useUser } from "@/lib/hooks";

const TechServiceAndParts = () => {
  const dispatch = useDispatch();
  const user = useUser({ redirectTo: "/techServiceAndParts", redirectIfFound: true });
  const items = useSelector(selectServicePartsProposalItems);
  console.log(items);

  // useEffect(() => {
  //   if (items && items.length === 0) {
  //     for (let i = 0; i < 51; i++) {
  //       dispatch(
  //         // @ts-ignore
  //         addItem({
  //           requestNumber: `ZSEQ10001 - ${i + 1}`,
  //           requestDate: `May 25, 2023 - ${i + 1}`,
  //           requestType: `${
  //             i % 5 !== 0 ? "Send a Tech to my office" : "Handpiece Repair"
  //           }`,
  //           emergency: `${i % 5 != 0 ? (i % 2 == 0 ? "Yes" : "No") : ""}`,
  //           requestedBy: `Zachary Hoffman, zach.hoffman@willamettedental.com - ${
  //             i + 1
  //           }`,
  //           action: `See Details`,
  //           preferredDay: `Any Day - ${i + 1}`,
  //           preferredTime: `Any Time - ${i + 1}`,
  //           problemLocation: `Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem. - ${
  //             i + 1
  //           }`,

  //           manufacturerName: `User Input - ${i + 1}`,
  //           underWarranty: `User Input - ${i + 1}`,
  //           contactMeBy: `Email, Phone - ${i + 1}`,
  //           model: `User Input - ${i + 1}`,
  //           estimateFirst: `Yes - ${i + 1}`,
  //           serialNumber: `User Input - ${i + 1}`,
  //           sendShippingLabel: `No - ${i + 1}`,

  //           notes: `Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem. Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem. Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem.  - ${
  //             i + 1
  //           }`,
  //         })
  //       );
  //     }
  //   }
  // }, []);


  const [isServicePartsProposalModalOpen, setIsServicePartsProposalModalOpen] =
    useState(false);

  const closeServicePartsProposalModal = () => {
    setIsServicePartsProposalModalOpen(false);
  };

  return (
    <>
      <ServicePartsProposalsStyled>
        <MainNavigation />
        <ContentWrapper>
          <TopSection>
            <h1>Technical Service and Parts</h1>
            <button onClick={() => setIsServicePartsProposalModalOpen(true)}>
              Request Technical Service & Parts
            </button>
          </TopSection>
          <ReactTable  />
        </ContentWrapper>
        <DashboardFooter />
      </ServicePartsProposalsStyled>
      <ServicePartsProposalModal
        setIsOpen={setIsServicePartsProposalModalOpen}
        isOpen={isServicePartsProposalModalOpen}
        closeModal={closeServicePartsProposalModal}
        user={user}
      />
    </>
  );
};

export default TechServiceAndParts;
