import { useState } from "react";
import {
  Container,
  SideBar,
  CatalogSection,
  Row,
  RowContainer,
  Table,
  Th,
  Td,
  Tr,
  TableContainer,
  Span,
  CategorySpan,
  SkuSpan,
  Button,
  ButtonContainer,
  ButtonQTY,
  Quantity,
  TrContainer,
  TextContainer,
  ImageContainer,
  PageItem,
  Select,
  PageList,
  RowSpan,
  ColumnRow,
  ColumnLeft,
  ColumnRight,
  RowSideBar,
} from "@/styledComponents/catalog";
import Image from "next/image";
import Nav from "@/components/navigation";
import DashboardFooter from "@/components/footerDashboard";
import Filter from "../components/catalog/filter";
import Link from "next/link";

const tableData = [
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
  {
    id: 1,
    image: "/Placeholder.jpg",
    name: "AccuDent XD Alginate Impression System Syringe Material 9gm Packets",
    category: "Ivoclar Vivadent Inc",
    sku: "9229805",
    tag: "Tag1, Tag2",
    price: 10,
    quantity: 1,
  },
];

const CatalogFilter = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  // Logic for displaying current rows

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = tableData.slice(indexOfFirstRow, indexOfLastRow);

  // Logic for displaying page numbers

  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(tableData.length / rowsPerPage); i++) {
    pageNumbers.push(i);
  }

  // Handle click on page number

  const handleClick = (event: any) => {
    setCurrentPage(Number(event.target.key));
  };

  // Handle change of rows per page

  const handleChangeRowsPerPage = (event: any) => {
    setRowsPerPage(event.target.value);
    setCurrentPage(1); // Reset to first page
  };

  return (
    <>
      <div>
        <Nav />
        <RowContainer>
          <h1>Crown & Bridge</h1>
          <div>
            <button>Add Special Order Product</button>
            <Link href="/catalog">Back to main category</Link>
          </div>
        </RowContainer>
        <Container>
          <SideBar>
            <Filter />
          </SideBar>
          <CatalogSection>
            <TableContainer>
              <Table>
                <thead>
                  <Tr>
                    <Th>PRODUCT NAME</Th>
                    <Th>TAGS</Th>
                    <Th>PRICE</Th>
                    <Th>QTY</Th>
                    <Th>ACTIONS</Th>
                  </Tr>
                </thead>
                <tbody>
                  {currentRows.map((row) => (
                    <Tr key={row.id}>
                      <Td>
                        <TrContainer>
                          <ImageContainer>
                            <Image
                              src={row.image}
                              width="75"
                              height="75"
                              alt={row.name}
                            />
                          </ImageContainer>
                          <TextContainer>
                            <Span>{row.name}</Span>
                            <CategorySpan>
                              {row.category}
                              <SkuSpan>{row.sku}</SkuSpan>
                            </CategorySpan>
                          </TextContainer>
                        </TrContainer>
                      </Td>
                      <Td>
                        <h4>{row.tag}</h4>
                      </Td>
                      <Td>
                        <h5>${row.price.toFixed(2)}</h5>
                      </Td>
                      <Td>
                        <ButtonContainer>
                          <ButtonQTY>-</ButtonQTY>
                          <Quantity>{row.quantity}</Quantity>
                          <ButtonQTY>+</ButtonQTY>
                        </ButtonContainer>
                      </Td>
                      <Td>
                        <Button>
                          <img
                            src="/shopping-cart.svg"
                            width="16"
                            height="16"
                            alt="shoppingCartIcon"
                          />
                          Add to Cart
                        </Button>
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </TableContainer>
            <ColumnRow>
              <ColumnLeft>
                <RowSpan>Rows per page:</RowSpan>
                <Select value={rowsPerPage} onChange={handleChangeRowsPerPage}>
                  <option value="10">10</option>
                  <option value="15">15</option>
                  <option value="20">20</option>
                </Select>
              </ColumnLeft>
              <ColumnRight>
                <PageList>
                  {pageNumbers.map((number) => (
                    <PageItem
                      key={number}
                      // id={number}
                      onClick={handleClick}
                      active={currentPage === number ? true : false}
                    >
                      {number}
                    </PageItem>
                  ))}
                </PageList>
              </ColumnRight>
            </ColumnRow>
          </CatalogSection>
        </Container>
      </div>
      <DashboardFooter />
    </>
  );
};

export default CatalogFilter;
