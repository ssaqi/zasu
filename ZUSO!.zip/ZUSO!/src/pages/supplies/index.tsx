import DashboardFooter from "@/components/dashboardFooter";
import {
  ContentWrapper,
  PageContainer,
  Main,
} from "@/styledComponents/supplies/supplies";
import MainNavigation from "@/components/navigation";
import Header from "@/components/supplies/header";
import Sidebar from "@/components/supplies/Sidebar";
import Cards from "@/components/supplies/Cards";
// import Pagination from '@/components/supplies/Pagination';
import { useEffect, useState } from "react";
// import {get} from '@/utils/fetch';
import {
  Displaying,
  PaginationContainer,
  PaginationStyled,
  PerPage,
  PerPageDropDown,
} from "@/styledComponents/supplies/pagination";
import ReactPaginate from "react-paginate";
import { useDispatch, useSelector } from "react-redux";
import {
  getProducts,
  searchProducts,
  selectFilterBy,
  selectProducts,
  selectSearchQuery,
  selectTotalNumberOfProducts,
} from "@/store/productsSlice";
import NoSSR from "react-no-ssr";
import { useUser } from "@/lib/hooks";

export default function Supplies() {
  const dispatch = useDispatch();
  const productsFromStore = useSelector(selectProducts);
  const totalNumberOfProducts = useSelector(selectTotalNumberOfProducts);
  const searchQuery = useSelector(selectSearchQuery);
  const filterBy = useSelector(selectFilterBy);

  const [products, setProducts] = useState([]);
  const [itemOffset, setItemOffset] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(9);
  const endOffset = itemOffset + itemsPerPage;
  const [currentItems, setCurrentItems] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [orderBy, setOrderBy] = useState("");
  useUser({ redirectTo: "/supplies", redirectIfFound: true });

  console.log(`Filterby: ${filterBy.toString()}`);

  useEffect(() => {
    // @ts-ignore
    setProducts(productsFromStore);
  }, [productsFromStore]);

  useEffect(() => {
    // @ts-ignore
    setPageCount(Math.ceil(totalNumberOfProducts.total / itemsPerPage));
  }, [products, itemsPerPage, totalNumberOfProducts]);

  useEffect(() => {
    if (products.length > 0) {
      setCurrentItems(products);
    }
  }, [products, itemOffset]);

  const handlePageClick = (event: any) => {
    const newOffset =
      (event.selected * itemsPerPage) % totalNumberOfProducts.total;
    setItemOffset(newOffset);
  };

  useEffect(() => {
    if (searchQuery.length == 0) {
      dispatch(
        // @ts-ignore
        getProducts({
          limit: itemsPerPage,
          offset: itemOffset,
          orderBy: orderBy,
          filterBy: filterBy,
        })
      );
    } else {
      handleSearch();
    }
  }, [searchQuery, orderBy, itemsPerPage, itemOffset, filterBy]);

  const handleSearch = () => {
    dispatch(
      // @ts-ignore
      searchProducts({
        limit: itemsPerPage,
        offset: itemOffset,
        orderBy: orderBy,
        filterBy: filterBy,
        query: searchQuery,
      })
    );
  };

  const selectItemsPerPage = (event: any) => {
    setItemsPerPage(event.target.value);
  };

  return (
    <NoSSR>
      <PageContainer>
        <MainNavigation />
        <ContentWrapper>
          <Header />
          <Main>
            {/*// @ts-ignore*/}
            <Sidebar setOrderBy={setOrderBy} />
            {productsFromStore.length == 0 ? (
              <span>
                No products found for the given search query, Try something
                else.
              </span>
            ) : (
              <Cards products={currentItems} />
            )}
          </Main>
          {/*<Pagination data={products} setPageData={setPageData} itemsPerPage={5}/>*/}
          <PaginationStyled>
            <PerPage>
              <span>Show</span>
              <PerPageDropDown onChange={selectItemsPerPage}>
                <option value={9}>9</option>
                <option value={18}>18</option>
                <option value={27}>27</option>
                <option value={36}>36</option>
                <option value={45}>45</option>
                <option value={54}>54</option>
                <option value={63}>63</option>
                <img src="/images/supplies/chevron-down.svg" alt="..." />
              </PerPageDropDown>
              <span>products per page</span>
            </PerPage>
            <Displaying>
              Displaying {itemOffset} -{" "}
              {Number(itemOffset) + Number(itemsPerPage)} of{" "}
              {totalNumberOfProducts.total} Products
            </Displaying>
            <PaginationContainer>
              <ReactPaginate
                pageCount={pageCount}
                pageRangeDisplayed={5}
                onPageChange={handlePageClick}
                breakLabel="..."
                nextLabel="Next >"
                previousLabel="< Previous"
                renderOnZeroPageCount={null}
                className={"paginationContainer"}
                pageClassName={"paginationList"}
                activeClassName={"pageNumberActive"}
                previousClassName={"previous"}
                nextClassName={"previous"}
                disabledClassName={"previousDisabled"}
              />
            </PaginationContainer>
          </PaginationStyled>
        </ContentWrapper>
        <DashboardFooter />
      </PageContainer>
    </NoSSR>
  );
}
