import Head from "next/head";
import Link from "next/link";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import Footer from "@/components/register/footer";

export default function Home() {
  const [_isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (isMobile) {
      setIsMobile(true);
    }
  }, []);

  return (
    <>
      <div className="flex flex-col justify-between min-h-screen bg-zuso-blue">
        <Head>
          <title>Register Confirm</title>
        </Head>
        <main className="flex flex-col w-full flex-1 gap-10">
          <div className="flex flex-row">
            <div className="flex w-2/5 pl-10 pt-10">
              <div className="w-[185.48px] h-[63.38px]">
                <img src="/logo-white.png" alt="" />
              </div>
            </div>
          </div>

          <div className="flex flex-col h-3/4 mt-15 justify-center items-center mb-20 p-3">
            <div
              className={`flex ${
                _isMobile ? "w-full" : "w-2/3"
              } flex-col bg-white rounded-t-md p-4 justify-center items-center`}
            >
              <div className="w-[220px] h-[220px]">
                <img src="/confirmation.png" alt="" />
              </div>
              <span className="text-2xl font-semibold text-zuso-dark-blue-2 mb-4">
                Contratulations!
              </span>

              <span className="text-s text-center text-zuso-gray-2 mb-4">
                Thank you for registering for a ZuSo office Owner account. We
                will review your account info shortly, and once approved, send
                you a follow up email. Have a great day!
              </span>
              {/*<span className='text-s text-center text-zuso-gray-2'>If you did not receive any email from us within 30 minutes, please check your SPAM folder.</span>*/}
            </div>

            <div
              className={`flex ${
                _isMobile ? "w-full" : "w-2/3"
              } flex-col bg-zuso-gray rounded-b-md p-6 justify-center items-center`}
            >
              <div className="col-span-2">
                <Link href="/" passHref legacyBehavior>
                  <input
                    type="button"
                    className="rounded-sm w-full text-white text-sm text-bold hover:bg-zuso-btn-pressed hover:cursor-pointer bg-zuso-dark-blue-2 py-1.5 px-14"
                    value="Login to your account"
                  />
                </Link>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
}
