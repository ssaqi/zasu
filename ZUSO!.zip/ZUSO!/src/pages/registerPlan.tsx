import * as React from "react";
import Head from "next/head";
import Link from "next/link";
import { useRouter } from "next/router";
import { useSelector, useDispatch } from "react-redux";
import { selectPlanStage, setPlanStage } from "../store/registerSlice";
import { IPlan } from "@/types/registerTypes";
import {
  ArrowIcon,
  BackContainer,
  NavContainer,
  NavWrapper,
  Numbers,
  NumbersMuted,
  Logo,
} from "@/styledComponents/register";
import LeftArrow from "../../public/arrowLeft.svg";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import Footer from "@/components/register/footer";
import styled from "styled-components";
import lightBackground from "../../public/paymentBackgroundPolygonWhite.svg";
import darkBackground from "../../public/paymentBackgroundPolygonDark.svg";

const SelectPlan = styled.h2`
  color: white;
  align-self: center;
`;

const PlansContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 6rem;
  padding: 2rem 2rem;

  @media only screen and (max-width: 1025px) {
    gap: 2rem;
  }

  @media only screen and (max-width: 500px) {
    flex-direction: column;
  }
`;

const Plan = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  //gap: 6rem;
  padding: 1.5rem 1.5rem;
  border-radius: 5px;

  @media only screen and (max-width: 500px) {
    //flex-direction: column;
  }
`;

const ImageWrapper = styled.div`
  padding: 3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  background-position: center;
  background-repeat: no-repeat;
`;

const Image = styled.img`
  width: 120px;
`;

export const ContinueButton = styled.button`
  color: white;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  padding: 10px 0px;
  background: #1e9ed4;
  border-radius: 4px;
  width: 300px;
  transition-duration: 1s;
  margin-top: 20px;

  @media only screen and (max-width: 1024px) {
    //width: 100%;
  }

  :hover {
    background: #17325e;
  }
`;

export default function Home() {
  const [_isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (isMobile) {
      setIsMobile(true);
    }
  }, []);

  const planStage = useSelector(selectPlanStage);

  const dispatch = useDispatch();
  const router = useRouter();
  const { id } = router.query;
  const [formData, setFormData] = React.useState<IPlan>({
    planId: planStage.planId,
  });

  // const handleContinue = () =>{
  //     // console.log('handleContinue', registerStage);
  //     dispatch(setPlanStage(formData))
  //     // console.log(registerStage, locationStage, planStage, paymentStage)
  // }

  const handleChange = (e: React.FormEvent<HTMLButtonElement>): void => {
    // console.log(formData)
    if (formData.planId == Number(e.currentTarget.value)) {
      dispatch(setPlanStage(formData));
      router.push("/registerPayment?id=" + id);
    } else {
      setFormData({
        ...formData,
        [e.currentTarget.id]: e.currentTarget.value,
      });
    }
  };

  return (
    <>
      <div className="flex flex-col justify-between min-h-screen bg-zuso-blue">
        <Head>
          <title>Register Plan</title>
        </Head>
        <main className="flex flex-col w-full flex-1">
          <NavWrapper>
            <div className="flex pl-2 pt-5 align-center items-center justify-center">
              <Logo src="/logo-white.png" alt="" />
            </div>
            <div className="flex justify-between align-middle w-4/5 p-5 mt-5 mb:mt-1">
              {_isMobile ? (
                <>
                  <NavContainer>
                    <Numbers>3</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Select a Plan
                    </Link>
                  </NavContainer>
                </>
              ) : (
                <>
                  <NavContainer>
                    <Numbers>1</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Create Your Zuso Account
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <Numbers>2</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Your Location
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <Numbers>3</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Select a Plan
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <NumbersMuted>4</NumbersMuted>
                    <Link
                      href="#"
                      className="text-xs font-bold text-zuso-blue-disabled"
                    >
                      &nbsp; Payment
                    </Link>
                  </NavContainer>
                </>
              )}
            </div>
          </NavWrapper>
          <BackContainer>
            <Link href="/" passHref legacyBehavior>
              <span className="flex text-white font-semibold text-sm text-center hover:cursor-pointer">
                {<ArrowIcon src={LeftArrow.src} alt="" />} &nbsp;Back
              </span>
            </Link>
          </BackContainer>
          <SelectPlan>Select Plan</SelectPlan>
          <PlansContainer>
            <Plan
              className={
                formData.planId == 1 ? " bg-zuso-btn-pressed" : "bg-white"
              }
            >
              <button
                style={{ background: "#47BAEB" }}
                className="hover:bg-blue-700 text-white font-bold py-2 px-4 w-32 rounded-full mb-2.5"
              >
                MONTHLY
              </button>
              <ImageWrapper
                style={{
                  backgroundImage:
                    formData.planId == 1
                      ? `url(${darkBackground.src})`
                      : `url(${lightBackground.src})`,
                }}
              >
                <Image src="/plan-monthly.png" alt=""></Image>
              </ImageWrapper>
              <div>
                <span className="text-zuso-blue font-extrabold">
                  $199.00<span className="text-zuso-label font-thin">/mo</span>{" "}
                </span>
              </div>
              <span className="text-zuso-label font-thin mb-2">
                + $399 setup fee
              </span>
              {/* <Link href="/registerPayment" passHref legacyBehavior> */}
              <ContinueButton id="planId" value="1" onClick={handleChange}>
                {formData.planId == 1 ? "Continue" : "Choose Plan"}
              </ContinueButton>
              {/* </Link> */}
            </Plan>

            {/* <div className="flex flex-wrap w-1/4 p-24 bg-white hover:bg-zuso-btn-pressed rounded-md justify-center "> */}
            <Plan
              className={
                formData.planId == 2 ? " bg-zuso-btn-pressed" : "bg-white"
              }
            >
              <button
                style={{ background: "#47BAEB" }}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 w-32 rounded-full mb-2.5"
              >
                ANNUAL
              </button>
              <ImageWrapper
                style={{
                  backgroundImage:
                    formData.planId == 2
                      ? `url(${darkBackground.src})`
                      : `url(${lightBackground.src})`,
                }}
              >
                <Image src="/planYearly.svg" alt=""></Image>
              </ImageWrapper>
              <div>
                <span className="text-zuso-blue font-extrabold">
                  $1,999.00
                  <span className="text-zuso-label font-thin">/year</span>{" "}
                </span>
              </div>
              <span className="text-yellow-300 font-bold mb-2">
                $399 setup fee is waived!
              </span>
              {/* <Link href="/registerPayment" passHref legacyBehavior> */}
              <ContinueButton id="planId" value="2" onClick={handleChange}>
                {formData.planId == 2 ? "Continue" : "Choose Plan"}
              </ContinueButton>
              {/* </Link> */}
            </Plan>
          </PlansContainer>
        </main>
        <Footer />
      </div>
    </>
  );
}
