import React from 'react'
import Image from 'next/image'
import MainNavigation from "@/components/navigation";
import IMG from "../../components/img/images.png";
function index() {
  return (
    <>
    <MainNavigation/>
       <div className="main" 
    style={{width : "700px", height: "300px",backgroundColor: "#fff", margin: "50px",marginTop: "20px"}}>

      <div className="boxes" style={{display: "flex", flexDirection: "row"}}>
         <div className="box" style={{width: "300px", height: "100px",backgroundColor: "#fff", margin: 10}}>
            <p className="head" style={{fontSize: 13, fontWeight: "bold",color: "#47BAEB"}}>
            Shipping Address
            </p>
           <p className="address" style={{fontSize : 10}}>John OfficeOwner 
Willamette Dental Group
220 NE Weidler St, Portland, OR 97232
512-123-4567</p> 
         </div>
         <div className="box" style={{width: "300px", height: "100px",backgroundColor: "white", margin: 10}}>
         <p className="head" style={{fontSize: 13, fontWeight: "bold",color: "#47BAEB"}}>
         Billing address
            </p>
           <p className="address" style={{fontSize : 10}}>John OfficeOwner 
           John OfficeOwner 
Willamette Dental Group
220 NE Weidler St, Portland, OR 97232
512-123-4567</p>
          </div>
      </div>
   <p style={{fontSize : 10, marginLeft: "20px", marginTop: "-30px"}}>Shipping and billing addresses can be changed in the account settings. There can be only one shipping address per office.</p>
    <hr style={{marginTop: "20px"}}/>
    <div className="boxes" style={{display: "flex", flexDirection: "row"}}>
         <div className="box" style={{width: "300px", height: "100px",backgroundColor: "#fff", margin: 10}}>
            <p className="head" style={{fontSize: 13, fontWeight: "bold",color: "#47BAEB"}}>
            Schedule Order Date
            </p>
           <p className="address" style={{fontSize : 10}}> 
            <input type='date'  style={{border : "solid 1px #000", width: "150px", height: "30px",borderColor: "gray"}}/>
          </p> 

          <p  style={{fontSize: 13, fontWeight: "bold",color: "#47BAEB",marginTop: 10}}>Rush this order</p>
          <input type='radio'style={{margin:5,fontSize: 13}}/> Yes
          <input type='radio' style={{margin:5,fontSize: 13}}/> No
         </div>
         <div className="box" style={{width: "300px", height: "100px",backgroundColor: "white", margin: 10}}>
         <p className="head" style={{fontSize: 13, fontWeight: "bold",color: "#47BAEB"}}>
         Notes for ZuSo Concierge
            </p>
           <input type='text' className="address" style={{width: "350px", height: "90px",borderRadius: 6,border: "solid 1px #000",fontSize : 10}}/>
          </div>
      </div>

    
      <div style={{marginTop: 70}}>
        <p>Midwest Dental Items</p>
      <hr/>
      <br/>
      <div className='main' style={{display: "flex", flexDirection: "row",}}>
      <div className='smallCard' style={{width: 200, height: 300,backgroundColor: "#fff",borderRadius: 10,margin: 20}}>
     <br/>
      <center>
      <Image 
      src={IMG}
      alt="Picture of the author"
      width={80}
      height={80}
      />
      </center>
      <p style={{fontSize: 10,fontWeight: "bold",margin: 5 }}>CaviWipes 2.0 Disinfectant Towelettes, X-Large Size, 9" x 12", 65 Count, 65/can</p>
      <p style={{fontSize: 11, margin: 5}}>Supplier SKU# abc-123
Mfr: ManufName (#MPNhere) Your nickname(s): Tag 1, Tag 2  &emsp; <spna style={{fontWeight: "bold"}}>$11.95</spna></p>
<button style={{width: 100, height: 20, backgroundColor: "Green", fontSize: 10, margin: 5,color: "#fff",borderRadius: 5}}>In Cart</button>
      </div>
      <br/>
      <div className='smallCard' style={{width: 200, height: 300,backgroundColor: "#fff",borderRadius: 10,margin: 20}}>
     <br/>
      <center>
      <Image 
      src={IMG}
      alt="Picture of the author"
      width={80}
      height={80}
      />
      </center>
      <p style={{fontSize: 10,fontWeight: "bold",margin: 5 }}>CaviWipes 2.0 Disinfectant Towelettes, X-Large Size, 9" x 12", 65 Count, 65/can</p>
      <p style={{fontSize: 11, margin: 5}}>Supplier SKU# abc-123
Mfr: ManufName (#MPNhere) Your nickname(s): Tag 1, Tag 2  &emsp; <spna style={{fontWeight: "bold"}}>$11.95</spna></p>
<button style={{width: 100, height: 20, backgroundColor: "Green", fontSize: 10, margin: 5,color: "#fff",borderRadius: 5}}>In Cart</button>
      </div>
</div>

</div>
<div className='smallCard' style={{width: 200, height: 300,backgroundColor: "#fff",borderRadius: 10,margin: 20}}>
     <br/>
      <center>
      <Image 
      src={IMG}
      alt="Picture of the author"
      width={80}
      height={80}
      />
      </center>
      <p style={{fontSize: 10,fontWeight: "bold",margin: 5 }}>CaviWipes 2.0 Disinfectant Towelettes, X-Large Size, 9" x 12", 65 Count, 65/can</p>
      <p style={{fontSize: 11, margin: 5}}>Supplier SKU# abc-123
Mfr: ManufName (#MPNhere) Your nickname(s): Tag 1, Tag 2  &emsp; <spna style={{fontWeight: "bold"}}>$11.95</spna></p>
<button style={{width: 100, height: 20, backgroundColor: "Green", fontSize: 10, margin: 5,color: "#fff",borderRadius: 5}}>In Cart</button>
      </div>



    </div>


  


    <div className='side' style={{width: 300, height:800, backgroundColor: "#fff", 
    float: "right",marginLeft: "-50px", marginTop: "-350px"}}>
  
            <h4 className='Heading'>Total</h4>
            <hr className='line' />
            <div className='parent'>
                <p className='item'>Heny Schen items
                    &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;
                    <span className='span'>$1239.95</span></p>
                <hr />
                <p className='item'>Midwest Dental items
                    &emsp;&emsp;&emsp;&emsp;&emsp;
                    <span className='span'>$1412.95</span></p>
                <hr />
                <p className='item'>Special Order items
                    &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;
                    <span className='span'>$0.00</span></p>
                <hr />
                <div className='subtotal'>
                    <br />
                    <p className='item, color '>Savings
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;
                        &emsp;&emsp;&emsp;
                        <span className='span1'>-$TBD</span></p>
                    <p className='item , fcolor'>Subtotal
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp; 
                        &emsp;&emsp;
                        <span className='span'>$1652.90</span></p>
                    <p className='item , fcolor'>Shipping & Handling
                        &emsp;&emsp;&emsp;&emsp;&emsp; 
                        <span className='span'>$TBD</span></p>
                    <p className='item , fcolor'>Tax
                        &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;
                        &emsp;&emsp;&emsp;
                        <span className='span'>$TBD</span></p>
                    <hr />
                </div>
            </div>

            <h4 className='Heading'>Grand Total
                &emsp;
                <span className='span1'>$1652.90</span> 
            </h4>

            <div className='userinput'>
                <input type='text' placeholder='Enter Coupon Here' className='inp' />
                <button className='btn'>Remove</button>
            </div>

            <div className='userinput'>
                <button className='btnn'>Checkout with Selected Products</button>
            </div>
            <div className='userinput'>
                <button className='btnnn'> Add Selected Products to List</button>
            </div>
            <div className='userTax'>
                <p className='tax'>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                    Lorem Ipsum has been the industry's standard dummy text
                    Lorem Ipsum has been the industry's standard dummy text
                </p>
            </div>
        </div>



    </>
  )
}

export default index