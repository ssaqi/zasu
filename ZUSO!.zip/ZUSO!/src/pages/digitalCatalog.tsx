import Image from "next/image";
import {
  Container,
  Table,
  Td,
  Tr,
  DownloadButton,
} from "@/styledComponents/digitalCatalog";
import NavSearch from "../components/dashboard/navSearch";
import FooterDashboard from "@/components/footerDashboard";
import { useUser } from "@/lib/hooks";
import MainNavigation from "@/components/navigation";

export default function DigitalCatalog() {
  useUser({ redirectTo: "/digitalCatalog", redirectIfFound: true });
  return (
    <>
      <MainNavigation />
      <NavSearch />
      <div>
        <Container>
          <h1>Catalog & E-Zines</h1>
          <p>Click on a Catalog below to download as a PDF.</p>
        </Container>
        <Table>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
        </Table>
        <Table>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
        </Table>
        <Table>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
          <Tr>
            <Td>
              <Image
                src="/DigitalCatalog.png"
                width="200"
                height="300"
                alt="DigitalCatalog.png"
              />
            </Td>
            <Td>Basic Guide to Dental Instruments</Td>
            <Td>
              <span>Carmen Scheller</span>
            </Td>
            <Td>
              <DownloadButton>
                <Image
                  src="/downloadDigital.svg"
                  alt=""
                  width="14"
                  height="14"
                />
                Download
              </DownloadButton>
            </Td>
          </Tr>
        </Table>
        <div></div>
      </div>
      <FooterDashboard />
    </>
  );
}
