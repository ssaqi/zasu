import "src/styles/globals.css";
import type { AppProps } from "next/app";
import { Provider } from "react-redux";
import { wrapper } from "../store/store";
import Head from "next/head";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import CONSTANTS from "@/utils/constants";

function App({ Component, ...rest }: AppProps) {
  const stripePromise = loadStripe(CONSTANTS.stripe_public_key);
  const { store, props } = wrapper.useWrappedStore(rest);
  const { pageProps } = props;

  return (
    <>
      <Head>
        <title>Zuso</title>
      </Head>
      <Provider store={store}>
        <Elements stripe={stripePromise}>
          <Component {...pageProps} />
        </Elements>
      </Provider>
    </>
  );
}

export default App;
