import MainNavigation from "@/components/navigation";
import { useUser } from "@/lib/hooks";
import { Container } from "@/styledComponents/OrderStyle.ts/OrderStyle";

export default function Orders() {
   useUser({ redirectTo: "/orders", redirectIfFound: true });

   return (
      <>
         <MainNavigation />
         <div className="styled.main">
            <Container>

               <div className="search" style={{ width: 800, height: 70, backgroundColor: "#fff", margin: "auto", }}>

               </div>


               <div className="chlid"
                  style={{ width: 800, height: 500, backgroundColor: "#fff", margin: "auto" }}
               >

                  <div style={{ display: "flex", flexDirection: "row", margin: 10, justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>
                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>
                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>


                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>

                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>


                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>

                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div> <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>

                  </div> <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "lightgrey", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>ZESU PD</h3>
                  </div>



               </div>

            </Container>
         </div>
      </>
   );
}
