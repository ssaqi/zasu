import React from "react";

import MainNavigation from "@/components/navigation";
import DashboardFooter from "@/components/dashboardFooter";
import { BackgroundContainer } from "@/styledComponents/global";
import { ContentWrapper } from "@/styledComponents/global";
import { useUser } from "@/lib/hooks";

function Lists() {
   useUser({ redirectTo: "/lists", redirectIfFound: true });
   return (
      <BackgroundContainer>
         <MainNavigation />
         <ContentWrapper>

            <div className="styled.main">

               <h3 style={{ marginLeft: "80px", marginTop: "-30px" }}>Lists</h3>
               <button style={{ width: "100px", height: "25px", backgroundColor: "#1E9ED4", fontSize: 12, color: "#fff", float: "right", marginTop: "-30px", marginRight: "77px" }}>Create a List</button>

               <div className="chlid"
                  style={{ width: 800, height: 500, backgroundColor: "#fff", margin: "auto", marginTop: "10px" }}
               >

                  <div style={{
                     display: "flex", flexDirection: "row", margin: 0,
                     justifyContent: "space-between", width: "100%", backgroundColor: "#F8FAFC"
                  }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>&ensp;NAME</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        &emsp;&emsp;&emsp; &emsp;
                        ITEMS
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &ensp;
                        &ensp;
                        TOTAL
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>CREATED BY</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>CREATED ON</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Action</h3>
                  </div>
                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "#fff", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>
                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "#F8FAFC", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>


                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: "#fff", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>

                  <div style={{ display: "flex", flexDirection: "row", margin: 10, backgroundColor: " #F8FAFC", justifyContent: "space-between" }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>


                  <div style={{
                     display: "flex", flexDirection: "row", margin: 10,
                     backgroundColor: "#fff", justifyContent: "space-between"
                  }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>

                  <div style={{
                     display: "flex", flexDirection: "row", margin: 10,
                     backgroundColor: "#F8FAFC", justifyContent: "space-between"
                  }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>
                  <div style={{
                     display: "flex", flexDirection: "row", margin: 10,
                     backgroundColor: "white", justifyContent: "space-between"
                  }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>

                  </div>
                  <div style={{
                     display: "flex", flexDirection: "row", margin: 10,
                     backgroundColor: "#F8FAFC", justifyContent: "space-between"
                  }}>
                     <h3 style={{ fontSize: 12, margin: 10 }}>List Name</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>
                        <input type="text"
                           placeholder="5 Different items (13 quantity)"
                           style={{
                              width: "160px", borderRadius: "20px", fontSize: 9, textAlign: "center",
                              border: "solid 1px #000", backgroundColor: "#f5f7f6"
                           }} />
                     </h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>$315.00</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>Zachey Hoffman</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}>03/04/2021</h3>
                     <h3 style={{ fontSize: 12, margin: 10 }}> &emsp; &emsp;:</h3>
                  </div>



               </div>


            </div>


         </ContentWrapper>
         <DashboardFooter />
      </BackgroundContainer>
   );
}

export default Lists;
