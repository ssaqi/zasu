import DashboardFooter from "@/components/dashboardFooter";
import {
  AvatarBody,
  AvatarContainer,
  AvatarHeading,
  AvatarHeadingContainer,
  AvatarInput,
  AvatarProfileContainer,
  AvatarProfileHeading,
  AvatarProfileHeadingContainer,
  AvatarTitle,
  Container,
  CreateProfileButton,
  Header,
  MainHeading,
  PermissionName,
  Permissions,
  PermissionsBody,
  PermissionsCheckbox,
  PermissionsContainer,
  PermissionsHeading,
  PermissionsHeadingContainer,
  ProfileBody,
  ProfileBodyLeft,
  ProfileBodyRight,
  ProfileDescriptionInput,
  ProfileInput,
  ProfileInputLabel,
  AvatarImageIcon,
  ClickHereSpan,
  ProfileRows,
  ProfileInputContainer,
  ProfileInputError,
} from "@/styledComponents/users";
import imageIcon from "../../../../public/ImageIcon.svg";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import CONSTANTS from "@/utils/constants";
import * as React from "react";
import { validateEmail } from "@/utils/utils";
import MainNavigation from "@/components/navigation";
import UserSearchBar from "@/components/accountsAndBilling/users/searchBar";

export default function UserEdit() {
  const router = useRouter();
  const { id } = router.query;

  const [emailError, setEmailError] = useState(false);
  const [emailInvalidError, setEmailInvalidError] = useState(false);
  const [firstNameError, setFirstNameError] = useState(false);
  const [lastNameError, setLastNameError] = useState(false);
  const [phoneNumberError, setPhoneNumberError] = useState(false);
  const [positionError, setPositionError] = useState(false);
  // const [passwordError, setPasswordError] = useState(false)
  const [infoError, setInfoError] = useState(false);
  // const [confirmPasswordError, setConfirmPasswordError] = useState(false)
  // const [passwordsMatch, setPasswordsMatch] = useState(true)
  // const [passwordLengthError, setPasswordLengthError] = useState(false)
  const [permitOrders, setPermitOrders] = useState(false);
  const [permitApprovals, setPermitApprovals] = useState(false);
  const [permitUsers, setPermitUsers] = useState(false);
  const [permitSupport, setPermitSupport] = useState(false);
  const [permissions, setPermissions] = useState([]);

  const [formData, setFormData] = useState({
    email: "",
    first_name: "",
    last_name: "",
    position: "",
    info: "",
    phone_number: "",
    profile_image: "",
    permissions: [],
  });

  useEffect(() => {
    if (id !== undefined) {
      fetch(CONSTANTS.api + "users/id/" + id, {
        method: "GET",
        // credentials: 'include',
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
        .then((r) => r.json())
        .then((response) => {
          setFormData(response);
          // console.log(response, ' <<< ')
          setPermissions(response.permissions);
        });
    }
  }, []);

  useEffect(() => {
    permissions.forEach((permission) => {
      if (permission === "Users") {
        setPermitUsers(true);
      }
      if (permission === "Approvals") {
        setPermitApprovals(true);
      }
      if (permission === "Orders") {
        setPermitOrders(true);
      }
      if (permission === "Support") {
        setPermitSupport(true);
      }
    });
  }, [permissions]);

  const handleChange = (e: any): void => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value,
    });
  };

  const submitForm = () => {
    let formValid = true;
    if (formData.email == "") {
      formValid = false;
      setEmailError(true);
    } else {
      setEmailError(false);
    }
    if (!validateEmail(formData.email)) {
      formValid = false;
      setEmailInvalidError(true);
    } else {
      setEmailInvalidError(false);
    }
    if (formData.phone_number == "") {
      formValid = false;
      setPhoneNumberError(true);
    } else {
      setPhoneNumberError(false);
    }
    if (formData.info == "") {
      formValid = false;
      setInfoError(true);
    } else {
      setInfoError(false);
    }
    if (formData.first_name == "") {
      formValid = false;
      setFirstNameError(true);
    } else {
      setFirstNameError(false);
    }
    if (formData.last_name == "") {
      formValid = false;
      setLastNameError(true);
    } else {
      setLastNameError(false);
    }
    if (formData.position == "") {
      formValid = false;
      setPositionError(true);
    } else {
      setPositionError(false);
    }
    // if (formData.password == '') {
    //     formValid = false;
    //     setPasswordError(true)
    // } else {
    //     setPasswordError(false)
    // }
    // if (formData.confirmPassword == '') {
    //     formValid = false;
    //     setConfirmPasswordError(true)
    // } else {
    //     setConfirmPasswordError(false)
    // }
    // if (formData.password !== formData.confirmPassword) {
    //     formValid = false;
    //     setPasswordsMatch(false)
    // } else {
    //     setPasswordsMatch(true)
    // }
    // if (formData.password.length < 8) {
    //     formValid = false;
    //     setPasswordLengthError(true)
    // } else {
    //     setPasswordLengthError(false)
    // }
    if (formValid) {
      updateUser();
    }
  };

  const updateUser = () => {
    // console.log(formData, ' <<<< form data')
    const permissions = [];
    if (permitUsers) {
      permissions.push("Users");
    }
    if (permitApprovals) {
      permissions.push("Approvals");
    }
    if (permitOrders) {
      permissions.push("Orders");
    }
    if (permitSupport) {
      permissions.push("Support");
    }

    const body = {
      id: id,
      email: formData.email,
      firstName: formData.first_name,
      lastName: formData.last_name,
      position: formData.position,
      info: formData.info,
      phoneNumber: Number(formData.phone_number),
      permissions: permissions,
    };
    fetch(CONSTANTS.api + "users/update", {
      method: "POST",
      // credentials: 'include',
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
      body: JSON.stringify(body),
    })
      .then((r) => r.json())
      .then((rsp: any) => {
        // console.log('Response:',rsp)
        if (rsp.success) {
          // console.log('user registered')
          alert("User updated successfully");
          router.push("/accountsAndBilling/users");
        } else {
          // console.log(rsp.message)
          alert(rsp.message);
        }
      })
      .catch((error) => {
        console.log(error.ErrorMessage);
        alert(error);
      });
  };

  const addApprovalPermission = (event: any) => {
    if (event.target.checked) {
      setPermitApprovals(true);
    } else {
      setPermitApprovals(false);
    }
  };

  const addOrdersPermission = (event: any) => {
    if (event.target.checked) {
      setPermitOrders(true);
    } else {
      setPermitOrders(false);
    }
  };

  const addUsersPermission = (event: any) => {
    if (event.target.checked) {
      setPermitUsers(true);
    } else {
      setPermitUsers(false);
    }
  };

  const addSupportPermission = (event: any) => {
    if (event.target.checked) {
      setPermitSupport(true);
    } else {
      setPermitSupport(false);
    }
  };

  return (
    <>
      <MainNavigation />
      <UserSearchBar />
      <Container>
        <Header>
          <MainHeading>Edit User</MainHeading>
        </Header>
        <AvatarContainer>
          <AvatarHeadingContainer>
            <AvatarHeading>Profile Image</AvatarHeading>
          </AvatarHeadingContainer>
          <AvatarBody>
            <AvatarInput type="file" />
            <AvatarImageIcon src={imageIcon.src} alt="" />
            <AvatarTitle>
              Select a file or <ClickHereSpan>click here</ClickHereSpan>
            </AvatarTitle>
          </AvatarBody>
        </AvatarContainer>
        <AvatarProfileContainer>
          <AvatarProfileHeadingContainer>
            <AvatarProfileHeading>Profile Info</AvatarProfileHeading>
          </AvatarProfileHeadingContainer>
          <ProfileBody>
            <ProfileBodyLeft>
              <ProfileRows>
                <ProfileInputLabel>First name</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="first_name"
                    type="text"
                    placeholder="First name"
                    value={formData.first_name}
                    onChange={handleChange}
                  />
                  {firstNameError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Last name</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="last_name"
                    type="text"
                    placeholder="Last name"
                    value={formData.last_name}
                    onChange={handleChange}
                  />
                  {lastNameError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Position</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="position"
                    type="text"
                    placeholder="Position"
                    value={formData.position}
                    onChange={handleChange}
                  />
                  {positionError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>Email</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="email"
                    type="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  {emailError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                  {emailInvalidError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              {/*<ProfileRows>*/}
              {/*    <ProfileInputLabel>Password</ProfileInputLabel>*/}
              {/*    <ProfileInputContainer>*/}
              {/*        <ProfileInput id="password" type="password" placeholder="Password"*/}
              {/*                      value={formData.password} onChange={handleChange}/>*/}
              {/*        {*/}
              {/*            passwordError ? <ProfileInputError>This field is required*</ProfileInputError> : null*/}
              {/*        }*/}
              {/*        {*/}
              {/*            passwordLengthError ? <ProfileInputError>Password should be atleast 8 characters long</ProfileInputError> : null*/}
              {/*        }*/}
              {/*    </ProfileInputContainer>*/}
              {/*</ProfileRows>*/}
              {/*<ProfileRows>*/}
              {/*    <ProfileInputLabel>Confirm Password</ProfileInputLabel>*/}
              {/*    <ProfileInputContainer>*/}
              {/*        <ProfileInput id="confirmPassword" type="password" placeholder="Confirm Password"*/}
              {/*                      value={formData.confirmPassword} onChange={handleChange}/>*/}
              {/*        {*/}
              {/*            confirmPasswordError ? <ProfileInputError>This field is required*</ProfileInputError> : null*/}
              {/*        }*/}
              {/*        {*/}
              {/*            !passwordsMatch ? <ProfileInputError>Passwords do not match</ProfileInputError> : null*/}
              {/*        }*/}
              {/*    </ProfileInputContainer>*/}
              {/*</ProfileRows>*/}
              {/*<ProfileRows>*/}
              {/*    <PasswordInfo>Password should have a minimum of 8 chars and combination of*/}
              {/*        Lower Case and Upper Case letters.</PasswordInfo>*/}
              {/*</ProfileRows>*/}
              <ProfileRows>
                <ProfileInputLabel>Phone number</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="phoneNumber"
                    type="number"
                    placeholder="Phone Number"
                    value={formData.phone_number}
                    onChange={handleChange}
                  />
                  {phoneNumberError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
            </ProfileBodyLeft>
            <ProfileBodyRight>
              <ProfileInputLabel>Profile Description</ProfileInputLabel>
              <ProfileInputContainer>
                <ProfileDescriptionInput
                  id="info"
                  placeholder="Please Describe this profile here"
                  value={formData.info}
                  onChange={handleChange}
                />
                {infoError ? (
                  <ProfileInputError>This field is required*</ProfileInputError>
                ) : null}
              </ProfileInputContainer>
              {/*<ProfileRows>*/}
              {/*    <PasswordInfo>All fields required*</PasswordInfo>*/}
              {/*</ProfileRows>*/}
            </ProfileBodyRight>
          </ProfileBody>
        </AvatarProfileContainer>
        <PermissionsContainer>
          <PermissionsHeadingContainer>
            <PermissionsHeading>Permissions</PermissionsHeading>
          </PermissionsHeadingContainer>
          <PermissionsBody>
            <Permissions>
              <PermissionsCheckbox
                type="checkbox"
                checked={permitOrders}
                onClick={addOrdersPermission}
              />
              <PermissionName>Orders</PermissionName>
            </Permissions>
            <Permissions>
              <PermissionsCheckbox
                type="checkbox"
                checked={permitSupport}
                onClick={addSupportPermission}
              />
              <PermissionName>Support</PermissionName>
            </Permissions>
            <Permissions>
              <PermissionsCheckbox
                type="checkbox"
                checked={permitApprovals}
                onClick={addApprovalPermission}
              />
              <PermissionName>Approvals</PermissionName>
            </Permissions>
            <Permissions>
              <PermissionsCheckbox
                type="checkbox"
                checked={permitUsers}
                onClick={addUsersPermission}
              />
              <PermissionName>Users</PermissionName>
            </Permissions>
          </PermissionsBody>
        </PermissionsContainer>
        <CreateProfileButton onClick={submitForm}>
          Update Profile
        </CreateProfileButton>
      </Container>
      <DashboardFooter />
    </>
  );
}
