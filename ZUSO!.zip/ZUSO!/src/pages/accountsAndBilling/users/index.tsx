import { useEffect, useState } from "react";
import DashboardFooter from "@/components/dashboardFooter";
import {
  Container,
  SortIcon,
  TableDefinitionLast,
  TableDefinitions,
  TableHeaders,
  TableHeadersContainer,
  TableHeadersLast,
  TableHeading,
  TableRows,
  UserDesignation,
  UserEmail,
  UserName,
  UserPermissions,
  UserTable,
  UserTableContainer,
  MenuRow,
  MenuIcon,
  MenuHeadingDelete,
  MenuHeadingUpdate,
  ModalContainer,
  ModalImageContainer,
  ModalImage,
  ModalHeading,
  ModalName,
  ModalSubHeading,
  ModalBottom,
  ModalConfirmButton,
  ModalConfirmButtonText,
  ModalCloseButton,
  ModalCloseButtonText,
} from "@/styledComponents/users";
import sortIcon from "../../../../public/Sort.svg";
import updateIcon from "../../../../public/update.svg";
import deleteIcon from "../../../../public/delete.svg";
import modalImage from "../../../../public/deleteModalImage.svg";
import Modal from "react-modal";
import { useRouter } from "next/router";
import CONSTANTS from "@/utils/constants";
import UserHeader from "@/components/accountsAndBilling/users/header";
import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";

interface IUsers {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  info: string;
  position: string;
  permissions: [];
}

export default function Users() {
  const [users, setUsers] = useState<IUsers[]>([]);
  const router = useRouter();

  const fetchUsers = () => {
    fetch(CONSTANTS.api + "users/list", {
      credentials: "include",
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    })
      .then((res) => res.json())
      .then((resJson) => {
        setUsers(resJson);
      });
  };

  useEffect(() => {
    if (users.length === 0) {
      fetchUsers();
    }
  }, []);

  // const [currentPage, setCurrentPage] = useState(1);
  // const [rowsPerPage, setRowsPerPage] = useState(5);
  //
  // // Logic for displaying current rows
  // const indexOfLastRow = currentPage * rowsPerPage;
  // const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  // const currentRows = users.slice(indexOfFirstRow, indexOfLastRow);
  //
  // // Logic for displaying page numbers
  // const pageNumbers = [];
  // for (let i = 1; i <= Math.ceil(users.length / rowsPerPage); i++) {
  //     pageNumbers.push(i);
  // }
  //
  // // Handle click on page number
  // const handleClick = (event: any) => {
  //     setCurrentPage(Number(event.target.key));
  // }
  //
  // // Handle change of rows per page
  // const handleChangeRowsPerPage = (event: any) => {
  //     setRowsPerPage(event.target.value);
  //     setCurrentPage(1); // Reset to first page
  // }
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(0);
  const [selectedUserName, setSelectedUserName] = useState("");

  const openModal = (event: any) => {
    setSelectedUser(event.currentTarget.id);
    users.forEach((user) => {
      if (user.id === event.currentTarget.id) {
        setSelectedUserName(user?.first_name + " " + user?.last_name);
      }
    });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const deleteUser = () => {
    fetch(CONSTANTS.api + "users/delete?id=" + selectedUser, {
      method: "POST",
      // credentials: 'include',
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    })
      .then((r) => r.json())
      .then((response) => {
        // console.log(response, ' <<<<')
        closeModal();
        fetchUsers();
        // router.push('/users')
      });
  };

  const editUser = (event: any) => {
    router.push("/accountsAndBilling/users/edit?id=" + event.currentTarget.id);
  };

  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <Container>
        <UserHeader />
        <UserTableContainer>
          <UserTable>
            <TableHeadersContainer>
              <TableHeaders>
                <TableHeading>NAME</TableHeading>
                <SortIcon src={sortIcon.src} alt="" />
              </TableHeaders>
              <TableHeaders>
                <TableHeading>EMAIL ADDRESS</TableHeading>
                <SortIcon src={sortIcon.src} alt="" />
              </TableHeaders>
              <TableHeaders>
                <TableHeading>PERMISSIONS</TableHeading>
                <SortIcon src={sortIcon.src} alt="" />
              </TableHeaders>
              <TableHeadersLast>
                <TableHeading>ACTIONS</TableHeading>
              </TableHeadersLast>
            </TableHeadersContainer>
            {users.map((user, index) => {
              return (
                <TableRows
                  backgroundColor={index % 2 === 0 ? "white" : "#F8FAFC"}
                  key={index}
                >
                  <TableDefinitions>
                    <UserName
                      href={"/accountsAndBilling/users/view?id=" + user.id}
                    >
                      {user.first_name} {user.last_name}
                    </UserName>
                    <UserDesignation>{user.position}</UserDesignation>
                  </TableDefinitions>
                  <TableDefinitions>
                    <UserEmail
                      href={"/accountsAndBilling/users/view?id=" + user.id}
                    >
                      {user.email}
                    </UserEmail>
                  </TableDefinitions>
                  <TableDefinitions>
                    <UserPermissions>
                      {user.permissions.map(
                        (permission, index) =>
                          permission +
                          (index + 1 == user.permissions.length ? "" : ", ")
                      )}
                    </UserPermissions>
                  </TableDefinitions>
                  <TableDefinitionLast>
                    {/*<OptionsIcon src={optionsIcon.src} alt=""/>*/}
                    <MenuRow id={String(user.id)} onClick={editUser}>
                      <MenuIcon src={updateIcon.src} alt="" />
                      <MenuHeadingUpdate>Update</MenuHeadingUpdate>
                    </MenuRow>
                    <hr />
                    <MenuRow id={String(user.id)} onClick={openModal}>
                      <MenuIcon src={deleteIcon.src} alt="" />
                      <MenuHeadingDelete>Delete</MenuHeadingDelete>
                    </MenuRow>
                    {/*<MenuContainer display={'flex'}>*/}
                    {/*    <MenuRow>*/}
                    {/*        <MenuIcon src={updateIcon.src} alt=""/>*/}
                    {/*        <MenuHeadingUpdate>Update</MenuHeadingUpdate>*/}
                    {/*    </MenuRow>*/}
                    {/*    <hr/>*/}
                    {/*    <MenuRow>*/}
                    {/*        <MenuIcon src={deleteIcon.src} alt=""/>*/}
                    {/*        <MenuHeadingDelete>Delete</MenuHeadingDelete>*/}
                    {/*    </MenuRow>*/}
                    {/*</MenuContainer>*/}
                  </TableDefinitionLast>
                </TableRows>
              );
            })}
          </UserTable>
        </UserTableContainer>
        <Modal
          isOpen={modalOpen}
          // onAfterOpen={afterOpenModal}
          onRequestClose={closeModal}
          style={CONSTANTS.modalStyles}
          contentLabel="Delete User"
          ariaHideApp={false}
        >
          <ModalContainer>
            <ModalImageContainer>
              <ModalImage src={modalImage.src} alt="" />
            </ModalImageContainer>
            <ModalHeading>You are about to delete this user:</ModalHeading>
            <ModalName>{selectedUserName}</ModalName>
            <ModalSubHeading>Are you sure you want to do this?</ModalSubHeading>
          </ModalContainer>
          <ModalBottom>
            <ModalConfirmButton onClick={deleteUser}>
              <ModalConfirmButtonText>Delete User</ModalConfirmButtonText>
            </ModalConfirmButton>
            <ModalCloseButton onClick={closeModal}>
              <ModalCloseButtonText>Cancel</ModalCloseButtonText>
            </ModalCloseButton>
          </ModalBottom>
        </Modal>
      </Container>
      <DashboardFooter />
    </>
  );
}
