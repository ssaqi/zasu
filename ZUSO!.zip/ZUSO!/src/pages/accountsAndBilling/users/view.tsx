import { useEffect, useState } from "react";
import DashboardFooter from "@/components/dashboardFooter";
import {
  Container,
  Header,
  MainHeading,
  MainHeadingHighlighted,
  MainHeadingMuted,
  DeleteUserButton,
  ProfileContainer,
  ProfileHeadingContainer,
  ProfileHeading,
  ProfileDetailsContainer,
  ProfileImageContainer,
  ProfileImage,
  ProfileDetails,
  PermissionsContainer,
  PermissionsHeadingContainer,
  PermissionsHeading,
  PermissionsBody,
  PermissionName,
  Permissions,
  PermissionsIcon,
  ProfileName,
  ProfileDesignation,
  ProfileIcons,
  ProfileEmail,
  ProfileIconsContainer,
  ProfilePhone,
  ProfileInfoHeading,
  ProfileDescription,
  ModalContainer,
  ModalImageContainer,
  ModalImage,
  ModalHeading,
  ModalName,
  ModalSubHeading,
  ModalBottom,
  ModalConfirmButtonText,
  ModalCloseButton,
  ModalCloseButtonText,
  ModalConfirmButton,
} from "@/styledComponents/users";
import greenTickIcon from "../../../../public/Bulletbg.svg";
import defaultProfileImage from "../../../../public/ProfileDefault.svg";
import emailIcon from "../../../../public/EmailIcon.svg";
import phoneIcon from "../../../../public/PhoneIcon.svg";
import Modal from "react-modal";
import modalImage from "../../../../public/deleteModalImage.svg";
import { useRouter } from "next/router";
import CONSTANTS from "@/utils/constants";
import MainNavigation from "@/components/navigation";
import UserSearchBar from "@/components/accountsAndBilling/users/searchBar";

export default function UserView() {
  const router = useRouter();
  const { id } = router.query;

  const [user, setUser] = useState<any>(null);
  const [permissions, setPermissions] = useState([]);

  // const [userInfo, setUserInfo] = useState(
  //     {
  //         id: 1,
  //         name: "Micheal Fassbender",
  //         designation: 'Account Owner',
  //         email: 'john.fassbender@willametterdetail.com',
  //         phone: '(503) 456-873',
  //         info: 'Vestibulum tristique ultricies sem, nec molestie ante aliquet vitae. Sed nec cursus purus. Praesent finibus neque eu nunc fringilla hendrerit. Quisque interdum laoreet arcu sed viverra. Aliquam erat volutpat. Nulla id orci eu est consequat efficitur tristique ac est. Curabitur porta eleifend ex, a aliquet risus dapibus in.',
  //         permissions: 'Approvals, Users, Order, Support',
  //     }
  // );

  useEffect(() => {
    if (id !== undefined) {
      if (user === null) {
        fetch(CONSTANTS.api + "users/id/" + id, {
          method: "GET",
          // credentials: 'include',
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
          .then((r) => r.json())
          .then((response) => {
            console.log(response, " <<<<");
            setUser(response);
            setPermissions(response.permissions);
          });
      }
    }
  }, [id]);

  const [modalOpen, setModalOpen] = useState(false);

  const openModal = () => {
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const deleteUser = () => {
    fetch(CONSTANTS.api + "users/delete?id=" + id, {
      method: "POST",
      // credentials: 'include',
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    })
      .then((r) => r.json())
      .then((response) => {
        console.log(response, " <<<<");
        alert("user deleted.");
        router.push("/accountsAndBilling/users");
      });
  };

  // @ts-ignore
  return (
    <>
      <MainNavigation />
      <UserSearchBar />
      <Container>
        {user !== null ? (
          <>
            <Header>
              <MainHeading>
                <MainHeadingHighlighted href="/users">
                  Users{" "}
                </MainHeadingHighlighted>
                <MainHeadingMuted>/</MainHeadingMuted> {user.first_name}
              </MainHeading>
              <DeleteUserButton onClick={openModal}>
                Delete User
              </DeleteUserButton>
            </Header>
            <ProfileContainer>
              <ProfileHeadingContainer>
                <ProfileHeading>Profile</ProfileHeading>
              </ProfileHeadingContainer>
              <ProfileDetailsContainer>
                <ProfileImageContainer>
                  <ProfileImage src={defaultProfileImage.src} alt="" />
                </ProfileImageContainer>
                <ProfileDetails>
                  <ProfileName>
                    {user.first_name} {user.last_name}
                  </ProfileName>
                  <ProfileDesignation>{user.position}</ProfileDesignation>
                  <ProfileIconsContainer>
                    <ProfileIcons src={emailIcon.src} alt="" />
                    <ProfileEmail>{user.email}</ProfileEmail>
                  </ProfileIconsContainer>
                  <ProfileIconsContainer>
                    <ProfileIcons src={phoneIcon.src} alt="" />
                    <ProfilePhone>{user.phone_number}</ProfilePhone>
                  </ProfileIconsContainer>
                  <ProfileInfoHeading>Profile Info</ProfileInfoHeading>
                  <ProfileDescription>{user.info}</ProfileDescription>
                </ProfileDetails>
              </ProfileDetailsContainer>
            </ProfileContainer>
            <PermissionsContainer>
              <PermissionsHeadingContainer>
                <PermissionsHeading>Permissions</PermissionsHeading>
              </PermissionsHeadingContainer>
              <PermissionsBody>
                {permissions !== undefined ? (
                  <>
                    {permissions.map((permission, index) => {
                      return (
                        <Permissions key={index}>
                          <PermissionsIcon src={greenTickIcon.src} />
                          <PermissionName>{permission}</PermissionName>
                        </Permissions>
                      );
                    })}
                  </>
                ) : null}
              </PermissionsBody>
            </PermissionsContainer>
          </>
        ) : null}
        <Modal
          isOpen={modalOpen}
          // onAfterOpen={afterOpenModal}
          onRequestClose={closeModal}
          style={CONSTANTS.modalStyles}
          contentLabel="Delete User"
          ariaHideApp={false}
        >
          <ModalContainer>
            <ModalImageContainer>
              <ModalImage src={modalImage.src} alt="" />
            </ModalImageContainer>
            <ModalHeading>You are about to delete this user:</ModalHeading>
            <ModalName>
              {user !== null ? user.first_name + " " + user.last_name : ""}
            </ModalName>
            <ModalSubHeading>Are you sure you want to do this?</ModalSubHeading>
          </ModalContainer>
          <ModalBottom>
            <ModalConfirmButton onClick={deleteUser}>
              <ModalConfirmButtonText>Delete User</ModalConfirmButtonText>
            </ModalConfirmButton>
            <ModalCloseButton onClick={closeModal}>
              <ModalCloseButtonText>Cancel</ModalCloseButtonText>
            </ModalCloseButton>
          </ModalBottom>
        </Modal>
      </Container>
      <DashboardFooter />
    </>
  );
}
