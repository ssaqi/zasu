import * as React from "react";
import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import DashboardFooter from "@/components/dashboardFooter";
import EditAccount from "@/components/accountsAndBilling/editAccount";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { getUserAccountDetails } from "@/store/accountSlice";

export default function EditAccountPage() {
  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <EditAccount />
      <DashboardFooter />
    </>
  );
}
