import DashboardFooter from "@/components/dashboardFooter";
import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import { useDispatch } from "react-redux";
import AccountAndBilling from "@/components/accountsAndBilling";
import { useEffect } from "react";
import { getUserAccountDetails } from "../../store/accountSlice";
import { useUser } from "@/lib/hooks";

export default function AccountsAndBilling() {
  const dispatch = useDispatch();
  useUser({ redirectTo: "/accountsAndBilling", redirectIfFound: true });

  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <AccountAndBilling />
      <DashboardFooter />
    </>
  );
}
