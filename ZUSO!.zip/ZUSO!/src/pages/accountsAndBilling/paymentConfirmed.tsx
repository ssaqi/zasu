import DashboardFooter from "@/components/dashboardFooter";
import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import Link from "next/link";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import Heading from "@/components/accountsAndBilling/heading";
import { Container } from "@/components/accountsAndBilling/choosePlan";

export default function PracticePreferencesPage() {
  const [_isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (isMobile) {
      setIsMobile(true);
    }
  }, []);

  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <Container>
        <Heading />
        <main className="flex flex-col w-full flex-1 gap-10">
          <div className="flex flex-col h-3/4 mt-15 justify-center items-center mb-20 p-3">
            <div
              className={`flex ${
                _isMobile ? "w-full" : "w-2/3"
              } flex-col bg-white rounded-t-md p-4 justify-center items-center`}
            >
              <div className="w-[220px] h-[220px]">
                <img src="/confirmation.png" alt="" />
              </div>
              <span className="text-2xl font-semibold text-zuso-dark-blue-2 mb-4">
                Contratulations!
              </span>
              <span className="text-s text-center text-zuso-gray-2 mb-4">
                Your ZuSo Subscription plan was updated successfully.
              </span>
            </div>
            <div
              className={`flex ${
                _isMobile ? "w-full" : "w-2/3"
              } flex-col bg-zuso-gray rounded-b-md p-6 justify-center items-center`}
            >
              <div className="col-span-2">
                <Link href="/accountsAndBilling" passHref legacyBehavior>
                  <input
                    type="button"
                    className="rounded-sm w-full text-white text-sm text-bold hover:bg-zuso-btn-pressed hover:cursor-pointer bg-zuso-dark-blue-2 py-1.5 px-14"
                    value="Go back to Accounts & Billing page"
                  />
                </Link>
              </div>
            </div>
          </div>
        </main>
      </Container>
      <DashboardFooter />
    </>
  );
}
