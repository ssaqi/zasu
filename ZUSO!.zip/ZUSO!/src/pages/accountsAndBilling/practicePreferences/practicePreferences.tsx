import Heading from '@/pages/accountsAndBilling/practicePreferences/heading';
import {
    AccountInfoAddress,
    AccountInfoBody,
    AccountInfoContainer,
    AccountInfoHeading,
    AccountInfoHeadingContainer,
    AccountInfoTopHeading,
    Container,
    FirstRow,
    FirstRowLeft,
    FirstRowRight,
    Headings,
    Row,
    SaveButton,
    SecondRow,
    SecondRowLeft,
    SecondRowRight,
    SupplierAccountsTable,
    SupplierAccountTableHeadings,
    AccountInfoButtons,
    BottomRow,
    Icon,
    SupplierAccountsTableRows,
    SupplierAccountsTableDefinitions,
    SaveButtonContainer
} from '@/styledComponents/practicePreferences/practicePreferences';
import * as React from 'react';
import {useEffect, useState} from 'react';
import {get, post} from '@/utils/fetch';
import {useRouter} from 'next/router';
import editIcon from '../../../../public/editBlue.svg'
import Select from 'react-select'
import SupplierAccounts from '@/pages/accountsAndBilling/practicePreferences/supplierAccounts';
import {useDispatch, useSelector} from 'react-redux';
import {
    suppliersList,
    updateSelectedSuppliers,
    uploadSupplierAccounts
} from '@/store/supplierPreferenceSlice';
import CONSTANTS from '@/utils/constants';

export default function PracticePreferences() {

    const router = useRouter()
    const dispatch = useDispatch()
    const allSuppliers = useSelector(suppliersList)
    const [primaryDistributor, setPrimaryDistributor] = useState('')
    const [secondaryDistributor, setSecondaryDistributor] = useState('')
    const [additionalDistributors, setAdditionalDistributors] = useState<string[]>([])
    const [additionalDistributorsValue, setAdditionalDistributorsValue] = useState<{ value: ''; label: ''; }[]>([])
    const [suppliers, setSuppliers] = useState<any>([])
    const [selectedSuppliers, setSelectedSuppliers] = useState([])
    const [supplierValues, setSupplierValues] = useState<{ value: ''; label: ''; }[]>([])

    const [billingAddressForm, setBillingAddressForm] = useState({
        streetLineOne: '',
        streetLineTwo: '',
        streetLineThree: '',
        useAsShippingAddress: false,
    });

    const [shippingAddressForm, setShippingAddressForm] = useState({
        streetLineOne: '',
        streetLineTwo: '',
        streetLineThree: '',
    });

    useEffect(() => {
        setSuppliers(allSuppliers)
    }, [allSuppliers])

    const gotoAddressPage = () => {
        router.push('/accountsAndBilling/practicePreferences/address')
    }

    useEffect(() => {
        get('users/companyAddress?type=BILLING')
            .then((res: any) => {
                if (res.success) {
                    setBillingAddressForm(
                        {
                            ...billingAddressForm,
                            ['streetLineOne']: res.streetOne,
                            ['streetLineTwo']: res.streetTwo,
                            ['streetLineThree']: res.streetThree,
                            ['useAsShippingAddress']: res.useAsShippingAddress,
                        }
                    )
                }
            })
    }, [])

    useEffect(() => {
        get('users/companyAddress?type=SHIPPING')
            .then((res: any) => {
                if (res.success) {
                    setShippingAddressForm(
                        {
                            ...shippingAddressForm,
                            ['streetLineOne']: res.streetOne,
                            ['streetLineTwo']: res.streetTwo,
                            ['streetLineThree']: res.streetThree,
                        }
                    )
                }
            })
    }, [])

    const selectPrimaryDistributor = (event: any) => {
        if (event.value === secondaryDistributor) {
            alert('Already Selected as Secondary!')
            return
        }
        let selectedAsAdditional = false
        additionalDistributors.forEach(distributor => {
            if (distributor === event.value) {
                selectedAsAdditional = true
                return
            }
        })
        let selectedAsDirect = false
        // @ts-ignore
        selectedSuppliers.forEach(selectedSupplier => {
            if (selectedSupplier === event.value) {
                selectedAsDirect = true
                return
            }
        })
        if (selectedAsAdditional) {
            alert('Already Selected as Additional!')
            return
        }
        if (selectedAsDirect) {
            alert('Already Selected as Direct!')
            return
        }
        setPrimaryDistributor(event.value)
    }

    const checkSupplierAccount = async (name: string) => {
        const request = await fetch(CONSTANTS.api + 'users/supplierAccounts/get?name=' + name, {
            method: 'GET',
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('token')
            }
        })
        const response = await request.json()
        if (response.success) {
            return {
                name: name,
                accountNumber: response.accountNumber,
                username: response.username,
                password: response.password,
            }
        } else {
            return {
                name: name,
                accountNumber: '',
                username: '',
                password: '',
            }
        }
    }

    const getSupplierAccounts = async () => {
        let suppliers = []
        if (primaryDistributor !== '') {
            const primarySupplierDetails = await checkSupplierAccount(primaryDistributor)
            suppliers.push(primarySupplierDetails)
        }
        if (secondaryDistributor !== '') {
            const secondarySupplierDetails = await checkSupplierAccount(secondaryDistributor)
            suppliers.push(secondarySupplierDetails)
        }
        for (const distributor of additionalDistributors) {
            const distributorDetails = await checkSupplierAccount(distributor)
            suppliers.push(distributorDetails)
        }
        for (const distributor of selectedSuppliers) {
            const supplierDetails = await checkSupplierAccount(distributor)
            suppliers.push(supplierDetails)
        }
        dispatch(
            // @ts-ignore
            updateSelectedSuppliers(suppliers)
        )
    }

    useEffect(() => {
        getSupplierAccounts().then(r => console.log(r))
    }, [primaryDistributor, secondaryDistributor, additionalDistributors, selectedSuppliers])

    const selectSecondaryDistributor = (event: any) => {
        if (event.value === primaryDistributor) {
            alert('Already Selected as Primary!')
            return
        }
        let selectedAsAdditional = false
        additionalDistributors.forEach(distributor => {
            if (distributor === event.value) {
                selectedAsAdditional = true
                return
            }
        })
        let selectedAsDirect = false
        // @ts-ignore
        selectedSuppliers.forEach(selectedSupplier => {
            if (selectedSupplier === event.value) {
                selectedAsDirect = true
                return
            }
        })
        if (selectedAsAdditional) {
            alert('Already Selected as Additional!')
            return
        }
        if (selectedAsDirect) {
            alert('Already Selected as Direct!')
            return
        }
        setSecondaryDistributor(event.value)
    }

    const selectAdditionalDistributors = (event: any) => {
        const additionals: string[] = []
        event.forEach((additionalDist: any) => {
            additionals.push(additionalDist.value)
        })
        setAdditionalDistributors(additionals)
    }

    const selectDirectSuppliers = (event: any) => {
        const _suppliers: string[] = []
        event.forEach((supplier: any) => {
            _suppliers.push(supplier.value)
        })
        // @ts-ignore
        setSelectedSuppliers(_suppliers)
    }

    const saveDistributorPreferences = () => {
        const body = {
            primaryDistributor: primaryDistributor,
            secondaryDistributor: secondaryDistributor,
            additionalDistributors: additionalDistributors
        }
        post('users/distributorPreferences/update', body)
            .then((res: any) => {
                // console.log(res, ' <<<<<<< here')
                if (res.success) {
                    updateSupplierPreferences()
                } else {
                    alert('Something went wrong, Please try again later.')
                }
            })
    }

    const updateSupplierPreferences = () => {
        const body = {
            suppliers: selectedSuppliers,
        }
        post('users/supplierPreferences/update', body)
            .then((res: any) => {
                // console.log(res, ' <<<<<<< here')
                if (res.success) {
                    alert('Preferences updated.')
                } else {
                    alert('Something went wrong, Please try again later.')
                }
            })
    }

    useEffect(() => {
        get('users/distributorPreferences/list')
            .then((res: any) => {
                // console.log(res, ' <<<<<<<<<< res ')
                if (res.success) {
                    setPrimaryDistributor(res?.primary)
                    setSecondaryDistributor(res?.secondary)
                    setAdditionalDistributors(res?.additional)
                }
            })
    }, [])

    useEffect(() => {
        get('users/supplierPreferences/list')
            .then((res: any) => {
                if (res.success) {
                    setSelectedSuppliers(res.suppliers)
                }
            })
    }, [])

    useEffect(() => {
        const _suppliers: ((prevState: never[]) => never[]) | { value: any; label: any; }[] = []
        selectedSuppliers.forEach((supplier: any) => {
            _suppliers.push({value: supplier, label: supplier})
        })
        setSupplierValues(_suppliers)
    }, [selectedSuppliers])

    useEffect(() => {
        const distributors: ((prevState: never[]) => never[]) | { value: any; label: any; }[] = []
        additionalDistributors.forEach((distributor: any) => {
            distributors.push({value: distributor, label: distributor})
        })
        setAdditionalDistributorsValue(distributors)
    }, [additionalDistributors])

    const addSupplierAccounts = () => {
        // @ts-ignore
        dispatch(uploadSupplierAccounts(true))
    }

    return (
        <Container>
            <Heading/>
            <FirstRow>
                <FirstRowLeft>
                    <AccountInfoTopHeading>Distributors/Direct Suppliers Information</AccountInfoTopHeading>
                    <AccountInfoContainer>
                        <AccountInfoHeadingContainer>
                            <AccountInfoHeading>BEST EXPERIENCE IF YOU SELECT ALL RELEVANT SUPPLIERS THAT YOU WORK
                                WITH</AccountInfoHeading>
                        </AccountInfoHeadingContainer>
                        <AccountInfoBody>
                            <Row>
                                <Headings>Select Primary Distributor *</Headings>
                                <Select options={suppliers} onChange={selectPrimaryDistributor}
                                        value={{value: primaryDistributor, label: primaryDistributor}}/>
                            </Row>
                            <Row>
                                <Headings>Select Secondary Distributor</Headings>
                                <Select options={suppliers} onChange={selectSecondaryDistributor}
                                        value={{value: secondaryDistributor, label: secondaryDistributor}}/>
                            </Row>
                            <Row>
                                <Headings>Select Additional Distributors</Headings>
                                <Select
                                    options={suppliers.filter((supp: any) => supp.value !== primaryDistributor && supp.value !== secondaryDistributor)}
                                    isMulti={true} value={additionalDistributorsValue}
                                    onChange={selectAdditionalDistributors}/>
                            </Row>
                            <Row>
                                <Headings>Select Direct Suppliers</Headings>
                                <Select
                                    options={suppliers.filter((supp: any) => supp.value !== primaryDistributor && supp.value !== secondaryDistributor)}
                                    isMulti={true} value={supplierValues}
                                    onChange={selectDirectSuppliers}/>
                            </Row>
                            <SaveButton onClick={saveDistributorPreferences}>Save Distributor
                                Preferences</SaveButton>
                        </AccountInfoBody>
                    </AccountInfoContainer>
                </FirstRowLeft>
                <FirstRowRight>
                    <AccountInfoTopHeading>Supplier Account & Login</AccountInfoTopHeading>
                    <SupplierAccountsTable>
                        <SupplierAccountsTableRows backgroundColor={'#F8FAFC'}>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountTableHeadings>SUPPLIER NAME</SupplierAccountTableHeadings>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountTableHeadings>SUPPLIER ACCOUNT NUMBER</SupplierAccountTableHeadings>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountTableHeadings>SUPPLIER SITE USERNAME</SupplierAccountTableHeadings>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountTableHeadings>SUPPLIER SITE PASSWORD</SupplierAccountTableHeadings>
                            </SupplierAccountsTableDefinitions>
                        </SupplierAccountsTableRows>
                        <SupplierAccounts/>
                    </SupplierAccountsTable>
                    <SaveButtonContainer>
                        <SaveButton onClick={addSupplierAccounts}>Save Supplier Accounts</SaveButton>
                    </SaveButtonContainer>
                </FirstRowRight>
            </FirstRow>
            <SecondRow>
                <SecondRowLeft>
                    <AccountInfoTopHeading>Office Address</AccountInfoTopHeading>
                    <AccountInfoContainer>
                        <AccountInfoHeadingContainer>
                            <AccountInfoHeading>DEFAULT BILLING ADDRESS</AccountInfoHeading>
                        </AccountInfoHeadingContainer>
                        <AccountInfoBody>
                            <AccountInfoAddress>{billingAddressForm.streetLineOne}</AccountInfoAddress>
                            <AccountInfoAddress>{billingAddressForm.streetLineTwo}</AccountInfoAddress>
                            <AccountInfoAddress>{billingAddressForm.streetLineThree}</AccountInfoAddress>
                            <BottomRow>
                                <Icon src={editIcon.src} alt=""/>
                                <AccountInfoButtons onClick={gotoAddressPage}>Edit Address</AccountInfoButtons>
                            </BottomRow>
                        </AccountInfoBody>
                    </AccountInfoContainer>
                </SecondRowLeft>
                <SecondRowRight>
                    <AccountInfoContainer>
                        <AccountInfoHeadingContainer>
                            <AccountInfoHeading>DEFAULT SHIPPING ADDRESS</AccountInfoHeading>
                        </AccountInfoHeadingContainer>
                        <AccountInfoBody>
                            {
                                billingAddressForm.useAsShippingAddress ?
                                    <>
                                        <AccountInfoAddress>{billingAddressForm.streetLineOne}</AccountInfoAddress>
                                        <AccountInfoAddress>{billingAddressForm.streetLineTwo}</AccountInfoAddress>
                                        <AccountInfoAddress>{billingAddressForm.streetLineThree}</AccountInfoAddress>
                                    </> :
                                    <>
                                        <AccountInfoAddress>{shippingAddressForm.streetLineOne}</AccountInfoAddress>
                                        <AccountInfoAddress>{shippingAddressForm.streetLineTwo}</AccountInfoAddress>
                                        <AccountInfoAddress>{shippingAddressForm.streetLineThree}</AccountInfoAddress>
                                    </>
                            }
                            <BottomRow>
                                <Icon src={editIcon.src} alt=""/>
                                <AccountInfoButtons onClick={gotoAddressPage}>Edit Address</AccountInfoButtons>
                            </BottomRow>
                        </AccountInfoBody>
                    </AccountInfoContainer>
                </SecondRowRight>
            </SecondRow>
        </Container>
    )
}
