import * as React from 'react';
import {
    SupplierAccountInput,
    SupplierAccountNames,
    SupplierAccountsTableDefinitions,
    SupplierAccountsTableRows
} from '@/styledComponents/practicePreferences/practicePreferences';
import {useDispatch, useSelector} from 'react-redux';
import {
    getSupplierAccounts,
    selectedSuppliersList,
    supplierAccountsList,
    updateSupplierAccounts, updateSupplierAccountValue,
    uploadSupplierAccounts
} from '@/store/supplierPreferenceSlice';
import {useEffect, useState} from 'react';
import {post} from '@/utils/fetch';

interface ISupplierAccount {
    // bg: string,
    // name: string,
}

const SupplierAccounts: React.FC<ISupplierAccount> = (
    // {bg, name}
) => {
    const selectedSuppliers = useSelector(selectedSuppliersList)
    const updateAccounts = useSelector(updateSupplierAccounts)
    const dispatch = useDispatch()

    useEffect(() => {
        if (selectedSuppliers.length < 1) {
            // @ts-ignore
            dispatch(getSupplierAccounts())
        }
    })

    const update = () => {
        const body = {
            supplierAccounts: selectedSuppliers
        }
        post('users/supplierAccounts/update', body)
            .then((res: any) => {
                alert('Supplier Accounts updated')
            })
            .catch(() => {
                alert('Something went wrong! Please try again later.')
            })
    }

    useEffect(() => {
        if (updateAccounts) {
            update()
            // @ts-ignore
            dispatch(uploadSupplierAccounts(false))
        }
    }, [updateAccounts])

    const valueChangeOnInput = (event: any) => {
        // @ts-ignore
        dispatch(updateSupplierAccountValue({id: event.target.id, valueName: event.target.name, value: event.target.value}))
    }

    return (
        <>
            {
                selectedSuppliers.map((supplier, index) => {
                    return (
                        <SupplierAccountsTableRows backgroundColor={index % 2 === 0 ? 'white' : '#E5E5E5'} key={index}>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountNames>{supplier.name}</SupplierAccountNames>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountInput id={supplier.name} title={supplier.name} type='number' value={supplier.accountNumber}
                                                      name='accountNumber' onInput={valueChangeOnInput}
                                                      placeholder="Enter Account Number"/>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountInput id={supplier.name} type='text' name='username' title={supplier.name}
                                                      value={supplier.username} onInput={valueChangeOnInput}
                                                      placeholder="Enter Login username/email"/>
                            </SupplierAccountsTableDefinitions>
                            <SupplierAccountsTableDefinitions>
                                <SupplierAccountInput id={supplier.name} type='password' name='password' title={supplier.name}
                                                      value={supplier.password} onInput={valueChangeOnInput}
                                                      placeholder="Enter Login Password"/>
                            </SupplierAccountsTableDefinitions>
                        </SupplierAccountsTableRows>
                    )
                })
            }
        </>
    )
}

export default SupplierAccounts
