import * as React from 'react';
import {
    Header,
    MainHeading,
} from '@/styledComponents/accountsAndBilling/editAccount';

export default function Heading() {

    return (
        <Header>
            <MainHeading>
                Practice Preferences
            </MainHeading>
        </Header>
    )
}
