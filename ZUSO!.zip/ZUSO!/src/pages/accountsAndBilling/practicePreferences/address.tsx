import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import DashboardFooter from "@/components/dashboardFooter";
import Heading from "@/pages/accountsAndBilling/practicePreferences/heading";
import {
  AccountInfoBody,
  AccountInfoContainer,
  AccountInfoHeading,
  AccountInfoHeadingContainer,
  AccountInfoTopHeading,
  AvatarBody,
  Select,
  AvatarBodyWrapper,
  AvatarImage,
  AvatarImageIcon,
  AvatarInput,
  AvatarTitle,
  ClickHereSpan,
  Container,
  FirstRow,
  FirstRowLeft,
  FirstRowRight,
  ProfileDescriptionInput,
  ProfileInput,
  ProfileInputContainer,
  ProfileInputError,
  ProfileInputLabel,
  ProfileRows,
  UpdateAddressCheckbox,
  CheckboxLabel,
} from "@/styledComponents/practicePreferences/editAddress";
import * as React from "react";
import { useEffect, useState } from "react";
import { States } from "@/components/states";
import { Countries } from "@/components/countries";
import { AddUserButton, Header, MainHeading } from "@/styledComponents/users";
import { get, post } from "@/utils/fetch";
import { useRouter } from "next/router";

export default function PracticePreferencesAddress() {
  const router = useRouter();
  const [useAsShippingAddress, setUseAsShippingAddress] = useState(false);
  const [streetError, setStreetError] = useState(false);
  const [countryError, setCountryError] = useState(false);
  const [phoneNumberError, setPhoneNumberError] = useState(false);
  const [cityError, setCityError] = useState(false);
  const [stateError, setStateError] = useState(false);
  const [zipError, setZipError] = useState(false);

  const [billingAddressForm, setBillingAddressForm] = useState({
    fullName: "",
    streetLineOne: "",
    streetLineTwo: "",
    streetLineThree: "",
    country: "United States",
    phoneNumber: "",
    city: "",
    state: "Alabama",
    zipCode: "",
    useAsShippingAddress: false,
    type: "BILLING",
  });

  const [shippingAddressForm, setShippingAddressForm] = useState({
    fullName: "",
    streetLineOne: "",
    streetLineTwo: "",
    streetLineThree: "",
    country: "United States",
    phoneNumber: "",
    city: "",
    state: "Alabama",
    zipCode: "",
    type: "SHIPPING",
  });

  useEffect(() => {
    setBillingAddressForm({
      ...billingAddressForm,
      ["useAsShippingAddress"]: useAsShippingAddress,
    });
  }, [useAsShippingAddress]);

  const toggleUseAsShippingAddress = () => {
    setUseAsShippingAddress(!useAsShippingAddress);
  };

  const handleShippingAddressInfoChange = (e: any): void => {
    setShippingAddressForm({
      ...shippingAddressForm,
      [e.target.id]: e.target.value,
    });
  };

  const handleBillingAddressInfoChange = (e: any): void => {
    setBillingAddressForm({
      ...billingAddressForm,
      [e.target.id]: e.target.value,
    });
  };

  const updateBillingAddress = () => {
    post("users/createAddress", billingAddressForm).then((res: any) => {
      if (res.success) {
        alert("Billing Address updated successfully");
      } else {
        alert("Please ask owner to change the address!");
      }
    });
  };

  const updateShippingAddress = () => {
    post("users/createAddress", shippingAddressForm).then((res: any) => {
      if (res.success) {
        alert("Shipping Address updated successfully");
      } else {
        alert("Please ask owner to change the address!");
      }
    });
  };

  useEffect(() => {
    get("users/companyAddress?type=BILLING").then((res: any) => {
      if (res.success) {
        setUseAsShippingAddress(res.useAsShipping);
        setBillingAddressForm({
          ...billingAddressForm,
          ["fullName"]: res.fullName,
          ["streetLineOne"]: res.streetOne,
          ["streetLineTwo"]: res.streetTwo,
          ["streetLineThree"]: res.streetThree,
          ["country"]: res.country,
          ["phoneNumber"]: res.phoneNumber,
          ["city"]: res.city,
          ["state"]: res.state,
          ["zipCode"]: res.zip,
          ["useAsShippingAddress"]: res.useAsShippingAddress,
        });
      }
    });
  }, []);

  useEffect(() => {
    get("users/companyAddress?type=SHIPPING").then((res: any) => {
      if (res.success) {
        setShippingAddressForm({
          ...shippingAddressForm,
          ["fullName"]: res.fullName,
          ["streetLineOne"]: res.streetOne,
          ["streetLineTwo"]: res.streetTwo,
          ["streetLineThree"]: res.streetThree,
          ["country"]: res.country,
          ["phoneNumber"]: res.phoneNumber,
          ["city"]: res.city,
          ["state"]: res.state,
          ["zipCode"]: res.zip,
        });
      }
    });
  }, []);

  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <Container>
        <Heading />
        <Header>
          <AccountInfoTopHeading>Edit Billing Address</AccountInfoTopHeading>
          <AddUserButton onClick={updateBillingAddress}>
            Save Billing Address
          </AddUserButton>
        </Header>
        <AccountInfoContainer>
          <AccountInfoHeadingContainer>
            <AccountInfoHeading>OFFICE BILLING ADDRESS</AccountInfoHeading>
            <UpdateAddressCheckbox
              type="checkbox"
              onClick={toggleUseAsShippingAddress}
              defaultChecked={useAsShippingAddress}
            />
            <CheckboxLabel>Use as shipping address</CheckboxLabel>
          </AccountInfoHeadingContainer>
          <AccountInfoBody>
            <FirstRowLeft>
              <ProfileRows>
                <ProfileInputLabel>Full Name</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="fullName"
                    type="text"
                    placeholder="First name Last name"
                    value={billingAddressForm.fullName}
                    onInput={handleBillingAddressInfoChange}
                  />
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  Street Address <span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="streetLineOne"
                    type="text"
                    placeholder="123 Office Street, Suite # 300"
                    value={billingAddressForm.streetLineOne}
                    onInput={handleBillingAddressInfoChange}
                  />
                  <ProfileInput
                    id="streetLineTwo"
                    type="text"
                    placeholder="My dental Office Name (Optional)"
                    value={billingAddressForm.streetLineTwo}
                    onInput={handleBillingAddressInfoChange}
                  />
                  <ProfileInput
                    id="streetLineThree"
                    type="text"
                    placeholder=""
                    value={billingAddressForm.streetLineThree}
                    onInput={handleBillingAddressInfoChange}
                  />
                  {streetError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  Country <span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <Select
                  id="country"
                  value={billingAddressForm.country}
                  onInput={handleBillingAddressInfoChange}
                  className="rounded-sm w-full"
                >
                  <Countries />
                </Select>
              </ProfileRows>
            </FirstRowLeft>
            <FirstRowRight>
              <ProfileRows>
                <ProfileInputLabel>Phone Number</ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="phoneNumber"
                    type="number"
                    placeholder="Enter Phone Number"
                    value={billingAddressForm.phoneNumber}
                    onInput={handleBillingAddressInfoChange}
                  />
                  {phoneNumberError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  City <span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="city"
                    placeholder="Enter City"
                    value={billingAddressForm.city}
                    onInput={handleBillingAddressInfoChange}
                  />
                  {cityError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  State / Province
                  <span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <select
                    id="state"
                    onInput={handleBillingAddressInfoChange}
                    value={billingAddressForm.state}
                    className="rounded-sm w-full"
                  >
                    <States />
                  </select>
                </ProfileInputContainer>
              </ProfileRows>
              <ProfileRows>
                <ProfileInputLabel>
                  Zip / Postal Code <span style={{ color: "red" }}>*</span>
                </ProfileInputLabel>
                <ProfileInputContainer>
                  <ProfileInput
                    id="zipCode"
                    placeholder="Enter Postal Code"
                    value={billingAddressForm.zipCode}
                    onInput={handleBillingAddressInfoChange}
                  />
                  {zipError ? (
                    <ProfileInputError>
                      This field is required*
                    </ProfileInputError>
                  ) : null}
                </ProfileInputContainer>
              </ProfileRows>
            </FirstRowRight>
          </AccountInfoBody>
        </AccountInfoContainer>
        {!useAsShippingAddress ? (
          <>
            <Header style={{ marginTop: "20px" }}>
              <AccountInfoTopHeading>
                Edit Shipping Address
              </AccountInfoTopHeading>
              <AddUserButton onClick={updateShippingAddress}>
                Save Shipping Address
              </AddUserButton>
            </Header>
            <AccountInfoContainer>
              <AccountInfoHeadingContainer>
                <AccountInfoHeading>OFFICE SHIPPING ADDRESS</AccountInfoHeading>
              </AccountInfoHeadingContainer>
              <AccountInfoBody>
                <FirstRowLeft>
                  <ProfileRows>
                    <ProfileInputLabel>Full Name</ProfileInputLabel>
                    <ProfileInputContainer>
                      <ProfileInput
                        id="fullName"
                        type="text"
                        placeholder="First name Last name"
                        value={shippingAddressForm.fullName}
                        onInput={handleShippingAddressInfoChange}
                      />
                    </ProfileInputContainer>
                  </ProfileRows>
                  <ProfileRows>
                    <ProfileInputLabel>
                      Street Address <span style={{ color: "red" }}>*</span>
                    </ProfileInputLabel>
                    <ProfileInputContainer>
                      <ProfileInput
                        id="streetLineOne"
                        type="text"
                        placeholder="123 Office Street, Suite # 300"
                        value={shippingAddressForm.streetLineOne}
                        onInput={handleShippingAddressInfoChange}
                      />
                      <ProfileInput
                        id="streetLineTwo"
                        type="text"
                        placeholder="My dental Office Name (Optional)"
                        value={shippingAddressForm.streetLineTwo}
                        onInput={handleShippingAddressInfoChange}
                      />
                      <ProfileInput
                        id="streetLineThree"
                        type="text"
                        placeholder=""
                        value={shippingAddressForm.streetLineThree}
                        onInput={handleShippingAddressInfoChange}
                      />
                      {streetError ? (
                        <ProfileInputError>
                          This field is required*
                        </ProfileInputError>
                      ) : null}
                    </ProfileInputContainer>
                  </ProfileRows>
                  <ProfileRows>
                    <ProfileInputLabel>
                      Country <span style={{ color: "red" }}>*</span>
                    </ProfileInputLabel>
                    <Select
                      id="country"
                      value={shippingAddressForm.country}
                      onChange={handleShippingAddressInfoChange}
                      className="rounded-sm w-full"
                      placeholder="Select a Country"
                    >
                      <Countries />
                    </Select>
                  </ProfileRows>
                </FirstRowLeft>
                <FirstRowRight>
                  <ProfileRows>
                    <ProfileInputLabel>Phone Number</ProfileInputLabel>
                    <ProfileInputContainer>
                      <ProfileInput
                        id="phoneNumber"
                        type="number"
                        placeholder="Enter Phone Number"
                        value={shippingAddressForm.phoneNumber}
                        onInput={handleShippingAddressInfoChange}
                      />
                      {phoneNumberError ? (
                        <ProfileInputError>
                          This field is required*
                        </ProfileInputError>
                      ) : null}
                    </ProfileInputContainer>
                  </ProfileRows>
                  <ProfileRows>
                    <ProfileInputLabel>
                      City <span style={{ color: "red" }}>*</span>
                    </ProfileInputLabel>
                    <ProfileInputContainer>
                      <ProfileInput
                        id="city"
                        placeholder="Enter City"
                        value={shippingAddressForm.city}
                        onInput={handleShippingAddressInfoChange}
                      />
                      {cityError ? (
                        <ProfileInputError>
                          This field is required*
                        </ProfileInputError>
                      ) : null}
                    </ProfileInputContainer>
                  </ProfileRows>
                  <ProfileRows>
                    <ProfileInputLabel>
                      State / Province
                      <span style={{ color: "red" }}>*</span>
                    </ProfileInputLabel>
                    <ProfileInputContainer>
                      <select
                        id="state"
                        onInput={handleShippingAddressInfoChange}
                        value={shippingAddressForm.state}
                        className="rounded-sm w-full"
                        placeholder="Select Your State"
                      >
                        <States />
                      </select>
                    </ProfileInputContainer>
                  </ProfileRows>
                  <ProfileRows>
                    <ProfileInputLabel>
                      Zip / Postal Code <span style={{ color: "red" }}>*</span>
                    </ProfileInputLabel>
                    <ProfileInputContainer>
                      <ProfileInput
                        id="zipCode"
                        placeholder="Enter Postal Code"
                        value={shippingAddressForm.zipCode}
                        onInput={handleShippingAddressInfoChange}
                      />
                      {zipError ? (
                        <ProfileInputError>
                          This field is required*
                        </ProfileInputError>
                      ) : null}
                    </ProfileInputContainer>
                  </ProfileRows>
                </FirstRowRight>
              </AccountInfoBody>
            </AccountInfoContainer>
          </>
        ) : null}
      </Container>
      <DashboardFooter />
    </>
  );
}
