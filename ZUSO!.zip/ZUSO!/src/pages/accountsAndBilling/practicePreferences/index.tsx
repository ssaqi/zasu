import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import DashboardFooter from "@/components/dashboardFooter";
import * as React from "react";
import { useDispatch } from "react-redux";
import NoSSR from "react-no-ssr";
import {
  getSupplierAccounts,
  getSuppliers,
} from "@/store/supplierPreferenceSlice";
import { setSelectedTab } from "@/store/accountsAndBillingSecondaryNavbarSlice";
import PracticePreferences from "./practicePreferences";

export default function PracticePreferencesPage() {
  const dispatch = useDispatch();

  // @ts-ignore
  dispatch(setSelectedTab(2));
  // @ts-ignore
  dispatch(getSuppliers());

  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <NoSSR>
        <PracticePreferences />
      </NoSSR>
      <DashboardFooter />
    </>
  );
}
