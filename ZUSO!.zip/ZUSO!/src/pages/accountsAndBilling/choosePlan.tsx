import * as React from "react";
import MainNavigation from "@/components/navigation";
import SecondaryNavBar from "@/components/accountsAndBilling/secondaryNavBar";
import DashboardFooter from "@/components/dashboardFooter";
import ChoosePlan from "@/components/accountsAndBilling/choosePlan";

export default function ChoosePlanPage() {
  return (
    <>
      <MainNavigation />
      <SecondaryNavBar />
      <ChoosePlan />
      <DashboardFooter />
    </>
  );
}
