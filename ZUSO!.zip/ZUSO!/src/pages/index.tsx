import Footer from "@/components/footer";
import LoginForm from "@/components/home/loginForm";
import Intro from "@/components/home/intro";
import { HomeContainer } from "@/styledComponents/home";
import { useUser } from "../lib/hooks";
import { useEffect } from "react";
import { useRouter } from "next/router";

import CONSTANTS from "@/utils/constants";

export default function Home() {
  //   const router = useRouter();
  //   const dispatch = useDispatch();

  useUser({ redirectTo: "/dashboard", redirectIfFound: true });
  //   useEffect(() => {
  //     (async () => {
  //         if(localStorage.token.length > 0) {
  //             dispatch(
  //                 // @ts-ignore
  //                 getUserAccountDetails()
  //               );
  //               router.push("/dashboard");
  //         }
  //     //   try {

  //     //     const rsp: any = await fetch(CONSTANTS.api + "user", {
  //     //       credentials: "include",
  //     //       headers: {
  //     //         Authorization: "Bearer " + localStorage.getItem("token"),
  //     //       },
  //     //     });
  //     //     if (rsp.status === 200) {
  //     //       let user = await rsp.json();
  //     //       if (user.message === "success") {
  //     //         console.log(user, ' <<< user response')
  //     //         // if(rj.registerState === 1){
  //     //         //     router.push('/registerLocation?id=' + rj.userId);
  //     //         // }else if(rj.registerState === 2){
  //     //         //     router.push('/registerPayment?id=' + rj.userId);
  //     //         // }else{
  //     //         router.push("/dashboard");
  //     //       }
  //     //     }
  //     //   } catch (err) {
  //     //     console.log("not logged in");
  //     //   }
  //     })();
  //   }),
  //     [];

  return (
    <HomeContainer>
      <LoginForm />
      <Intro />
      <Footer />
    </HomeContainer>
  );
}
