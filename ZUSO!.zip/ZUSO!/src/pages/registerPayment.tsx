import * as React from "react";
import Head from "next/head";
import Link from "next/link";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/router";
import {
  selectRegisterStage,
  selectLocationStage,
  selectPlanStage,
  selectPaymentStage,
  setPaymentStage,
} from "../store/registerSlice";
import { IPayment } from "@/types/registerTypes";
import {
  ArrowIcon,
  BackContainer,
  Container,
  FormPadding,
  NavContainer,
  NavWrapper,
  Numbers,
  NumbersMuted,
} from "@/styledComponents/register";
import { Logo } from "@/styledComponents/register";
import LeftArrow from "../../public/arrowLeft.svg";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import Left from "@/components/register/left";
import LocationForm from "@/components/register/LocationForm";
import PaymentDetailsForm from "@/components/register/paymentDetailsForm";
import Footer from "@/components/register/footer";

export default function Home() {
  const [_isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (isMobile) {
      setIsMobile(true);
    }
  }, []);

  return (
    <>
      <div className="flex flex-col justify-between min-h-screen bg-zuso-blue">
        <Head>
          <title>Register Payment</title>
        </Head>
        <main className="flex flex-col w-full flex-1">
          <NavWrapper>
            <div className="flex pl-2 pt-5 align-center items-center justify-center">
              <Logo src="/logo-white.png" alt="" />
            </div>
            <div className="flex justify-between align-middle w-4/5 p-5 mt-5 mb:mt-1">
              {_isMobile ? (
                <>
                  <NavContainer>
                    <Numbers>4</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Payment
                    </Link>
                  </NavContainer>
                </>
              ) : (
                <>
                  <NavContainer>
                    <Numbers>1</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Create Your Zuso Account
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <Numbers>2</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Your Location
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <Numbers>3</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Select a Plan
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <Numbers>4</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Payment
                    </Link>
                  </NavContainer>
                </>
              )}
            </div>
          </NavWrapper>
          <BackContainer>
            <Link href="/" passHref legacyBehavior>
              <span className="flex text-white font-semibold text-sm text-center hover:cursor-pointer">
                {<ArrowIcon src={LeftArrow.src} alt="" />} &nbsp;Back
              </span>
            </Link>
          </BackContainer>
          <Container>
            <FormPadding>
              <Left />
            </FormPadding>
            <PaymentDetailsForm />
          </Container>
        </main>
        <Footer />
      </div>
    </>
  );
}
