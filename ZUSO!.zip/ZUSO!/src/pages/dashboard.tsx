import {
  DashboardSectionsStyled,
  MainSection,
  MainCards,
  OrderSummaySection,
  SummaryCard,
  TotalQuantity,
  ComingSoon,
} from "@/styledComponents/dashboard/dashboard";
import { useEffect } from "react";
import { useRouter } from "next/router";
import DashboardFooter from "@/components/footerDashboard";
import { useSelector } from "react-redux";
import { selectAccountState } from "@/store/accountSlice";
import MainCard from "../components/dashboard/MainCard";
import OrderCard from "../components/dashboard/OrderCard";
import ComingSoonCard from "../components/dashboard/ComingSoonCard";
import { useUser } from "@/lib/hooks";
import MainNavigation from "@/components/navigation";

const mainCardsContent = [
  {
    icon: "/images/userDashboard/supplies-icon.svg",
    title: "Supplies",
    description:
      "Order from over 500,000 dental products. See supplies that you have previously purchased.",
    buttonText: "Order Supplies",
    link: "/supplies",
  },
  {
    icon: "/images/userDashboard/equipment-icon.svg",
    title: "Equipment",
    description:
      "Research new equipment and get quotes from your preferred vendors.",
    buttonText: "Request Bids",
    link: "/equipmentProposals",
  },
  {
    icon: "/images/userDashboard/technical-icon.svg",
    title: "Technical Service and Parts",
    description: "Request a service call from your preferred vendor.",
    buttonText: "Request Service",
    link: "/techServiceAndParts",
  },
  {
    icon: "/images/userDashboard/orders-icon.svg",
    title: "Orders",
    description:
      "Manage all your orders, check backorders and reconcile product pricing.",
    buttonText: "Manage",
    link: "/orders",
  },
  {
    icon: "/images/userDashboard/lists-icon.svg",
    title: "Lists",
    description:
      "Create and manage lists of the things you want now or in the future.",
    buttonText: "Manage",
    link: "/lists",
  },
  {
    icon: "/images/userDashboard/digital-icon.svg",
    title: "Digital Catalogs",
    description: "Download product information and brochures.",
    buttonText: "View Catalogs",
    link: "/digitalCatalog",
  },
  {
    icon: "/images/userDashboard/help-icon.svg",
    title: "Get Help",
    description:
      "Contact ZuSo for any help you need procuring supplies, equipment or a service technician. Identify a product or get help locating hard to find products.",
    buttonText: "Get help",
    link: "/contactUs",
  },
  {
    icon: "/images/userDashboard/team-icon.svg",
    title: "Manage your Team",
    description: "Add or delete team members. Manage team members permissions.",
    buttonText: "Manage",
    link: "/accountsAndBilling/users",
  },
  {
    icon: "/images/userDashboard/request-icon.svg",
    title: "Request Product Info or Sample",
    description:
      "Request product samples, schedule product demos or find product information.",
    buttonText: "Create a request",
    link: "/techServiceAndParts",
  },
];

export default function Home() {
  const router = useRouter();

  const userDetails = useUser({
    redirectTo: "/dashboard",
    redirectIfFound: true,
  });

  useEffect(() => {
    if (userDetails.register_stage == 1) {
      router.push("/registerPlan");
    }
  });

  return (
    <>
      <MainNavigation />
      <DashboardSectionsStyled>
        <MainSection>
          <h1>Dashboard</h1>
          <MainCards>
            <MainCard
              icon={mainCardsContent[0].icon}
              title={mainCardsContent[0].title}
              description={mainCardsContent[0].description}
              buttonText={mainCardsContent[0].buttonText}
              largeFont={true}
              goToLink={() => router.push(mainCardsContent[0].link)}
            />
            <MainCard
              icon={mainCardsContent[1].icon}
              title={mainCardsContent[1].title}
              description={mainCardsContent[1].description}
              buttonText={mainCardsContent[1].buttonText}
              largeFont={true}
              goToLink={() => router.push(mainCardsContent[1].link)}
            />
            <MainCard
              icon={mainCardsContent[2].icon}
              title={mainCardsContent[2].title}
              description={mainCardsContent[2].description}
              buttonText={mainCardsContent[2].buttonText}
              largeFont={true}
              goToLink={() => router.push(mainCardsContent[2].link)}
            />
            <OrderCard />
            <MainCard
              icon={mainCardsContent[3].icon}
              title={mainCardsContent[3].title}
              description={mainCardsContent[3].description}
              buttonText={mainCardsContent[3].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[3].link)}
            />
            <MainCard
              icon={mainCardsContent[4].icon}
              title={mainCardsContent[4].title}
              description={mainCardsContent[4].description}
              buttonText={mainCardsContent[4].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[4].link)}
            />
            <MainCard
              icon={mainCardsContent[5].icon}
              title={mainCardsContent[5].title}
              description={mainCardsContent[5].description}
              buttonText={mainCardsContent[5].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[5].link)}
            />
            <MainCard
              icon={mainCardsContent[6].icon}
              title={mainCardsContent[6].title}
              description={mainCardsContent[6].description}
              buttonText={mainCardsContent[6].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[6].link)}
            />
            <MainCard
              icon={mainCardsContent[7].icon}
              title={mainCardsContent[7].title}
              description={mainCardsContent[7].description}
              buttonText={mainCardsContent[7].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[7].link)}
            />
            <MainCard
              icon={mainCardsContent[8].icon}
              title={mainCardsContent[8].title}
              description={mainCardsContent[8].description}
              buttonText={mainCardsContent[8].buttonText}
              largeFont={false}
              goToLink={() => router.push(mainCardsContent[8].link)}
            />
          </MainCards>
        </MainSection>
        <OrderSummaySection>
          <h1>Order Summary</h1>
          <div>
            <SummaryCard>
              <div>
                <h2>YTD Total Purchased</h2>
              </div>
              <div>
                <p>$20,332</p>
              </div>
            </SummaryCard>
            <SummaryCard>
              <div>
                <h2>Prev. Year Total Purchased</h2>
              </div>
              <div>
                <p>$Unknown</p>
              </div>
            </SummaryCard>
            <SummaryCard>
              <div>
                <h2>YTD Total Order quantity</h2>
              </div>
              <div>
                <p>54 Items</p>
                <TotalQuantity>78 Total Quantity</TotalQuantity>
              </div>
            </SummaryCard>
            <SummaryCard>
              <div>
                <h2>YTD EQPT & Services Requests</h2>
              </div>
              <div>
                <p>12 Requests</p>
              </div>
            </SummaryCard>
          </div>
        </OrderSummaySection>
        <ComingSoon>
          <h2>Coming Soon!</h2>
          <div>
            <ComingSoonCard text={"Approvals"} />
            <ComingSoonCard text={"Manage Locations"} />
            <ComingSoonCard text={"Create or Manage Formulary"} />
            <ComingSoonCard text={"Request a Quote"} />
          </div>
        </ComingSoon>
      </DashboardSectionsStyled>
      <DashboardFooter />
    </>
  );
}
