import * as React from "react";
import Head from "next/head";
import Link from "next/link";
import { useSelector, useDispatch } from "react-redux";
import {
  // selectRegisterStageIndex,
  selectRegisterStage,
  // selectLocationStage,  selectPlanStage,  selectPaymentStage,
  // setRegisterStageIndex,
  setRegisterStage,
  // , setLocationStage, setPlanStage, setPaymentStage
} from "../store/registerSlice";
import { IRegister } from "@/types/registerTypes";
import {
  ArrowIcon,
  BackContainer,
  Container,
  FormPadding,
  NavContainer,
  NavWrapper,
  Numbers,
  NumbersMuted,
} from "../styledComponents/register";
import Footer from "../components/register/footer";
// import { wrapper } from "../store/store";
import { useEffect, useState } from "react";
import { isMobile } from "react-device-detect";
import Left from "@/components/register/left";
import AccountForm from "@/components/register/accountForm";
import { Logo } from "src/styledComponents/register";
import LeftArrow from "../../public/arrowLeft.svg";

function Home() {
  const [_isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (isMobile) {
      setIsMobile(true);
    }
  }, []);

  return (
    <>
      <div className="flex flex-col justify-between min-h-screen bg-zuso-blue">
        <Head>
          <title>Register</title>
        </Head>
        <main className="flex flex-col w-full flex-1">
          <NavWrapper>
            <div className="flex pl-2 pt-5 align-center items-center justify-center">
              <Logo src="/logo-white.png" alt="" />
            </div>
            <div className="flex justify-between align-middle w-4/5 p-5 mt-5 mb:mt-1">
              {_isMobile ? (
                <>
                  <NavContainer>
                    <Numbers>1</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Create Your Zuso Account
                    </Link>
                  </NavContainer>
                </>
              ) : (
                <>
                  <NavContainer>
                    <Numbers>1</Numbers>
                    <Link href="#" className="text-xs font-bold text-white">
                      &nbsp; Create Your Zuso Account
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <NumbersMuted>2</NumbersMuted>
                    <Link
                      href="#"
                      className="text-xs font-bold text-zuso-blue-disabled"
                    >
                      &nbsp; Your Location
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <NumbersMuted>3</NumbersMuted>
                    <Link
                      href="#"
                      className="text-xs font-bold text-zuso-blue-disabled"
                    >
                      &nbsp; Select a Plan
                    </Link>
                  </NavContainer>
                  <NavContainer>
                    <NumbersMuted>4</NumbersMuted>
                    <Link
                      href="#"
                      className="text-xs font-bold text-zuso-blue-disabled"
                    >
                      &nbsp; Payment
                    </Link>
                  </NavContainer>
                </>
              )}
            </div>
          </NavWrapper>
          <BackContainer>
            <Link href="/" passHref legacyBehavior>
              <span className="flex text-white font-semibold text-sm text-center hover:cursor-pointer">
                {<ArrowIcon src={LeftArrow.src} alt="" />} &nbsp;Back
              </span>
            </Link>
          </BackContainer>
          <Container>
            <FormPadding>
              <Left />
            </FormPadding>
            <AccountForm />
          </Container>
        </main>
        <Footer />
      </div>
    </>
  );
}

export default Home;
