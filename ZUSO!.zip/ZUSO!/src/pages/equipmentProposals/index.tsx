/* eslint-disable react-hooks/exhaustive-deps */
import {
  EquipmentProposalsStyled,
  ContentWrapper,
  TopSection,
} from "@/styledComponents/equipmentProposals/equipmentProposals";
import MainNavigation from "@/components/navigation";
import DashboardFooter from "@/components/dashboardFooter";
import { useDispatch, useSelector } from "react-redux";
import EquipmentProposalsModal from "../../components/equipmentProposals/EquipmentProposalsModal";
import { useState, useEffect } from "react";
import ReactTable from "@/components/equipmentProposals/ReactTable";
import { useUser } from "@/lib/hooks";

const EquipmentProposals = () => {
  const dispatch = useDispatch();
  const user = useUser({ redirectTo: "/equipmentProposals", redirectIfFound: true });
 

  //Just to show some early mock data with state
  // useEffect(() => {
  //   if (items && items.length === 0) {
  //     for (let i = 0; i < 20; i++) {
  //       dispatch(
  //         // @ts-ignore
  //         addItem({
  //           requestNumber: `ZSEQ10001 - ${i + 1}`,
  //           requestDate: `Mar 3, 2023 - ${i + 1}`,
  //           suppliers: `Midwest Dental, Henry Schein, Patterson - ${i + 1}`,
  //           requestedBy: `Zachary Hoffman, zach.hoffman@willamettedental.com - ${
  //             i + 1
  //           }`,
  //           action: `See Details`,
  //           manufacturerName: `User input info here - ${i + 1}`,
  //           mfrPartNumber: `User input info here - ${i + 1}`,
  //           productName: `User input info here - ${i + 1}`,
  //           notes: `Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem. Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem. Ipsa non labore quia dolorem. Laborum voluptas animi totam suscipit blanditiis non voluptas rem.  - ${
  //             i + 1
  //           }`,
  //         })
  //       );
  //     }
  //   }
  // }, []);

  

  const [isEquipmentProposalsModalOpen, setIsEquipmentProposalsModalOpen] =
    useState(false);

  const closeEquipmentProposalsModal = () => {
    setIsEquipmentProposalsModalOpen(false);
  };

  return (
    <>
      <EquipmentProposalsStyled>
        <MainNavigation />
        <ContentWrapper>
          <TopSection>
            <h1>Equipment Proposals</h1>
            <button onClick={() => setIsEquipmentProposalsModalOpen(true)}>
              Request Equipment Proposal
            </button>
          </TopSection>
          {<ReactTable />}
        </ContentWrapper>
        <DashboardFooter />
      </EquipmentProposalsStyled>
      <EquipmentProposalsModal
        setIsOpen={setIsEquipmentProposalsModalOpen}
        isOpen={isEquipmentProposalsModalOpen}
        closeModal={closeEquipmentProposalsModal}
        user={user}
      />
    </>
  );
};

export default EquipmentProposals;
