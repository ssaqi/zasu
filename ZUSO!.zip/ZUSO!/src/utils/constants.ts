const CONSTANTS = {
  api: "https://staging.app.zusodental.com/api/", // STAGING
  // api: "http://localhost:4000/api/", // DEV/local
  stripe_public_key:
    "pk_test_51JtYoVEvyGxTLA6bzjjazEqrl1o0GyxDaM3cu14pKS2mU2rLJ22X5gG5dSHuL9yNcVsVt7HwCgM2zLbu0jLoJAbz00Y6jTDTfS",
  modalStyles: {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)",
      border: "none",
      padding: "0px",
    },
  },
  distributorTypes: {
    PRIMARY: "PRIMARY",
    SECONDARY: "SECONDARY",
    ADDITIONAL: "ADDITIONAL",
  },
};

export default CONSTANTS;
