/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
 
    // Or if using `src` directory:
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        'login-image': "url('/login-right.png')",
        'login-logo': "url('/login-new.png')",
      },
      colors: {
        'zuso-gray' : '#E5E5E5',
        'zuso-gray-2' : '#64748B',
        'zuso-blue' : '#1E9ED4',
        'zuso-blue-disabled' : '#72CDF3',
        'zuso-dark-blue' : '#475569',
        'zuso-light-blue' : '#30ACE0',
        'zuso-label' : '#64748B',
        'zuso-btn-pressed' : '#015F87',
        'zuso-yellow' : '#FCD34D',
        'zuso-dark-blue-2' : '#0172A2',
        'zuso-logo-db-bg-dark' : '#0D2142',
        'zuso-navbar-bg-dark' : '#17325E',
        'zuso-db-bg-gray' : '#F1F5F9',
        'zuso-db-text-gray' : '#94A38B',
        'zuso-bg-search': '#E2E8F0',
        
      },
      height : {
        'h-63' : '63.38px',
      },
      width : {
        'w-185' : '185.48px'
      }
    },
  },
  plugins: [],
}
